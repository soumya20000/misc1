function tb_pdplot(tb, varargin)
%TB_PDPLOT    Partial Dependence Plot for a TreeBagger TB
%    This function creates a grid of 1D and 2D partial dependency plots for
%    a multivariate function.  If TB is a classifier, then the quantities
%    plotted will be the probabilities of the last class.  The line plots along
%    the diagonal are the 1D partial dependency plots - they illustrate the
%    average change in the out-of-bag predictions as the x-variable is varied
%    across the range of values.
%
%    tb_pdplot(tb) - make the grid of partial dependence plots
%    tb_pdplot(tb, X_names) - apply labels to the plot identifying the
%                             X variables
%    tb_pdplot(..., 'num_points',N) - use grids of size N in each direction for
%                                     all of the non-categorical variables
%    tb_pdplot(..., 'pure_interactions',tf) - if tf is true, then subtract the
%                                             1D partial dependencies from the
%                                             2D partial dependencies to get
%                                             a picture of the purely 2D
%                                             interaction effects
%    tb_pdplot(..., 'columns',cols) - only make partial dependence plots for
%                                     the columns specified by COLS (either
%                                     a logical vector with TRUE for the
%                                     columns to include, or a vector of
%                                     indices into the columns of X);
%                                     note that even when this option is used,
%                                     the other parameters (X_names)
%                                     must still contain all of the columns

    function X_new = predictors_0col(tb)
        X_new = tb.X;
    end

    function X_new = predictors_1col(tb, col_ind, col_vals)
        N = size(tb.X, 1);
        X_new = repmat(tb.X, numel(col_vals), 1);
        X_new(:,col_ind) = reshape(repmat(col_vals(:)', N, 1), ...
                                   N*numel(col_vals),          ...
                                   1);
    end

    function X_new = predictors_2col(tb, col_ind1, col_vals1, ...
                                         col_ind2, col_vals2)
        [CV1,CV2] = meshgrid(col_vals1(:)', col_vals2(:));
        N = size(tb.X, 1);
        X_new = repmat(tb.X, numel(col_vals1) * numel(col_vals2), 1);
        X_new(:,col_ind1) = reshape(repmat(CV1(:)', N, 1), N*numel(CV1), 1);
        X_new(:,col_ind2) = reshape(repmat(CV2(:)', N, 1), N*numel(CV2), 1);
    end

    function y_hat = numerical_predictions(tb, X, varargin)
    % Return the regression predictions or the classification probabilities of
    % the last class.
        if strcmpi(tb.Method, 'regression')
            y_hat = tb.predict(X, varargin{:});
        else
            [~,scores] = tb.predict(X, varargin{:});
            y_hat = scores(:,end);
        end
    end % numerical_predictions()

    function y_hat = predictions(tb, X_new)
        N = size(tb.X, 1);
        num_rep = size(X_new, 1) / N;
        res = NaN(N, num_rep, tb.NumTrees);
        for t=1:tb.NumTrees
            tf_oob = tb.OOBIndices(:,t);
            if (any(tf_oob))
                tmp = numerical_predictions( ...
                        tb, X_new(repmat(tf_oob, num_rep, 1), :), 'trees',t);
                res(tf_oob, :, t) = reshape(tmp, sum(tf_oob), num_rep);
            end
        end
        y_hat = squeeze(nanmean(res, 3));
    end


    % Validate the inputs
    assert((nargin>=2), 'TB_PDPLOT requires at least 2 input parameters');
    assert(isscalar(tb) && strcmp(class(tb), 'TreeBagger'), ...
           'TB_PDPLOT requires a TreeBagger object as its first argument');
    assert(tb.ComputeOOBPrediction, ...
           'TB_PDPLOT requires the random forest to have been constructed with the OOBPRED option set to ON');
    p = size(tb.X, 2);
    ip = inputParser();
    ip.FunctionName = 'tb_pdplot';
    ip.KeepUnmatched = false;
    ip.addOptional('X_names', {}, @(c)(iscell(c) & numel(c)==p));
    ip.addParameter('num_points', 11, @(n)(isscalar(n) & (n > 1)));
    ip.addParameter('pure_interactions', false, @(f)(isscalar(f)));
    ip.addParameter('columns', 1:p, @(c)(   (islogical(c) && (numel(c)==p))  ...
                                         || (   isnumeric(c) && (numel(c)<=p)...
                                             && (min(c)>=1) && (max(c)<=p) ) ));
    ip.parse(varargin{:});
    if islogical(ip.Results.columns)
        ip.Results.columns = find(ip.Results.columns);
    end


    % Initialize the figure
    f = figure();
    set(f, 'Units','normalized', 'OuterPosition',[0 0 1 1]); % maximize figure

    % Choose some "typical" value of Y as a common reference, only plot deltas
    Y0 = predictions(tb, predictors_0col(tb));

    % Store the array of x-values over which to compute the responses;
    % the TreeBagger class doesn't store whether or not each column is
    % categorical, so try to guess.
    num_vars = numel(ip.Results.columns);
    x_vals = cell(1, num_vars);
    for jj=1:num_vars
        jj_col = ip.Results.columns(jj);
        all_values = unique(tb.X(:,jj_col));
        all_values = all_values(isfinite(all_values));
        if (numel(all_values) < ip.Results.num_points)
            x_vals{jj} = all_values';
        else
            x_vals{jj} = linspace(min(tb.X(:,jj_col)), ...
                                  max(tb.X(:,jj_col)), ...
                                  ip.Results.num_points);
        end
    end

    % Create and store the 1D partial dependency plots along the diagonal
    delta_lim = [+Inf, -Inf];
    Y1 = cell(1, num_vars);
    for jj=1:num_vars
        jj_col = ip.Results.columns(jj);
        ii = jj;
        ax = subplot(num_vars, num_vars, (ii-1)*num_vars+jj);
        xs = x_vals{jj};
        Y1{jj} = predictions(tb, predictors_1col(tb, jj_col, xs));
        deltas = nanmean(bsxfun(@minus, Y1{jj}, Y0));
        surface([xs;xs], [deltas;deltas],            ...
                zeros(2,numel(xs)), [deltas;deltas], ...
                'FaceColor','none', 'EdgeColor','interp', 'LineWidth',4);
        xlim(ax, [xs(1) - (xs(2)-xs(1))/2, xs(end) + (xs(end)-xs(end-1))/2]);
        delta_lim(1) = min(delta_lim(1), min(deltas(:)));
        delta_lim(2) = max(delta_lim(2), max(deltas(:)));
    end

    % Create the 2D partial dependency plots on the off-diagonals
    for ii=1:num_vars
        ii_col = ip.Results.columns(ii);
        for jj=1:num_vars
            jj_col = ip.Results.columns(jj);
            if (ii == jj)
                continue;
            end
            ax = subplot(num_vars, num_vars, (ii-1)*num_vars+jj);
            xs = x_vals{jj};
            ys = x_vals{ii};
            Y2 = predictions(tb, predictors_2col(tb, jj_col, xs, ii_col, ys));
            if (ip.Results.pure_interactions)
                deltas =   bsxfun(@plus, Y2, Y0)                 ...
                         - reshape(repmat(Y1{jj}, numel(ys), 1), ...
                                   size(Y1{jj},1),               ...
                                   size(Y1{jj},2)*numel(ys))     ...
                         - repmat(Y1{ii}, 1, numel(xs));
            else
                deltas = bsxfun(@minus, Y2, Y0);
            end
            deltas = reshape(nanmean(deltas), numel(ys), numel(xs));
            image([xs(1), xs(end)], [ys(1), ys(end)], deltas, ...
                  'CDataMapping','scaled');
            set(ax, 'YDir','normal');
            delta_lim(1) = min(delta_lim(1), min(deltas(:)));
            delta_lim(2) = max(delta_lim(2), max(deltas(:)));
        end
    end

    % Make all of the $\Delta Y$ limits the same
    for ii=1:num_vars
        for jj=1:num_vars
            ax = subplot(num_vars, num_vars, (ii-1)*num_vars+jj);
            caxis(ax, delta_lim);
            if (ii == jj)
                ylim(ax, delta_lim);
            end
        end
    end

    % Add axis labels if requested
    if ~isempty(ip.Results.X_names)
        % X labels along bottom row
        ii=num_vars;
        for jj=1:num_vars
            jj_col = ip.Results.columns(jj);
            ax = subplot(num_vars, num_vars, (ii-1)*num_vars+jj);
            xlabel(ax, ip.Results.X_names{jj_col});
        end

        % Y labels along left column
        jj=1;
        for ii=1:num_vars
            ii_col = ip.Results.columns(ii);
            ax = subplot(num_vars, num_vars, (ii-1)*num_vars+jj);
            ylabel(ax, ip.Results.X_names{ii_col});
        end
    end

    % Place a tick at every value for the categorical variables
    for jj=1:num_vars
        if (numel(x_vals{jj}) < ip.Results.num_points)
            for ii=1:num_vars
                ax = subplot(num_vars, num_vars, (ii-1)*num_vars+jj);
                set(ax, 'XTick',x_vals{jj});
            end
        end
    end
    for ii=1:num_vars
        if (numel(x_vals{ii}) < ip.Results.num_points)
            for jj=1:num_vars
                ax = subplot(num_vars, num_vars, (ii-1)*num_vars+jj);
                set(ax, 'YTick',x_vals{ii});
            end
        end
    end

    % Remove extraneous tick labels
    for ii=1:(num_vars-1)
        for jj=1:num_vars
            ax = subplot(num_vars, num_vars, (ii-1)*num_vars+jj);
            set(ax, 'XTickLabel',{});
        end
    end
    for ii=1:num_vars
        for jj=2:num_vars
            ax = subplot(num_vars, num_vars, (ii-1)*num_vars+jj);
            set(ax, 'YTickLabel',{});
        end
    end
    % TODO fix this to work like GPLOTMATRIX
    ii=1; jj=1;
    ax = subplot(num_vars, num_vars, (ii-1)*num_vars+jj);
    set(ax, 'YTick',[]);

    % Create a common colorbar for all of the $\Delta Y$ scales
    pos_bot  = get(subplot(num_vars,num_vars,num_vars*num_vars), 'Position');
    pos_top  = get(subplot(num_vars,num_vars,num_vars),          'Position');
    margin_width = 1 - pos_top(1) - pos_top(3);
    colorbar('Position', [pos_top(1) + pos_top(3) + margin_width/5, ...
                          pos_bot(2),                               ...
                          margin_width / 2,                         ...
                          pos_top(2) + pos_top(4) - pos_bot(2)]);

end % tb_pdplot()
