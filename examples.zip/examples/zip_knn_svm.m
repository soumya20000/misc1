%% Handwriting Recognition - Digits from the zip code data set
% This is a famous data set that has been used for many different
% classification studies in the public literature.  The data set was put
% together by the United States Postal Service.  It was used to test algorithms
% to be used by their automatic handwriting recognition systems used to sort
% and route mail.  Note that the classification of an image as a handwritten
% "1" or "2" is the _last_ step of the business problem.  The hard work of
% making this a production system would have to include all of the following
% steps:
%
% # Find the zip code on the envelope.
% # Isolate the individual digits in the zip code.
% # Re-color the images so that they use a common scale for the pixel values.
% # Rescale the images so that they are the same size.
% # Rotate and center the images so that they are all facing the right way for the classifier (note that with deep learning, this might not be required).
%
% All of these steps have been performed for us so we can concentrate on the
% classification problem.  Remember, though, that for a real business problem,
% the "data analytics" is always just a small fraction of the work required.



%% Import the data
% This data set is already split into a training set and a test set.
% For any particular classification model, you should _only_ experiment with
% the training data.  In particular, you should use the training data to help
% decide on the features you want to include, the metric you want to use, the
% hyperparameters that seem to work best, etc.  Only at the end should you
% train the final algorithm on the complete training set and then test
% _exactly once_ against the test set.  In other words, the test set should
% _only_ be used to compare algorithms, not to fine-tune algorithms.
[X_train,Y_train,X_test,Y_test] = zip_import();

%%
% Plot examples of each digit
figure();
for d=0:9
    subplot(4, 3, d+1);
    ind = find(Y_train == d, 1, 'first');
    zip_plot(X_train(ind,:));
    title(num2str(Y_train(ind)));
end



%% k-Nearest Neighbors
% This is the simplest machine learning algorithm.  Define some metric in order
% to quantify the "distance" between pairs of feature vectors.  Also fix some
% small positive integer $k$.  The *k-nearest neighbors* algorithm makes
% a prediction for a new feature vector by finding the $k$ training vectors
% that are most similar to the new feature vector.  It then uses the majority
% vote of those $k$ training classes as the predicted class for the new feature
% vector.

%%
% Make sure we get the same results every time we run this code
RandStream.getGlobalStream.reset();

%%
% We'll use 10-fold cross-validation on the training set in order to tune our
% model.
cvp = cvpartition(numel(Y_train), 'KFold',10);

%%
% I don't know what the best metric or the best value of $k$ might be, so I'll
% iterate over many possibilities to choose the parameters that give the best
% cross-validated performance.
knn_param1_numneighbors = 1:10;
knn_param2_metrics = {'euclidean', 'cityblock', 'correlation'};
knn_misclassification_rates = NaN(numel(knn_param1_numneighbors), ...
                                  numel(knn_param2_metrics),      ...
                                  cvp.NumTestSets);
for p1=1:numel(knn_param1_numneighbors)
    for p2=1:numel(knn_param2_metrics)
        % Perform cross-validation for this combination of model parameters
        for f=1:cvp.NumTestSets
            mdl = fitcknn(X_train(cvp.training(f),:),                 ...
                          Y_train(cvp.training(f)),                   ...
                          'BreakTies','nearest',                      ...
                          'NumNeighbors',knn_param1_numneighbors(p1), ...
                          'Distance',knn_param2_metrics{p2});
            predictions = mdl.predict(X_train(cvp.test(f),:));
            loss = mean(Y_train(cvp.test(f)) ~= predictions);
            knn_misclassification_rates(p1, p2, f) = loss;
        end
    end
end

%%
% Plot the cross-validated results
figure();
for p2=1:numel(knn_param2_metrics)
    errorbar(knn_param1_numneighbors,                            ...
             mean(squeeze(knn_misclassification_rates(:,p2,:))), ...
             std(squeeze(knn_misclassification_rates(:,p2,:))),  ...
             'o-');
    hold on;
end
legend(knn_param2_metrics);
xlabel('number of nearest neighbors');
ylabel('misclassification rate across folds');
title('k-Nearest Neighbors training');

%%
% Choose the best parameter set for our k-nearest neighbor model to test
knn_avg_misclassification_rates = mean(knn_misclassification_rates, 3);
[~,ind] = min(knn_avg_misclassification_rates(:));
[knn_p1,knn_p2] = ind2sub(size(knn_avg_misclassification_rates), ind);
knn_mdl = fitcknn(X_train, Y_train, 'BreakTies','nearest',        ...
                  'NumNeighbors',knn_param1_numneighbors(knn_p1), ...
                  'Distance',knn_param2_metrics{knn_p2});



%% Support Vector Machines
% Support Vector Machines (SVM) are much more sophisticated machine learning
% algorithms.  Intuitively, they work by automatically creating more features
% and then searching for hyperplanes in this new, higher-dimensional space that
% perfectly separate the classes.  We do not know ahead of time which "kernel"
% or what kernel "scale" parameter will work best, so we optimize them using
% cross-validation.
svm_param1_kernelfunction = {'gaussian', 'linear'};
svm_param2_kernelscale = logspace(-1, +2, 21);
svm_misclassification_rates = NaN(numel(svm_param1_kernelfunction), ...
                                  numel(svm_param2_kernelscale),    ...
                                  cvp.NumTestSets);
for p1=1:numel(svm_param1_kernelfunction)
    for p2=1:numel(svm_param2_kernelscale)
        % Perform cross-validation for this combination of model parameters
        t = templateSVM('KernelFunction',svm_param1_kernelfunction{p1}, ...
                        'KernelScale',svm_param2_kernelscale(p2));
        for f=1:cvp.NumTestSets
            mdl = fitcecoc(X_train(cvp.training(f),:), ...
                           Y_train(cvp.training(f)),   ...
                           'Learners',t);
            predictions = mdl.predict(X_train(cvp.test(f),:));
            loss = mean(Y_train(cvp.test(f)) ~= predictions);
            svm_misclassification_rates(p1, p2, f) = loss;
        end
    end
end

%%
% Plot the cross-validated results.
figure();
for p1=1:numel(svm_param1_kernelfunction)
    errorbar(svm_param2_kernelscale,                          ...
             mean(svm_misclassification_rates(p1,:,:), 3),    ...
             std(svm_misclassification_rates(p1,:,:), [], 3), ...
             'o-');
    hold on;
end
legend(svm_param1_kernelfunction);
xlabel('kernel scale');
ylabel('misclassification rate across folds');
title('Support Vector Machine training');
set(gca, 'xscale','log');

%%
% Choose the best parameter set for our support vector machine model to test.
svm_avg_misclassification_rates = mean(svm_misclassification_rates, 3);
[~,ind] = min(svm_avg_misclassification_rates(:));
[svm_p1,svm_p2] = ind2sub(size(svm_avg_misclassification_rates), ind);
t = templateSVM('KernelFunction',svm_param1_kernelfunction{svm_p1}, ...
                'KernelScale',svm_param2_kernelscale(svm_p2));
svm_mdl = fitcecoc(X_train, Y_train, 'Learners',t);



%% Final evaluation on test set
% We tuned our models using cross-validation on the training set.  This is the
% best way to tune models, but might still leave us with a model that is
% overfit to the training data.  We perform the final evaluation of our models'
% abilities to generalize to unseen data by testing them against our test set.
knn_yhat = knn_mdl.predict(X_test);
knn_confmat = array2table(confusionmat(Y_test, knn_yhat),                    ...
                          'VariableNames',cellfun(@(v)sprintf('pred_%u', v), ...
                                                  num2cell(0:9),             ...
                                                  'UniformOutput',false),    ...
                          'RowNames',cellfun(@(v)sprintf('actual_%u', v),    ...
                                             num2cell(0:9),                  ...
                                             'UniformOutput',false));
fprintf('%u-nearest neighbors (metric = %s) misclassification rate:  %.1f%%\n',...
        knn_param1_numneighbors(knn_p1), knn_param2_metrics{knn_p2}, ...
        100 * mean(knn_yhat ~= Y_test));
disp(knn_confmat);

svm_yhat = svm_mdl.predict(X_test);
svm_confmat = array2table(confusionmat(Y_test, svm_yhat),                    ...
                          'VariableNames',cellfun(@(v)sprintf('pred_%u', v), ...
                                                  num2cell(0:9),             ...
                                                  'UniformOutput',false),    ...
                          'RowNames',cellfun(@(v)sprintf('actual_%u', v),    ...
                                             num2cell(0:9),                  ...
                                             'UniformOutput',false));
fprintf('\nSupport Vector Machine (%s kernel function with kernel scale = %.3f) misclassification rate:  %.1f%%\n', ...
        svm_param1_kernelfunction{svm_p1}, ...
        svm_param2_kernelscale(svm_p2),    ...
        100 * mean(svm_yhat ~= Y_test));
disp(svm_confmat);



%% Final model
% We have now built, tuned, and evaluated our models, and we have decided on
% a single best model.  If we were to deploy this model, we would first want to
% rebuild our best model on ALL of the data (training + test).
mdl_deploy = fitcknn(vertcat(X_train, X_test), vertcat(Y_train, Y_test), ...
                     'BreakTies','nearest',                              ...
                     'NumNeighbors',knn_param1_numneighbors(knn_p1),     ...
                     'Distance',knn_param2_metrics{knn_p2});

