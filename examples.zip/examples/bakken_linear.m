%% Unconventional Well Example
% The |bakken.matlab| file contains information about several thousand wells
% in the Bakken formation in North Dakota and Montana.


%% Data Import
%#ok<*NOPTS>
%#ok<*NASGU>
bakken_import;



%% 2(a) Outliers
% Are there any outliers that you might want to exclude from further analysis
% (or at least from your first analysis)?

%%
% We could certainly try a purely statistical approach.  A common
% (but terrible) rule of thumb is to look at one variable at a time, and to
% consider all values more than two standard deviations away from the mean to
% be outliers.  The main reason that this is terrible is because means and
% standard deviations are highly sensitive to outliers, which is not a good
% property to have for an outlier detection method.
%
% A better approach is to use the Median Absolute Deviation (MAD).  In this
% case, the median serves as a robust point estimate (whereas the mean is
% non-robust), and the MAD serves as a robust spread (whereas the standard
% deviation is non-robust).  We multiply by the arbitrary-looking 1.4826 to get
% a quantity that should approximately equal the standard deviation if the data
% were Gaussian with no big outliers.  Then the robust z-score is just the
% point value minus the median, divided by the MAD.  We could define an
% arbitrary cutoff for outliers; in a Gaussian sample, for instance, there
% would be less than a one-in-a-million chance of a point being outside the
% range from -5 to +5.
propp_median        = nanmedian(X.proppant); % exclude NaNs
propp_mad           = 1.4826 * mad(X.proppant, 1); % median absolute deviation
propp_zscore_robust = (X.proppant - propp_median) / propp_mad;
propp_tf_outlier    = abs(propp_zscore_robust) > 5;

%%
% Notice that in this case we only removed a small number of proppant values,
% but it had a dramatic effect on the mean and standard deviation.  The median
% and the MAD, however, are almost unchanged.
before_outlier_removal = round([nanmedian(X.proppant);    ...
                                nanmean(X.proppant);      ...
                                mad(X.proppant,1)*1.4826; ...
                                nanstd(X.proppant)] / 1e6, 2);
after_outlier_removal = round([nanmedian(X.proppant(~propp_tf_outlier));    ...
                               nanmean(X.proppant(~propp_tf_outlier));      ...
                               mad(X.proppant(~propp_tf_outlier),1)*1.4826; ...
                               nanstd(X.proppant(~propp_tf_outlier))] / 1e6, 2);
num_removed = sum(propp_tf_outlier)
fraction_removed = mean(propp_tf_outlier)
results = table(before_outlier_removal, after_outlier_removal, ...
                'RowNames',{'median', 'mean', 'median absolute deviation', 'standard deviation'})


%%
% It is MUCH better to do problem-specific filtering.  This is where a LOT of
% your time will be spent on any real problem.  Here is how I probably
% approached this problem.
clear propp_median propp_mad propp_zscore_robust propp_tf_outlier before_outlier_removal after_outlier_removal num_removed fraction_removed results;

%%
% *Proppant:*  Some of the proppant values are so large that the histogram for
% proppant looks like a vertical line near 0 and a single point all the way to
% the right.  Let's investigate.
[~,j] = max(X.proppant);
X.proppant(j) / nanmedian(X.proppant)

%%
% So, the biggest value is about 1,000 times bigger than "normal".  I have
% a hypothesis.  The units are pounds, but occasionally an operator will report
% their proppant total in tons (1 ton = 2,000 pounds).  In this case they might
% have converted to pounds but accidentally written "tons" as the unit.  I can
% check the official records for this well that have been submitted to the
% state.  For now, I will just flag it as an outlier.
tf_X_reject = false(numel(X.proppant), 1);
tf_X_reject(j) = true;
figure();
histogram(X.proppant(~tf_X_reject));
xlabel('proppant [lbs]');

%%
% There are still a few big outliers, but I can't think of any simple
% explanation for them.  I also can't think of any simple explanation for the
% large fluid volumes.  What if I plot them together?
proppant_concentration = X.proppant ./ X.frac_fluid / 42;
figure();
scatter(X.frac_fluid(~tf_X_reject), X.proppant(~tf_X_reject), 10, ...
        proppant_concentration(~tf_X_reject), 'filled');
xlabel('frac\_fluid [bbls]');
ylabel('proppant [lbs]');
c = colorbar();
ylabel(c, 'proppant concentration [ppg]');

%%
% Some of my proppant concentrations are as high as 2300 pounds per gallon.
% I know that it's not physically possible to pump slurry with more than 5ppg
% of proppant, so those MUST be mistakes.  I should really look these up and
% correct the collected data if possible.  For now, I will mark them for
% rejection.
tf_X_reject(proppant_concentration > 5) = true;
figure();
scatter(X.frac_fluid(~tf_X_reject), X.proppant(~tf_X_reject), 10, ...
        proppant_concentration(~tf_X_reject), 'filled');
xlabel('frac\_fluid [bbls]');
ylabel('proppant [lbs]');
c = colorbar();
ylabel(c, 'proppant concentration [ppg]');

%%
% It still seems like there are a few points with frac fluid volumes that are
% too high.  I should really look these up and correct the collected data if
% possible.  They feel to me like they might have been experiments in
% low-proppant fractures, which isn't what I'm interested in for this analysis,
% so I'm going to exclude them.  Then this is what my engineering data set
% looks like:
tf_X_reject(X.frac_fluid > 3e5) = true;
h = figure();
h.Position = [h.Position(1)-h.Position(3), ...
              h.Position(2)-h.Position(4), ...
              2*h.Position(3),             ...
              2*h.Position(4)]; % make the figure bigger
gplotmatrix([X.length(~tf_X_reject), X.frac_fluid(~tf_X_reject),     ...
             X.proppant(~tf_X_reject), X.frac_stages(~tf_X_reject)], ...
            [], [], '', '.', [], 'off', 'hist',                      ...
            {'length','frac\_fluid','proppant','frac\_stages'});

%%
% You might be wondering about why there are so many wells with exactly 1 frac
% stage.  After some digging, I realized that the number of frac stages is
% often unreported; the company that collects this data for us just uses
% a default of 1.  We therefore cannot tell the difference between wells with
% 1 frac stage and wells with an unreported number of frac stages.  That will
% make frac_stages a challenge to analyze.  Consequently, I'm not going to do
% any frac_stages filtering and just analyze the other variables first.



%% 2(b) Missing data
% How should you deal with missing data (the NaN's in X and Y)?
%

%%
% Most real problems will involve some missing data.  Some systems use special
% codes (e.g. -1 or -9999) to denote missingness.  This is a _BAD_ idea.  If you
% take the mean of a column of positive numbers and there are a bunch of -9999
% values hiding in the data, it will skew your results.  It is MUCH better to
% use NaN (which stands for Not a Number) for missing data.  This is
% a perfectly valid floating point number that works differently from every
% other floating point number.  For more information, see the following:
% <https://www.mathworks.com/help/matlab/ref/nan.html>
%
% Examples:
NaN == NaN                   % NaN is the only number not equal to itself
isnan([-Inf, -3, 0, NaN, pi, +Inf])    % so you have to use the |isnan| function
isfinite([-Inf, -3, 0, NaN, pi, +Inf]) % or the |isfinite| function
[NaN < 0, NaN == 0, NaN > 0] % NaN doesn't compare to other numbers
NaN + 10                     % most arithmetic is NaN-in ==> NaN-out
mean([1,2,3,NaN])            % which means most arithmetic functions, too

%%
% *All missing data should be coded as NaN.*  However, I do not recommend
% changing outliers to NaN.  It's best to keep those in the data set and use
% logical arrays to mark the data that you want to use for any particular
% analysis.  For instance, I'm interested in predicting oil production for this
% problem, so for the rest of the analysis I'll only look at wells for which
% a valid oil production volume was listed (these are 365-day cumulative
% volumes, and many of the wells were still new when this data was pulled).
tf_Y_valid = Y.oil > 0;
mean(tf_Y_valid) % fraction of rows with a valid oil production volume

%%
% I could mark all of the rows in X that do not contain any NaNs.  However,
% that might not be appropriate for any particular analysis.  If I'm just
% trying to understand the distribution of one variable, I might not care
% whether or not a second variable is missing.  I might be analyzing Y as
% a function of just a few columns in X, in which case I wouldn't necessarily
% want to exclude rows that are missing data from columns that I'm ignoring.
% Finally, I might be using an analysis method that can handle rows with a few
% missing data points, in which case I probably want to keep them.  Just to
% illustrate the most blunt form of filtering, though:
tf_X_all_valid = all(isfinite(table2array(X)), 2) & ~tf_X_reject;
mean(tf_X_all_valid) % fraction of rows with all valid X values



%% 2(c) Do long wells produce more oil than short wells?
% For this analysis, I only care about valid oil production and valid well
% length.  Always start a problem by looking at the data:
tf = tf_Y_valid & isfinite(X.length);
figure();
gplotmatrix([X.length(tf), Y.oil(tf)], [], [], '', '.', [], 'off', 'hist', ...
            {'length', 'oil'});

%%
% First, what does it mean to be a short well vs. a long well?  We clearly have
% a bimodal distribution of well lengths, and I know that has to do with how
% big a standard lease is (long wells were drilled in double leases, short
% wells in single leases).  There isn't a precise cut-off, though.  We can
% start by picking an arbitrary dividing line and trying some of the hypothesis
% testing / confidence interval methods we've used over the past few weeks.
tf_short = (X.length <  7500);
tf_long  = (X.length >= 7500);
[h,p,ci] = ttest2(Y.oil(tf & tf_long), Y.oil(tf & tf_short), ...
                  'VarType','unequal', 'Alpha',0.05)

%%
% So long wells definitely tend to produce more than short wells, but not by as
% much as I would have expected.  Maybe the problem is that we have
% artificially introduced a binary classification, whereas the real system
% probably has some continuous, monotonic dependence on well length.  To solve
% a problem like this, we have to propose a *model* for oil production and look
% at the range of model parameters that are consistent with the data.  The
% simplest such model is *linear regression*:
mdl = fitlm(X.length(tf), Y.oil(tf))

%%
% We have proposed the *linear model* $Oil = \beta_0 + \beta_1 Length$ and have
% used the Matlab function |fitlm| to fit that model to our data.  We get an
% Estimate for each of the coefficients $\beta_i$, an estimated Standard Error
% for each of the coefficients, and a p-value telling us whether or not the
% coefficient is statistically significantly different from 0 (i.e. whether or
% not the effect we're trying to model is statistically significant).  In this
% case, the effect is highly significant:  the longer the well, the more oil we
% tend to produce, and we can even quantify an estimate and an uncertainty in
% that estimate for how much extra oil we tend to produce for every extra foot
% of well length.  However, the very low $R^2$ means that this is far from
% a complete model for production.  Well length alone does not determine total
% production.



%% 2(d) Which variables seem to be good predictors of oil production?
% We can easily add more terms to our linear model to get a
% *multivariate linear model*:
tf =   tf_Y_valid            & ~tf_X_reject                                  ...
     & isfinite(X.length)    & isfinite(X.frac_fluid) & isfinite(X.proppant) ...
     & isfinite(X.thickness) & isfinite(X.porosity)   & isfinite(X.oil_in_place);
tbl = horzcat(X(tf, {'length', 'frac_fluid', 'proppant', 'thickness', ...
                     'porosity','oil_in_place'}),                     ...
              Y(tf, 'oil'));
mdl = fitlm(tbl) % by default, the last variable in tbl is the response variable

%%
% First, note that our $R^2$ is much better.  Let's look at the fit:
figure();
plot(mdl.Fitted, tbl.oil, '.');
tmp = max([xlim(),ylim()]);
hold on;
plot([0,tmp], [0,tmp], '--');
xlabel('predicted oil production [bbls]');
ylabel('actual oil production [bbls]');
title(sprintf('multivariate linear model (N = %u, p = %u, R^2 = %0.1f%%)', ...
              mdl.NumObservations, mdl.NumCoefficients,                    ...
              mdl.Rsquared.Ordinary*100));

%%
% Second, note that most of our predictors are statistically significant (look
% at the pValue column).  Surprisingly, though, the well length is NOT
% significant in this model.  Explanation:  the well length is the amount of
% contact that the well has with the reservoir.  However, this is an extremely
% tight reservoir, so much so that we can't get any natural flow into the
% wellbore.  The proppant is actually creating the flow paths through which we
% get production.  We drill longer wells so that we can inject more proppant.
% Our earlier result is still true that longer wells tend to produce more;
% however, that explanation was incomplete because the well length was just our
% univariate proxy for the truly important quantities (proppant and
% fracture fluid).  This model is much better because we can say, for a fixed
% length of well, how much extra production we will tend to get for each
% additional pound of proppant, along with our uncertainty in that estimate:
mdl.Coefficients('proppant',:)

%%
% A very common question is, "Which variables are most important?"  This is
% a natural question to ask, but it isn't well defined.  We certainly can't
% just compare the coefficients because they all have different units.
% Also, important for what?  It only makes sense in the context of a business
% problem, each of which comes with its own set of restrictions or ranges of
% interest for the variables.  For example, the variables that are important
% when you've already chosen a drilling location are very different from the
% variables that are important when you're comparing acreage.
%
% "I understand," you're probably thinking, "but I still want to know which
% variables are most important."  Fine.  One way to do it is by defining
% "importance" in the context of the total range of all of the variables.
% Conceptually, I could rescale each variable so that they are unitless and all
% values are between 0 and 1.  Then the coefficients all have the same units
% and are directly comparable; the coefficients with bigger absolute values
% appear to be more important over the entire range of values in the data set.
% A slightly better way to accomplish the same thing is to convert each column
% (individually) to the number of standard deviations away from the mean.  This
% is easy using Matlab's |zscore| function.  Note that the resulting model has
% exactly the same $R^2$ and exactly the same p-values; all that has changed is
% the units of the coefficients (and the intercept, which is now exactly
% 0 because the oil column has also been recentered around its mean).
tbl_unitless = array2table(zscore(tbl{:,:}), ...
                           'VariableNames',tbl.Properties.VariableNames);
mdl_unitless = fitlm(tbl_unitless)
figure();
plot(mdl_unitless.Fitted, tbl_unitless.oil, '.');
tmp1 = min([xlim(),ylim()]);
tmp2 = max([xlim(),ylim()]);
hold on;
plot([tmp1,tmp2], [tmp1,tmp2], '--');
xlabel('predicted oil production [centered & scaled]');
ylabel('actual oil production [centered & scaled]');
title(sprintf('multivariate linear model (N = %u, p = %u, R^2 = %0.1f%%)', ...
              mdl_unitless.NumObservations, mdl_unitless.NumCoefficients,  ...
              mdl_unitless.Rsquared.Ordinary*100));

% This comes up so often that I wrote my own function to plot the variable
% importances.  It is called, appropriately enough, |variable_importance.m|.
% Feel free to use it for your own work.
if exist('variable_importance', 'file') == 2
    % Plot the variable importances.  Skip the first variable (the intercept)
    % because no one really cares about it, and it is exactly 0 here anyway.
    % Multiply the SE by 1.96 to plot 95% confidence intervals for each
    % coefficient.  Make sure to plot bad variables in red and good variables
    % in green.
    variable_importance(mdl_unitless.Coefficients.Estimate(2:end),  ...
                        mdl_unitless.CoefficientNames(2:end),       ...
                        mdl_unitless.Coefficients.SE(2:end) * 1.96, ...
                        true);
    xlabel('variable importance [unitless]');
    title('multivariate linear model for oil production');
end



%% 2(e) What's more important for oil production, geology or engineering?
% From the last part of 2(d), we see that oil-in-place is the most important
% variable.  A more thorough answer can be found by building geology-only and
% engineering-only models.  At a field-wide scale, knowing the geology allows
% us to make much more accurate predictions of oil production than knowing the
% engineering:
tbl_eng = horzcat(X(tf, {'length', 'frac_fluid', 'proppant'}), ...
                  Y(tf, 'oil'));
mdl_eng = fitlm(tbl_eng)

tbl_geo = horzcat(X(tf, {'thickness', 'porosity','oil_in_place'}), ...
                  Y(tf, 'oil'));
mdl_geo = fitlm(tbl_geo)
