function [X_train, Y_train, X_test, Y_test] = zip_import()
%ZIP_IMPORT    Import the zip code digit data sets
    train_data = load('zip.train', '-ascii');
    X_train    = train_data(:, 2:end);
    Y_train    = train_data(:, 1);

    test_data = load('zip.test', '-ascii');
    X_test    = test_data(:, 2:end);
    Y_test    = test_data(:, 1);
end % zip_import()
