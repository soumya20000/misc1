%%  Simple Bayesian Models
% 1. Medical tests aren�t as useful as doctors think
%
% a.  Suppose that 1% of the population has a particular disease.  Your doctor
%     routinely tests all patients for this disease whether or not they have
%     any symptoms.  The test has a 1% false positive rate and
%     a 1% false negative rate.  In other words, 1% of people who do not have
%     the disease will (randomly and falsely) test positive for it, and
%     1% of people with the disease will (randomly and falsely) test negative
%     for it.  Now suppose that your test comes back positive.  What is the
%     probability that you really do have that disease?
%
% b.  Why are medical associations debating the idea of INCREASING the age at
%     which to begin routine cancer screenings?
%
% 2.  Small field trials can be more informative than you might think:
%
% a.  Suppose we test a new hydraulic fracturing procedure using a randomized
%     field trial.  The old procedure has been used extensively; the mean
%     production from these wells is 100 kbbls, and the standard deviation is
%     10 kbbls.  The new procedure is used on three wells that produce
%     95, 110, and 115 kbbls.  Using what we�ve discussed so far, would you
%     say that the new procedure is definitely better than the old procedure,
%     or might the results just be due to chance and small sample sizes?
%     [Hint:  the z-test is more appropriate here than the t-test.]
%
% b.  Now suppose that this isn�t a new procedure.  We�ve tried this same
%     procedure in dozens of fields before.  In half of the historical fields,
%     the new procedure tended to increase production by 10%.  In the other
%     half of the historical fields, the new procedure tended to decrease
%     production by 10%.  Give this prior information and the same three-well
%     experiment above, do you think this is the kind of field in which the
%     new procedure increases or decreases production?  What probabilities
%     would you assign to these two possibilities?


%% Part 1(a) Using Bayes' Theorem
% Let $TEST$ be the random variable representing your response to the test that
% the doctor orders.  If you test positive for the disease, then
% $TEST=positive$, whereas if you test negative for the disease, then
% $TEST=negative$.  This is truly a random variable, at least according to the
% probabilistic model we have assumed for test errors.
%
% Let $TRUE$ be the random variable representing your true medical state.  If
% you have the disease, then $TRUE=positive$, and if you do not have the
% disease, then $TRUE=negative$.  We would not normally think of this as
% a random variable.  There isn't really a probability here; you either have
% the disease or you don't.  In the Bayesian world, though, we treat uncertain
% quantities as random variables, and we rigorously treat our uncertainties in
% them as probability distributions.  In this context, we start with large
% uncertainties about whether or not you have the disease, and we wish to
% update those uncertainties in light of the test results.
%
% What do we know before the test occurs?  The only information available is
% the background occurrence rate of the disease.  Without more information,
% there is no reason to believe that you are any more or less likely than
% anyone else to have that disease.  Therefore:
%
% $P(TRUE=positive) \equiv \pi_p = 0.01$.
%
% In Bayesian jargon, this is called our *prior* probability for having the
% disease.  As above, it is often denoted $\pi$ rather than $P$, but it is
% treated like any other probability distribution.  Therefore
%
% $P(TRUE=negative) \equiv \pi_n = 1-P(TRUE=positive) = 1 - \pi_p = 0.99$.
prior_positive = 0.01;
prior_negative = 1 - prior_positive;

%%
% What do we know about the tests?  We are given the false positive and the
% false negative rates.  These can be translated into conditional
% probabilities.  For the *false positive rate (fpr)*:
%
% $P(TEST=positive | TRUE=negative) \equiv fpr = 0.01$
%
% and thus the *true negative rate (tnr)*:
%
% $P(TEST=negative | TRUE=negative) \equiv tnr = 1 - P(TEST=positive | TRUE=negative) = 1 - fpr = 0.99$.
fpr = 0.01;
tnr = 1 - fpr;

%%
% Similarly, for the *false negative rate (fnr)*:
%
% $P(TEST=negative | TRUE=positive) \equiv fnr = 0.01$
%
% and the *true positive rate (tpr)*:
%
% $P(TEST=positive | TRUE=positive) \equiv tpr = 1 - P(TEST=negative | TRUE=positive) = 1 - fnr = 0.99$.
fnr = 0.01;
tpr = 1 - fnr;

%%
% Now we can update our prior knowledge in light of the test results using
% *Bayes' Theorem*
% <https://en.wikipedia.org/wiki/Bayes%27_theorem [Wikipedia]>.
% This gives us a *posterior* probability distribution for our true medical
% state.  For example:
%
% $P(TRUE=positive | TEST=positive) = P(TEST=positive | TRUE=positive) P(TRUE=positive) / P(TEST=positive)$.
%
% As is common with Bayesian analysis, the denominator takes some work to
% compute.  In simple cases like this, we can use the
% *law of total probability*
% <https://en.wikipedia.org/wiki/Law_of_total_probability [Wikipedia]>:
%
% $P(TEST=positive) = P(TEST=positive|TRUE=positive)P(TRUE=positive) + P(TEST=positive|TRUE=negative)P(TRUE=negative)$
%
% Putting these together, we get
%
% $P(TRUE=positive | TEST=positive) = tpr\cdot\pi_p / [tpr\cdot\pi_p + fpr\cdot\pi_n)$.
posterior_positive_given_testnegative ...
    = tpr*prior_positive / (tpr*prior_positive + fpr*prior_negative);
disp(posterior_positive_given_testnegative);



%% Part 1(a) Using Frequency Tables
% You can always use Bayes' Theorem directly and work through all of the
% algebra, as above.  However, it can be more intuitive to think in terms of
% frequency tables.  With this approach, we compute the fraction of people who
% fit every combination of TRUE and TEST.  We arrange these computations into
% a 2-by-2 table, and then we add a third row and column for the totals.  We
% start with an empty table:
freq_table = array2table(NaN(3,3), ...
                         'VariableNames',{'TRUE_positive', ...
                                          'TRUE_negative', ...
                                          'sum'},          ...
                         'RowNames',{'TEST_positive', 'TEST_negative', 'sum'});
disp(freq_table);

%%
% Everyone must fit into exactly one row and exactly one column.  The sum of
% the column sums and the sum of the row sums must therefore both equal 1.
freq_table{'sum','sum'} = 1;
disp(freq_table);

%%
% We know that 1% of the people have the disease, so the TRUE_positive column
% must sum to 0.01.
freq_table{'sum','TRUE_positive'} = prior_positive;
disp(freq_table);

%%
% We have already established that the sum of the column sums must equal 1, and
% we filled in the TRUE_positive column sum above, so we can compute the
% TRUE_negative column sum by subtraction.
freq_table{'sum','TRUE_negative'} = 1 - freq_table{'sum','TRUE_positive'};
disp(freq_table);

%%
% The false positive rate is the fraction of people who are TRUE negatives who
% will TEST positive.  We have already set the total fraction of people who are
% TRUE negatives, so we just need to multiply that total by the rate of
% false positives to fill in the TEST_positive x TRUE_negative cell.
freq_table{'TEST_positive','TRUE_negative'} = fpr * freq_table{'sum','TRUE_negative'};
disp(freq_table);

%%
% We now know one of the cells of the TRUE_negative column, and we know what
% those cells must sum to, so we can fill in the remaining cell of that column
% by subtraction.
freq_table{'TEST_negative','TRUE_negative'} = freq_table{'sum','TRUE_negative'} - freq_table{'TEST_positive','TRUE_negative'};
disp(freq_table);

%%
% Similarly, the false negative rate is the fraction of people who are
% TRUE positives who will TEST negative.  We have already set the total
% fraction of people who are TRUE positives, so we just need to multiply that
% total by the rate of false negatives to fill in the
% TEST_negative x TRUE_positive cell.
freq_table{'TEST_negative','TRUE_positive'} = fnr * freq_table{'sum','TRUE_positive'};
disp(freq_table);

%%
% We now know one of the cells of the TRUE_positive column, and we know what
% those cells must sum to, so we can fill in the remaining cell of that column
% by subtraction.
freq_table{'TEST_positive','TRUE_positive'} = freq_table{'sum','TRUE_positive'} - freq_table{'TEST_negative','TRUE_positive'};
disp(freq_table);

%%
% Finally, we know all four of the upper-left cells, so we can fill in the row
% totals by summing.
freq_table{'TEST_positive','sum'} = freq_table{'TEST_positive','TRUE_positive'} + freq_table{'TEST_positive','TRUE_negative'};
freq_table{'TEST_negative','sum'} = freq_table{'TEST_negative','TRUE_positive'} + freq_table{'TEST_negative','TRUE_negative'};
disp(freq_table);

%%
% Now that the cell is complete, we can compute any posterior probability.
% For example, the probability that you are a TRUE positive given that your
% TEST came back positive is just the fraction of people who are TRUE positives
% _and_ TEST positives, divided by the _total_ fraction of people who
% TEST positive.
posterior_positive_given_testnegative ...
    = freq_table{'TEST_positive','TRUE_positive'} / freq_table{'TEST_positive','sum'};
disp(posterior_positive_given_testnegative);



%% Part 1(b)
% So why would we want to wait until people are older to start routinely
% testing them for this disease?  The reason is that we do not want to treat
% people who do not _actually_ have the disease.  In other words, we want to
% reduce the rate of false negatives.  The test won't change, but the prior
% probability of having the disease will increase as a function of age, so the
% posterior probability of false negatives will decrease.
prior_positive = 0.01;
prior_negative = 1 - prior_positive;
posterior_negative_given_testpositive ...
    = fpr*prior_negative / (tpr*prior_positive + fpr*prior_negative);
fprintf(strcat('When the prior probability of TRUE positives is %.2f,\n',   ...
               '  the posterior probability of false negatives is %.2f\n'), ...
        prior_positive, posterior_negative_given_testpositive);

prior_positive = 0.02;
prior_negative = 1 - prior_positive;
posterior_negative_given_testpositive ...
    = fpr*prior_negative / (tpr*prior_positive + fpr*prior_negative);
fprintf(strcat('When the prior probability of TRUE positives is %.2f,\n',   ...
               '  the posterior probability of false negatives is %.2f\n'), ...
        prior_positive, posterior_negative_given_testpositive);



%% Part 2(a)
% We have used the t-test for questions like this in the past.  In those cases,
% we had two relatively small samples that we wanted to compare against each
% other.  In this case, I have one very small sample that I want to compare
% against a big population that I'm not going to sample.  A single-sample
% t-test would be fine, but I'd rather assume that the new procedure doesn't
% affect the standard deviation at all, in which case I can assume that
% I _know_ the standard deviation and use the z-test instead.  This allows for
% a sharper test, which is pretty important for such a small sample.
[~,p_value,confidence_interval,~] = ztest([95,110,115], 100, 10)


%%
% So, even our sharper test is pretty far from statistical significance.



%% Part 2(b)
% This calls for Bayes' Theorem.  Let $H$ be the binary random variable that
% indicates whether or not the new procedure is helpful in the current field.
% So $H=true$ if the new procedure increases production here, and $H=false$ if
% the new procedure decreases production here.  Our prior on $H$ is:
%
% $P(H=true) = P(H=false) = 0.5$.
prior_true = 0.5;
prior_false = 1 - prior_true;


%%
% Let $X$ be the random variable equal to production from a new well.
% A reasonable probabilistic model for $X$ given the wording of the problem
% would be:
%
% $(X | H=true) \sim N(110, 10^2)$
%
% and
%
% $(X | H=false) \sim N(90, 10^2)$ .
%
% In other words, $X$ is a Gaussian random number with standard deviation 10.
% If the new procedure is helpful, then the mean value of $X$ is 110, but if
% the new procedure is not helpful, then the mean value of $X$ is 90.
%
% $X$ is a continuous rather than discrete random variables.  However, we
% can still use the probability density to perform the Bayesian calculations.
% In this case, we treat the three production figures as independent draws from
% $X$.
p_x_given_h_true  = prod(normpdf([95,110,115], 110, 10));
p_x_given_h_false = prod(normpdf([95,110,115],  90, 10));


%%
% By Bayes' Theorem,
%
% $P(H=true|X) = P(X|H=true)P(H=true) / P(X)$
%
% and
%
% $P(H=false|X) = P(X|H=false)P(H=false) / P(X)$ .
%
% As usual, the denominator is a pain to calculate.  We can use the law of
% total probability, but I'd rather demonstrate a common Bayesian trick.
% Notice that the denominator is the _same_ for both expressions above, i.e. it
% does not depend on $H$.  Since those two probabilities must add to 1, we can
% compute them both _without_ their denominators and then normalize them to sum
% to 1.  We therefore manage to compute the probabilities exactly without ever
% having to explicitly compute the denominators.
posterior_true_numerator  = p_x_given_h_true  * prior_true;
posterior_false_numerator = p_x_given_h_false * prior_false;
posterior_true  = posterior_true_numerator / (posterior_true_numerator + posterior_false_numerator)
posterior_false = posterior_false_numerator / (posterior_true_numerator + posterior_false_numerator)


%%
% Notice, then, that if we account for prior information, even a small, noisy
% sample can yield strong results.
