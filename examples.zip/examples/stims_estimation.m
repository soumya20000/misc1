%% Well Stimulation Example
% The STIMS.XLSX spreadsheet contains information about most of the
% *well stimulations* that have been performed at a particular
% producing unit (PU).  The PU has wells spread across 6 different *fields*,
% which are several kilometers apart so may be geologically different.  As
% production starts to decline, the wells are stimulated by pumping fluid down
% the tubing and into the reservoir rock, hopefully removing any sand that
% might be blocking the flowpath of hydrocarbons into the wellbore.  There are
% three basic kinds of fluids or *stim types* used: a low salinity brine,
% a high salinity brine, and an enhanced fluid which is diesel-based rather
% than water-based.  The *uplift* is the average production rate (in bbls/day)
% after the stimulation minus the average production rate before the
% stimulation.  Yes, some of the wells have negative uplifts, which means that
% the stimulation did more harm than good.
%
% The business wants to know if they should use more high salinity and/or
% enhanced stimulations in the future.  What would you tell them if this were
% the only data you had?
%
% Last time we discussed *hypothesis testing*, which tells us how plausible it
% would be to assume that the average uplifts of the different stim types are
% the same.  That's not a practical question, though, because we need to be
% able to say whether or not the expected profit from the uplift will be worth
% the costs of the stimulation.  This requires *estimation* of
% how much more uplift we expect to get from one stim type vs. another.


%% Data Import
%#ok<*NOPTS>
%#ok<*NASGU>
%#ok<*ASGLU>
stims_import;



%% Classical Statistical Methods for Estimation

%%
% If all you want to know is, "How much more Uplift do we get from HighSalinity
% StimTypes on average than LowSalinity StimTypes?", then we can translate this
% question into one line of Matlab:
quickest_answer =   mean(X.Uplift(X.StimType == 'HighSalinity')) ...
                  - mean(X.Uplift(X.StimType == 'LowSalinity'))

%%
% However, it isn't quite that simple.  There is an enormous spread in the
% Uplift data for each StimType:
grpstats(X(:,{'Uplift','StimType'}), 'StimType', {'mean','std'})

%%
% It's possible that the StimTypes don't really have different effects on
% Uplift, but that their different means are just the result of the scatter in
% the data.  When we plot the data, it is not visually obvious that one
% StimType is systematically better than any other.
figure();
boxplot(X.Uplift, X.StimType);
xlabel('StimType');
ylabel('Uplift');

%%
% A better question to ask is, "Given that I have noisy data sets, what is the
% range of values that could plausibly approximate the true difference in their
% means?"  The most widely used tool to answer such questions is the
% *2-sample t-test*.
%
% *DATA ANALYTICS NOTE*:  Unless you have a _really_ small data set, you
% should set |VarType| to |unequal|.  This means that you _do not_ want to
% assume that the variance of the two samples is the same.  The resulting
% confidence interval will be more accurate (in the statistical sense).
[~,~,ci,~] = ttest2(X.Uplift(X.StimType == 'HighSalinity'), ...
                    X.Uplift(X.StimType == 'LowSalinity'),  ...
                    'VarType','unequal', 'Alpha',0.05)

%%
% This week, we only care about the practical problems of estimating the
% average difference between the stim types and quantifying our uncertainty
% therein.  This is given by the 95% *confidence interval*
% (|ci|; 95% because we chose |Alpha=0.05|).
% Thus, the data is consistent with the assertion that
% HighSalinity StimTypes generate Uplifts that are, on average,
% between 1 and 25 bbls/day greater than Uplifts from LowSalinity StimTypes.
%
% As with hypothesis testing, though, the t-test makes strong assumptions about
% the probability distributions of the data in order to derive an analytic
% formula for the confidence interval.  We can check this assumption with an
% *Anderson-Darling* test:
[h,p] = adtest(X.Uplift(X.StimType == 'LowSalinity'))
[h,p] = adtest(X.Uplift(X.StimType == 'HighSalinity'))

%%
% Or more simply with a graphical check via a *Q-Q plot*:
figure();
qqplot(X.Uplift(X.StimType=='LowSalinity'));
title('QQ Plot of LowSalinity Uplifts vs. Standard Normal');
figure();
qqplot(X.Uplift(X.StimType=='HighSalinity'));
title('QQ Plot of HighSalinity Uplifts vs. Standard Normal');

%%
% Neither sample is even close to being normally distributed.  The t-test is
% known to be robust to deviations from the assumptions, but these are pretty
% big deviations.



%% Modern Computational Methods for Estimation
% As stated above, we just want to estimate how much more Uplift we are likely
% to get with HighSalinity StimTypes.  We do not care about what kind of
% distribution fits the Uplift data best, and I don't want to tell my boss that
% "this is the difference if I assume the true distribution is Gaussian."
%
% There is a better way.  The t-test assumes that the data came from a normally
% distributed population and then uses analytical formulas that may be derived
% from this assumption.  We know that our "true" populations (if such a concept
% is even well defined) are never exactly Gaussian.  If we knew the true
% distribution, we could use Monte Carlo (like in Week 1) to estimate the mean
% value and quantify our uncertainty in it.  We do not know the _true_
% distribution, but we have a very good _approximation_ for it:  the _observed_
% distribution.
%
% *Bootstrapping*
%
% The bootstrap is just a Monte Carlo simulation for the statistic of interest
% using a histogram of the observed data as an approximation for the true
% distribution from which the observed data was drawn.  Random sampling from
% this histogram is equivalent to random sampling with replacement from the
% original data set.  More concretely:
%
% # Define a *statistic*, the quantity that you are trying to estimate.
% # Randomly draw a sample, _with replacement_, from your data.  The random
% sample must be _the same size_ as the original data set, so there will be
% duplicates.  Compute the statistic on this sample.
% # Repeat this process a number of times.  A published rule of thumb is to use
% 10,000 bootstrap samples if the process isn't too computationally expensive.
% # Define a confidence level (usually 95%).  Set $\alpha$ so that the
% confidence percentage is equal to $100(1-\alpha)$.
% # Define your *percentile bootstrap confidence interval* estimate for the
% statistic as the interval between the $100(\alpha/2)$ and $100(1-\alpha/2)$
% percentiles of the bootstrapped statistic.

% Define the statistic
stat_fun = @(sample1, sample2)( mean(sample1) - mean(sample2) );

% Define the significance level
alpha = 0.05

% Perform the Monte Carlo simulation to get the distribution of the test
% statistic under the null hypothesis
uplifts_LowSalinity  = X.Uplift(X.StimType == 'LowSalinity');
uplifts_HighSalinity = X.Uplift(X.StimType == 'HighSalinity');
num_simulations = 1e4;
bootstrap_statistics = NaN(num_simulations, 1);
for s=1:num_simulations
    bootstrap_sample_LowSalinity  = randsample(uplifts_LowSalinity,        ...
                                               numel(uplifts_LowSalinity), ...
                                               true); % WITH replacement
    bootstrap_sample_HighSalinity = randsample(uplifts_HighSalinity,        ...
                                               numel(uplifts_HighSalinity), ...
                                               true); % WITH replacement
    bootstrap_statistics(s) = stat_fun(bootstrap_sample_HighSalinity, ...
                                       bootstrap_sample_LowSalinity);
end

% Compute the statistic on the observed data
observed_statistic = stat_fun(uplifts_HighSalinity, uplifts_LowSalinity);

% Examine the bootstrapped statistics and the observed value graphically.
figure();
histogram(bootstrap_statistics);
hold on;
plot(observed_statistic + [0,0], ylim(), '--k', 'LineWidth',2);
yl = ylim();
confidence_limits = prctile(bootstrap_statistics, ...
                            [100*(alpha/2),100*(1-alpha/2)])
patch([confidence_limits(1) confidence_limits(2) confidence_limits(2) confidence_limits(1)], ...
      [yl(1)                yl(1)                yl(2)                yl(2)],                ...
      'g', 'LineStyle','none', 'FaceAlpha',0.2);
xlabel('bootstrapped statistic');
set(gca, 'YTickLabel',{});
title('Percentile Bootstrap for mean(HS) - mean(LS)');


%%
% The bootstrap is great because:
%
% # It is *non-parametric*, i.e. it does not require that we fit the data to
% some standard probability distribution.
% # It does not require any model assumptions.
% # It is easy to understand and apply.
% # It generates a full distribution for your estimator rather than just an
% estimator and a standard deviation or an estimator and a confidence interval.
% # It can be used without change for any statistic of interest (whereas there
% are hundreds of classical formulae for confidence intervals under different
% assumptions).
%
% To demonstrate the last point, notice that our bootstrap confidence interval
% is very close to the t-test confidence interval.  This is because we used the
% mean as our statistic of interest and because the t-test is relatively robust
% to deviations from its assumptions.  However, there are a few big outliers in
% our data, and we know that big outliers can skew the mean.  What if the
% apparent difference between LowSalinity and HighSalinity StimTypes is not due
% to random scatter but rather to a small number of outliers?  We can test this
% by using the *median*, which is much more robust than the mean.  We can
% use the _exact same code_ as above with a different |stat_fun|.

% Define the statistic
stat_fun = @(sample1, sample2)( median(sample1) - median(sample2) );

% Define the significance level
alpha = 0.05

% Perform the Monte Carlo simulation to get the distribution of the test
% statistic under the null hypothesis
uplifts_LowSalinity  = X.Uplift(X.StimType == 'LowSalinity');
uplifts_HighSalinity = X.Uplift(X.StimType == 'HighSalinity');
num_simulations = 1e4;
bootstrap_statistics = NaN(num_simulations, 1);
for s=1:num_simulations
    bootstrap_sample_LowSalinity  = randsample(uplifts_LowSalinity,        ...
                                               numel(uplifts_LowSalinity), ...
                                               true); % WITH replacement
    bootstrap_sample_HighSalinity = randsample(uplifts_HighSalinity,        ...
                                               numel(uplifts_HighSalinity), ...
                                               true); % WITH replacement
    bootstrap_statistics(s) = stat_fun(bootstrap_sample_HighSalinity, ...
                                       bootstrap_sample_LowSalinity);
end

% Compute the statistic on the observed data
observed_statistic = stat_fun(uplifts_HighSalinity, uplifts_LowSalinity);

% Examine the bootstrapped statistics and the observed value graphically.
figure();
histogram(bootstrap_statistics);
hold on;
plot(observed_statistic + [0,0], ylim(), '--k', 'LineWidth',2);
yl = ylim();
confidence_limits = prctile(bootstrap_statistics, ...
                            [100*(alpha/2),100*(1-alpha/2)])
patch([confidence_limits(1) confidence_limits(2) confidence_limits(2) confidence_limits(1)], ...
      [yl(1)                yl(1)                yl(2)                yl(2)],                ...
      'g', 'LineStyle','none', 'FaceAlpha',0.2);
xlabel('bootstrapped statistic');
set(gca, 'YTickLabel',{});
title('Percentile Bootstrap for median(HS) - median(LS)');


%%
% Another important point is that since the bootstrap is just a Monte Carlo
% simulation, we can easily accomodate much more complex scenarios.  For
% instance, so far we have assumed that the Uplift measurements are exact.  In
% practice, we might want to explicitly account for measurement errors.  For
% this we need some model for measurement error.  A common assumption is that
% the error is a random Gaussian with mean 0 (we need to study the physical
% system and the data to get the variance of the noise).
%
% Let's go back to using the difference between the means of the samples.
% Suppose the "uncertainty" in the Uplift for LowSalinity stimulations is
% +/- 10 bbls/day, and the "uncertainty" in the Uplift for the HighSalinity
% stimulations is +/- 25 bbls/day (this is an _extremely_ artificial example).
% Then we can add random noise to every bootstrap sample, and our results will
% give us confidence intervals that appropriately account for measurement
% noise.
%
% Notice that in this case, even relatively large measurement noises do not
% affect our confidence much.  The reason is because we're taking the mean of
% a pretty large sample, so the noises tend to cancel each other out.
% Measurement noise can be important when you have small samples, non-Gaussian
% noise models, or weird statistics that you're interested in.  We will revisit
% measurement noise later when we study prediction intervals.

% Define the statistic
stat_fun = @(sample1, sample2)( mean(sample1) - mean(sample2) );

% Define the significance level
alpha = 0.05

% Perform the Monte Carlo simulation to get the distribution of the test
% statistic under the null hypothesis
uplifts_LowSalinity  = X.Uplift(X.StimType == 'LowSalinity');
uplifts_HighSalinity = X.Uplift(X.StimType == 'HighSalinity');
num_simulations = 1e4;
bootstrap_statistics = NaN(num_simulations, 1);
for s=1:num_simulations
    bootstrap_sample_LowSalinity  =   randsample(uplifts_LowSalinity,        ...
                                                 numel(uplifts_LowSalinity), ...
                                                 true)                       ...
                                    + 10*randn(size(uplifts_LowSalinity));
    bootstrap_sample_HighSalinity =   randsample(uplifts_HighSalinity,       ...
                                                 numel(uplifts_HighSalinity),...
                                                 true)                       ...
                                    + 25*randn(size(uplifts_HighSalinity));
    bootstrap_statistics(s) = stat_fun(bootstrap_sample_HighSalinity, ...
                                       bootstrap_sample_LowSalinity);
end

% Compute the statistic on the observed data
observed_statistic = stat_fun(uplifts_HighSalinity, uplifts_LowSalinity);

% Examine the bootstrapped statistics and the observed value graphically.
figure();
histogram(bootstrap_statistics);
hold on;
plot(observed_statistic + [0,0], ylim(), '--k', 'LineWidth',2);
yl = ylim();
confidence_limits = prctile(bootstrap_statistics, ...
                            [100*(alpha/2),100*(1-alpha/2)])
patch([confidence_limits(1) confidence_limits(2) confidence_limits(2) confidence_limits(1)], ...
      [yl(1)                yl(1)                yl(2)                yl(2)],                ...
      'g', 'LineStyle','none', 'FaceAlpha',0.2);
xlabel('bootstrapped statistic');
set(gca, 'YTickLabel',{});
title('Percentile Bootstrap for median(HS) - median(LS)');



%% Matlab's Built-In Bootstrap Functionality
% What we described above is actually just one form of the bootstrap called
% the *percentile bootstrap*.  There are other ways to do the bootstrap that
% tend to be more accurate ("accuracy" is a confusing concept in this context,
% so we won't go into what that really means).  These include the
% *studentized bootstrap* and the
% *bias-corrected and accelerated (BCa) bootstrap*.
% Note that I'm using $10^5$ samples rather than the recommended $10^4$ just
% for demonstration purposes; I want to make sure that the differences we see
% in this section arise just from the different bootstrap methods, not from
% random noise due to Monte Carlo simulation.
tf = (X.StimType == 'HighSalinity') & (X.Field == 'Bolobo');
figure();
histogram(X.Uplift(tf));
xlabel('Uplift from HighSalinity stimulations in Bolobo');

%%
% Use *|bootstrp|* to do the full bootstrap sampling.
bootstat = bootstrp(1e5, @mean, X.Uplift(tf));
figure();
histogram(bootstat);
hold on;
yl = ylim();
plot(mean(X.Uplift(tf))+[0,0], yl, '--k', 'LineWidth',2);
confidence_limits = prctile(bootstat, [100*(alpha/2),100*(1-alpha/2)]);
patch([confidence_limits(1) confidence_limits(2) confidence_limits(2) confidence_limits(1)], ...
      [yl(1)                yl(1)                yl(2)                yl(2)],                ...
      'g', 'LineStyle','none', 'FaceAlpha',0.2);
xlabel('bootstrap sampling distribution of mean HighSalinity Uplift in Bolobo');
set(gca, 'YTickLabel',{});
ci_boot_percentile = confidence_limits

%%
% Use *|bootci|* to get more accurate confidence intervals than the above.
ci_boot_bca = bootci(1e5, {@mean, X.Uplift(tf)}, ...
                     'alpha',0.05, 'type','bca') % these are the defaults

%%
% Note that |bootci| could also be used to generate the (less accurate)
% percentile bootstrap estimate that we derived above using |bootstrp|.
ci_boot_percentile = bootci(1e5, {@mean, X.Uplift(tf)}, ...
                            'alpha',0.05, 'type','percentile')

%%
% We can compare these results with what we would get from classical
% statistical methods:
[~,~,ci_ttest,~] = ttest(X.Uplift(tf), 0, 'Alpha',0.05)

%%
% We can further demonstrate by looking at problem 2, which asks for
% estimates and uncertainties in the probabilities of getting more than
% 50 bbls/day in uplift.
%
% *MATLAB NOTE*:  |mean(sample > 50)| is Matlab shorthand for the number of
% samples greater than 50, divided by the total number of samples.  To see
% this, note that |sample| is an array of floating point numbers, so
% |sample > 50| is an array of booleans (|true| or |false|) of the same size as
% |sample|.  In Matlab (and most programming languages), |false| evaluates to
% 0 when included in a numerical expression, and |true| evaluates to 1.  So
% |sum(sample > 50)| is the number of samples greater than 50, and
% |mean(sample > 50)| is the average truth value, which is just the fraction of
% the samples that are greater than 50.
stat_fun = @(sample)( 100 * mean(sample > 50) );
for st={'LowSalinity', 'HighSalinity', 'Enhanced'}
    uplifts = X.Uplift(X.StimType == st{1});
    bootstat = bootstrp(1e4, stat_fun, uplifts);
    figure();
    histogram(bootstat);
    hold on;
    yl = ylim();
    plot(stat_fun(uplifts)+[0,0], yl, '--k', 'LineWidth',2);
    confidence_limits = prctile(bootstat, [100*(alpha/2),100*(1-alpha/2)]);
    patch([confidence_limits(1) confidence_limits(2) confidence_limits(2) confidence_limits(1)], ...
          [yl(1)                yl(1)                yl(2)                yl(2)],                ...
          'g', 'LineStyle','none', 'FaceAlpha',0.2);
    xlabel('probability [%] of >50 bbls/day uplift');
    title(sprintf('%s\nbootstrap 95%% confidence interval (%.1f,%.1f)', ...
                  st{1}, confidence_limits(1), confidence_limits(2)));
    set(gca, 'YTickLabel',{});
end

%%
% We can compare these results with what we would have gotten from classical
% statistical methods, as well.  In this case, I just happen to know that the
% estimator for a probability is approximately Gaussian with mean $p$ and
% variance $p(1-p)/N$.
for st={'LowSalinity', 'HighSalinity', 'Enhanced'}
    uplifts = X.Uplift(X.StimType == st{1});
    p = stat_fun(uplifts) / 100;
    N = numel(uplifts);
    variance = p * (1 - p) / N;
    confidence_limits = 100 * [p - 1.96*sqrt(variance), p + 1.96*sqrt(variance)];
    fprintf('%s\nclassical 95%% confidence interval (%.1f,%.1f)\n\n', ...
            st{1}, confidence_limits(1), confidence_limits(2));
end

%%
% *QUESTION FOR YOU*:  Why are the HighSalinity and Enhanced histograms above
% so ugly?  There is a reason.
