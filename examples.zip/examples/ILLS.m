classdef ILLS < handle
%ILLS    Interactive Linear Least Squares
%    This class provides a GUI for experimenting with least squares linear fits
%    and their residuals.  To get started, type ILLS at the Matlab prompt and
%    click Help on the menu bar.

    properties
        hfig; % handle to figure window
        xs;   % x-coordinates of current data points
        ys;   % y-coordinates of current data points
    end % properties


    methods % public

        function obj = ILLS()
        %ILLS    Object constructor

            % Create the figure window
            obj.hfig = figure('Units','pixels', 'Position',[100 100 750 550],...
                              'Toolbar','none', 'MenuBar','none',            ...
                              'NumberTitle','off',                           ...
                              'Name','Interactive Linear Least Squares',     ...
                              'CloseRequestFcn',@(src,event)(delete(obj)));
            uimenu(obj.hfig, 'Label','Help', ...
                   'Callback',@(src,event)obj.cb_help(src,event));

            % Create the two sets of axes
            ha_data = axes('Parent',obj.hfig,                             ...
                           'Units','pixels', 'Position',[50 275 300 250], ...
                           'Box','on', 'XLim',[3 20], 'YLim',[2 13],      ...
                           'Tag','data', 'ButtonDownFcn',                 ...
                           @(src,event)obj.cb_click(src,event));
            title( ha_data, 'Data');
            xlabel(ha_data, 't'); % the slides use 't' instead of 'x'
            ylabel(ha_data, 'y');
            ha_res = axes('Parent',obj.hfig,                              ...
                          'Units','pixels', 'Position',[425 275 300 250], ...
                          'Box','on', 'XLim',[3 20], 'YLim',[-4 +4],      ...
                          'Tag','residuals');
            title( ha_res, 'Residuals');
            xlabel(ha_res, 't');
            ylabel(ha_res, 'r');

            % Create the panel containing the data set information
            hp1 = uipanel(obj.hfig, 'Units','pixels', ...
                          'Position',[75 25 250 200]);
            uicontrol(hp1, 'Style','checkbox', 'Units','normalized', ...
                      'Position',[0.1 10/13 0.1 2/13],               ...
                      'Callback',@(src,event)obj.cb_line(src,event), ...
                      'Min',0, 'Max',1, 'Value',1);
            uicontrol(hp1, 'Style','text', 'Units','normalized', ...
                      'Position',[0.3 10/13 0.6 2/13],           ...
                      'HorizontalAlignment','left',              ...
                      'String','Plot the LLS fit');
            uicontrol(hp1, 'Style','listbox', 'Units','normalized',        ...
                      'Position',[0.1 4/13 0.8 5/13],                      ...
                      'Callback',@(src,event)obj.cb_set(src,event),        ...
                      'String',{'Anscombe I','Anscombe II','Anscombe III', ...
                                'Anscombe IV','blank'},                    ...
                      'Value',5);
            uicontrol(hp1, 'Style','pushbutton', 'Units','normalized', ...
                      'Position',[0.1 1/13 0.8 2/13],                  ...
                      'Callback',@(src,event)obj.cb_reset(src,event),  ...
                      'String','Reset');

            % Create the panel containing the results of the linear fit
            hp2 = uipanel(obj.hfig, 'Units','pixels', ...
                          'Position',[450 25 250 200]);
            uicontrol(hp2, 'Style','text', 'Units','normalized', ...
                      'Position',[0.05 10/13 0.4 2/13],          ...
                      'HorizontalAlignment','left',              ...
                      'String','Num points');
            uicontrol(hp2, 'Style','text', 'Units','normalized', ...
                      'Position',[0.05 7/13 0.4 2/13],           ...
                      'HorizontalAlignment','left',              ...
                      'String','LLS slope');
            uicontrol(hp2, 'Style','text', 'Units','normalized', ...
                      'Position',[0.05 4/13 0.4 2/13],           ...
                      'HorizontalAlignment','left',              ...
                      'String','LLS intercept');
            uicontrol(hp2, 'Style','text', 'Units','normalized', ...
                      'Position',[0.05 1/13 0.4 2/13],           ...
                      'HorizontalAlignment','left',              ...
                      'String','R-squared');
            uicontrol(hp2, 'Style','text', 'Units','normalized',  ...
                      'Position',[0.6 10/13 0.3 2/13],            ...
                      'HorizontalAlignment','left', 'String','0', ...
                      'Tag','num_points');
            uicontrol(hp2, 'Style','text', 'Units','normalized', ...
                      'Position',[0.6 7/13 0.3 2/13],            ...
                      'HorizontalAlignment','left',              ...
                      'Tag','slope');
            uicontrol(hp2, 'Style','text', 'Units','normalized', ...
                      'Position',[0.6 4/13 0.3 2/13],            ...
                      'HorizontalAlignment','left',              ...
                      'Tag','intercept');
            uicontrol(hp2, 'Style','text', 'Units','normalized', ...
                      'Position',[0.6 1/13 0.3 2/13],            ...
                      'HorizontalAlignment','left',              ...
                      'Tag','R_squared');
        end % ILLS()


        function delete(obj)
        %DELETE    Object destructor
        %    Close the figure, but be careful not to recursively delete this
        %    object.
            if strcmp(get(obj.hfig,'BeingDeleted'), 'off')
                set(obj.hfig, 'CloseRequestFcn',[]);
            end
            delete(obj.hfig);
        end % delete()

    end % public methods


    methods(Access='private')

        function update_display(obj)
        %UPDATE_DISPLAY    Compute, plot, and display everything
        %    Delete every dynamic element of the figure and replace it as
        %    appropriate using the current data.  Use the low-level LINE
        %    function instead of PLOT so as not to reset the axes properties.

            % Clear the old plots and displays
            ha_data = findobj(obj.hfig, 'Tag','data');
            ha_res  = findobj(obj.hfig, 'Tag','residuals');
            delete(get(ha_data, 'Children'));
            delete(get(ha_res,  'Children'));
            set(findobj(obj.hfig, 'Tag','slope'),      'String','');
            set(findobj(obj.hfig, 'Tag','intercept'),  'String','');
            set(findobj(obj.hfig, 'Tag','R_squared'),  'String','');

            % We can only fit a line if we have at least two points.
            % Plot and display whatever we can that doesn't require a fit.
            line('Parent',ha_data, 'XData',obj.xs, 'YData',obj.ys,           ...
                 'LineStyle','none','Marker','o','MarkerSize',10,'Color','b',...
                 'ButtonDownFcn',get(ha_data,'ButtonDownFcn'));
            set(findobj(obj.hfig, 'Tag','num_points'), 'String',numel(obj.xs));
            if (numel(obj.xs) < 2)
                return;
            end

            % Perform the computations
            X    = [ones(size(obj.xs)) obj.xs];
            beta = X \ obj.ys;
            yhat = X * beta;
            res  = obj.ys - yhat;
            rsqd = 1 - mean(res.^2)/var(obj.ys,1);

            % Plot and display the fit, residuals, etc.
            x_limits = xlim(ha_data);
            hcb = findobj(obj.hfig, 'Style','checkbox');
            if (get(hcb,'Value') == get(hcb,'Max'))
                hold(ha_data, 'on');
                line('Parent',ha_data,                                   ...
                     'XData',x_limits, 'YData',beta(1)+beta(2)*x_limits, ...
                     'LineStyle','-', 'Color','r', 'LineWidth',2,        ...
                     'ButtonDownFcn',get(ha_data,'ButtonDownFcn'));
            end
            line('Parent',ha_res, 'XData',x_limits, 'YData',[0 0], ...
                 'LineStyle',':', 'Color','k');
            hold(ha_res, 'on');
            line('Parent',ha_res, 'XData',obj.xs, 'YData',res, ...
                 'LineStyle','none', 'Marker','o','MarkerSize',10, 'Color','b');
            set(findobj(obj.hfig,'Tag','num_points'),'String',numel(obj.xs));
            set(findobj(obj.hfig,'Tag','slope'),     'String',num2str(beta(2)));
            set(findobj(obj.hfig,'Tag','intercept'), 'String',num2str(beta(1)));
            set(findobj(obj.hfig,'Tag','R_squared'), 'String',rsqd);
        end % update_display()


        function cb_click(obj, ~, ~)
        %CB_CLICK    Callback for mouse clicks in the data window

            % Get the details of the mouse click
            ha_data = findobj(obj.hfig, 'Tag','data');
            tmp     = get(ha_data, 'CurrentPoint');
            point   = tmp(1,1:2);
            is_left = strcmp(get(obj.hfig, 'SelectionType'), 'normal');

            if is_left
                % Left click - add a new point
                obj.xs = [obj.xs ; point(1)];
                obj.ys = [obj.ys ; point(2)];
            elseif (numel(obj.xs) > 0)
                % Right click - remove the nearest point (if there is one that
                % is reasonably close)
                distances = sqrt( (obj.xs-point(1)).^2 + (obj.ys-point(2)).^2 );
                [m,i] = min(distances);
                if (m < 1)
                    obj.xs = obj.xs([1:(i-1) (i+1):end]);
                    obj.ys = obj.ys([1:(i-1) (i+1):end]);
                end
            end

            % Redraw everything
            obj.update_display();
        end % cb_click()


        function cb_line(obj, ~, ~)
        %CB_LINE    Callback for line plotting checkbox
            obj.update_display();
        end % cb_line()


        function cb_set(obj, ~, ~)
        %CB_SET    Callback for data set selection listbox
            hlb = findobj(obj.hfig, 'Style','listbox');
            switch (get(hlb, 'Value'))
            case 1
                obj.xs = (4:14)';
                obj.ys = [4.26 5.68 7.24 4.82 6.95 8.81 8.40 8.33 10.264553463439110 7.250834364465046 10.494598509101790]';
            case 2
                obj.xs = (4:14)';
                obj.ys = [3.10 4.74 6.13 7.26 8.14 8.77 9.14 9.26 9.059225968662620 8.831529685863837 8.069239496015499]';
            case 3
                obj.xs = (4:14)';
                obj.ys = [5.39 5.73 6.08 6.42 6.77 7.11 7.46 7.81 8.134879264700416 12.740315214548538 8.854824946944433]';
            case 4
                obj.xs = [repmat(8,1,10) 19]';
                obj.ys = [6.89 5.25 7.91 5.76 8.84 6.58 8.47 5.56 7.715921157848292 7.024037496079593 12.499990077840701]';
            otherwise
                obj.xs = [];
                obj.ys = [];
            end
            obj.update_display();
        end % cb_set()


        function cb_reset(obj, ~, ~)
        %CB_RESET    Callback for the reset pushbutton
            obj.cb_set(); % Let the data set selection function do all the work
        end % cb_reset()


        function cb_help(obj, ~, ~)
        %CB_HELP    Callback for the Help menu option
            msg = sprintf(['Choose a base data set from the list.\n' ...
                           'Left-click in the Data plot to add a point.\n' ...
                           'Right-click in the Data plot to delete a point.\n' ...
                           '\n' ...
                           'The Anscombe data sets demonstrate the need to evaluate the LLS fit on your data.  They are very different, but all have the exact same fit (slope and intercept) and goodness of fit (R^2).  Note the inability of the procedure to detect deviations from linearity, and its sensitivity to outliers.']);
            helpdlg(msg);
        end % cb_help()
    end % private methods

end % classdef
