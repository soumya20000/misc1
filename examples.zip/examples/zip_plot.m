function zip_plot(row)
%ZIP_PLOT    Visualize the digit from a single row of the ZIP data

    % Validate the input
    assert((nargin == 1) && (numel(row) == 256));

    % Make the figure
    matrix = reshape(row, 16, 16)'; % Convert the row of pixels to a matrix
    image(matrix, 'CDataMapping','scaled'); % Plot the pixels
    colormap(flipud(gray(2048))); % Convert to gray scale, high numbers = black
    xlim([-7.5, +24.5]); % zoom
    ylim([-7.5, +24.5]); % out
    hold on; % but draw a box around the 16x16 matrix of pixels
    plot([0.5 16.5 16.5 0.5 0.5], [0.5 0.5 16.5 16.5 0.5], '-b');
    set(gca, 'Color',[0.8 1 1]); % Use a non-gray-scale background
    colorbar(); % Label the correspondence between pixel values and colors
end % zip_plot()
