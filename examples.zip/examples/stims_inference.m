%% Well Stimulation Example
% The |stims.xlsx| spreadsheet contains information about most of the
% *well stimulations* that have been performed at a particular
% producing unit (PU).  The PU has wells spread across 6 different *fields*,
% which are several kilometers apart so may be geologically different.  As
% production starts to decline, the wells are stimulated by pumping fluid down
% the tubing and into the reservoir rock, hopefully removing any sand that
% might be blocking the flowpath of hydrocarbons into the wellbore.  There are
% three basic kinds of fluids or *stim types* used: a low salinity brine,
% a high salinity brine, and an enhanced fluid which is diesel-based rather
% than water-based.  The *uplift* is the average production rate (in bbls/day)
% after the stimulation minus the average production rate before the
% stimulation.  Yes, some of the wells have negative uplifts, which means that
% the stimulation did more harm than good.
%
% The business wants to know if they should use more high salinity and/or
% enhanced stimulations in the future.  What would you tell them if this were
% the only data you had?

stims_import;



%% Classical Statistical Methods for Inference

%%
% If all you want to know is, "Do HighSalinity StimTypes produce higher Uplifts
% on average than LowSalinity StimTypes?", then we can translate this question
% into one line of Matlab:
quickest_answer =   mean(X.Uplift(X.StimType == 'HighSalinity')) ...
                  > mean(X.Uplift(X.StimType == 'LowSalinity'))

%%
% *MATLAB NOTE*:  In Matlab, |0| means |false| and any non-zero number means
% |true|.  So |quickest_answer| is |true|.
%
% However, it isn't quite that simple.  There is an enormous spread in the
% Uplift data for each StimType:
grpstats(X(:,{'Uplift','StimType'}), 'StimType', {'mean','std'})

%%
% It's possible that the StimTypes don't really have different effects on
% Uplift, and that their different means are just the result of the scatter in
% the data.  When we plot the data, it is not visually obvious that one
% StimType is systematically better than any other.
figure();
boxplot(X.Uplift, X.StimType);
xlabel('StimType');
ylabel('Uplift');

%%
% A better question to ask is, "Given that I have noisy data sets, is the
% difference in their means statistically significant?"  The most widely used
% tool to answer such questions is the *2-sample t-test*:
[h,p,ci,stats] = ttest2(X.Uplift(X.StimType == 'HighSalinity'),    ...
                        X.Uplift(X.StimType == 'LowSalinity'), ...
                        'VarType','unequal', 'Alpha',0.05)

%%
% In statistical jargon, the *null hypothesis* here is that the two samples
% came from populations with exactly the same mean values.  The t-test
% *rejected* the null hypothesis (|h=1|) because the *p-value* (|p|) is less
% than 0.05 (the significance level that we chose by setting |Alpha|).
% Equivalently, the 95% *confidence interval* (|ci|; 95% because we chose
% |Alpha=0.05|) does not include 0.  Intuitively, a true difference of
% 0 between the means would be very surprising given the data that we
% collected, which is much more consistent with the hypothesis that
% HighSalinity StimTypes generate Uplifts that are, on average,
% between 1 and 25 bbls/day greater than Uplifts from LowSalinity StimTypes.
%
% The difference is statistically significant according to the t-test, but we
% didn't really discuss whether or not the t-test is appropriate here.  Like
% most classical statistical tests, it makes strong assumptions about the
% probability distributions of the data in order to derive an analytic formula.
% The primary assumption of the t-test is that the two samples are drawn from
% normal distributions.  We can check this assumption with an
% *Anderson-Darling* test:
[h,p] = adtest(X.Uplift(X.StimType == 'LowSalinity'))
[h,p] = adtest(X.Uplift(X.StimType == 'HighSalinity'))

%%
% Or more simply with a graphical check via a *Q-Q plot*:
figure();
qqplot(X.Uplift(X.StimType=='LowSalinity'));
title('QQ Plot of LowSalinity Uplifts vs. Standard Normal');
figure();
qqplot(X.Uplift(X.StimType=='HighSalinity'));
title('QQ Plot of HighSalinity Uplifts vs. Standard Normal');

%%
% Neither sample is even close to being normally distributed.  The t-test is
% known to be robust to deviations from the assumptions, but these are pretty
% big deviations.



%% Modern Computational Methods for Inference
% As stated above, we just want to know whether we really do tend to get more
% Uplift from HighSalinity StimTypes or if the apparent difference is due to
% random scatter.  We do not care about what kind of distribution fits the
% Uplift data best, and I don't want to tell my boss that "there is
% a difference if we assume they're normally distributed."
%
% There is a better way.  I want to know if there is any difference in the
% average Uplift between HighSalinity and LowSalinity StimTypes.  I could
% equivalently ask, "Does knowing the StimType provide me with any information
% about the expected Uplift?"  If knowing the StimType provides _no_ additional
% information, then randomly shuffling the StimType shouldn't change the
% distribution of the Uplifts across StimTypes.  This is something we can
% directly test with a Monte Carlo simulation.
%
% *Permutation test* or *randomization test*
%
% Like any hypothesis test, the permutation test requires the following steps:
%
% # Define a *null hypothesis* that you would like to test.  In this case, our
% null hypothesis is that the distribution of Uplifts is the same for
% HighSalinity and LowSalinity StimTypes.
% # Define a *test statistic*, some quantity that you think might help to
% differentiate the null hypothesis from alternatives.  In this case, we'll use
% the mean Uplift for HighSalinity StimTypes minus the mean Uplift for
% LowSalinity StimTypes.
% # Define a *significance level* (usually denoted $\alpha$ and chosen to be
% 0.05).  This is the level of "surprise" you're willing to see in the data.
% # Compute the distribution of the test statistic under the null hypothesis.
% We cannot write down a closed-form probability distribution for this test
% statistic under this null hypothesis.  Instead, we use Monte Carlo simulation
% to approximate the distribution.  Randomly shuffle the LowSalinity and
% HighSalinity labels and compute the test statistic for each shuffle.
% # Compute the value of the test statistic on the observed data.
% # Compute the *p-value*, which is the probability under the null hypothesis
% of a value for the test statistic even more extreme than the value observed.
% # If the p-value is smaller than the significance level, then the observed
% value is highly unlikely under the null hypothesis, so we *reject* the null
% hypothesis.  Otherwise we *fail to reject*.  *Note that we can never _prove_
% anything in statistics, only quantify and weigh evidence.*

% Define the test statistic
% *MATLAB NOTE*  This is an example of an _anonymous function_.
% The "@" symbol is just a shorthand way to define a function on one line.
test_stat = @(sample1, sample2)( mean(sample1) - mean(sample2) );

% Define the significance level
alpha = 0.05

% Perform the Monte Carlo simulation to get the distribution of the test
% statistic under the null hypothesis
uplifts = X.Uplift(  (X.StimType == 'LowSalinity') ...
                   | (X.StimType == 'HighSalinity'));
n1      = sum(X.StimType == 'LowSalinity');
n2      = sum(X.StimType == 'HighSalinity');
num_simulations = 1e4; % need lots of simulations to get good confidence bands
test_statistics = NaN(num_simulations, 1);
for s=1:num_simulations
    % Randomly select n1 of the Uplifts.  For this Monte Carlo simulation,
    % we'll label these as LowSalinity.
    idx_LowSalinity  = randsample(numel(uplifts), n1);

    % For this Monte Carlo simulation, we'll label all of the other Uplifts
    % as HighSalinity.
    idx_HighSalinity = setdiff(1:numel(uplifts), idx_LowSalinity);

    % Compute the difference between the two means after having randomly
    % shuffled the labels.
    test_statistics(s) = test_stat(uplifts(idx_HighSalinity), ...
                                   uplifts(idx_LowSalinity));
end

% Compute the test statistic on the observed (unshuffled) data
observed_statistic = test_stat(X.Uplift(X.StimType == 'HighSalinity'), ...
                               X.Uplift(X.StimType == 'LowSalinity'));

% The p-value is the probability of getting a value at least as extreme as the
% observed value.  We need to consider extreme values at the low end and at the
% high end of the distribution.
p_value = 2*min(mean(test_statistics >= observed_statistic), ...
                mean(test_statistics <= observed_statistic))

% Examine the test statistics and the observed value graphically.
figure();
histogram(test_statistics);
hold on;
plot(observed_statistic + [0,0], ylim(), '--k', 'LineWidth',2);
rejection_limits = prctile(test_statistics, [100*(alpha/2),100*(1-alpha/2)]);
xl = xlim();
yl = ylim();
patch([rejection_limits(1) xl(1) xl(1) rejection_limits(1)], ...
      [yl(1)               yl(1) yl(2) yl(2)],               ...
      'r', 'LineStyle','none', 'FaceAlpha',0.2);
patch([rejection_limits(2) xl(2) xl(2) rejection_limits(2)], ...
      [yl(1)               yl(1) yl(2) yl(2)],               ...
      'r', 'LineStyle','none', 'FaceAlpha',0.2);
xlabel('test statistic');
set(gca, 'YTickLabel',{});
title('Permutation Test for mean(HS) - mean(LS)');


%%
% Permutation tests are great because:
%
% # They are *non-parametric*, i.e. they do not require that we fit the data to
% some standard probabilistic model.
% # They do not require any model assumptions.
% # They are easy to understand and apply (there are hundreds of classical
% tests for different hypotheses under different assumptions).
% # They can be used without change for any test statistic.
%
% To demonstrate the last point, notice that we have still used the mean in our
% test statistic.  There are a few big outliers in our data, and we know that
% big outliers can skew the mean.  What if the apparent difference between
% LowSalinity and HighSalinity StimTypes is not due to random scatter but
% rather to a small number of outliers?  We can test this by using the
% *trimmed mean*, which is just the mean of a set of numbers after throwing out
% big outliers.  This is more robust than the usual mean.  We can use the
% _exact same code_ as above with a different |test_stat|.  This gives us
% a more robust test.

% Define the test statistic
test_stat = @(sample1, sample2)( trimmean(sample1,5) - trimmean(sample2,5) );

% Define the significance level
alpha = 0.05

% Perform the Monte Carlo simulation to get the distribution of the test
% statistic under the null hypothesis
uplifts = X.Uplift(  (X.StimType == 'LowSalinity') ...
                   | (X.StimType == 'HighSalinity'));
n1      = sum(X.StimType == 'LowSalinity');
n2      = sum(X.StimType == 'HighSalinity');
num_simulations = 1e4;
test_statistics = NaN(num_simulations, 1);
for s=1:num_simulations
    idx_LowSalinity  = randsample(numel(uplifts), n1);
    idx_HighSalinity = setdiff(1:numel(uplifts), idx_LowSalinity);
    test_statistics(s) = test_stat(uplifts(idx_HighSalinity), ...
                                   uplifts(idx_LowSalinity));
end

% Compute the test statistic on the observed data
observed_statistic = test_stat(X.Uplift(X.StimType == 'HighSalinity'), ...
                               X.Uplift(X.StimType == 'LowSalinity'));

% The p-value is the probability of getting a value at least as extreme as the
% observed value.  We need to consider extreme values at the low end and at the
% high end of the distribution.
p_value = 2*min(mean(test_statistics >= observed_statistic), ...
                mean(test_statistics <= observed_statistic))

% Examine the test statistics and the observed value graphically.
figure();
histogram(test_statistics);
hold on;
plot(observed_statistic + [0,0], ylim(), '--k', 'LineWidth',2);
rejection_limits = prctile(test_statistics, [100*(alpha/2),100*(1-alpha/2)]);
xl = xlim();
yl = ylim();
patch([rejection_limits(1) xl(1) xl(1) rejection_limits(1)], ...
      [yl(1)               yl(1) yl(2) yl(2)],               ...
      'r', 'LineStyle','none', 'FaceAlpha',0.2);
patch([rejection_limits(2) xl(2) xl(2) rejection_limits(2)], ...
      [yl(1)               yl(1) yl(2) yl(2)],               ...
      'r', 'LineStyle','none', 'FaceAlpha',0.2);
xlabel('test statistic');
set(gca, 'YTickLabel',{});
title('Permutation Test for tm(HS) - tm(LS)');
