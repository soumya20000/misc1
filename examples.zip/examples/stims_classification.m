%% Well Stimulation - Classification
% The STIMS2.XLS spreadsheet contains information about most of the
% *well stimulations* that have been performed at a particular
% producing unit (PU).  The PU has wells spread across 6 different *fields*,
% which are several kilometers apart so may be geologically different.  As
% production starts to decline, the wells are stimulated by pumping fluid down
% the tubing and into the reservoir rock, hopefully removing any sand that
% might be blocking the flow path of hydrocarbons into the wellbore.  There are
% three basic kinds of fluids or *stim types* used: a low salinity brine,
% a high salinity brine, and an enhanced fluid which is diesel-based rather
% than water-based.  The *uplift* is the average production rate (in bbls/day)
% after the stimulation minus the average production rate before the
% stimulation.
%
% Some of the wells have negative uplifts, which means that the stimulation did
% more harm than good.  We have applied hypothesis testing and estimation to
% related problems in the past, but now we would like to focus on these
% "stimulation failures".  Specifically, can we predict the probability that
% the stimulation will actually hurt production?  This can be turned into a
% *classification* problem.



%% Data Import
% I've generated a new file with more information in it, so we can't just
% re-use our old stims_import.m script.

% It often only takes one line of code to import a table from Excel into Matlab.
% Use either |xlsread| to get an *array* or |readtable| to get a *table*.
X = readtable('stims2.xls');

% Columns containing strings are imported as cell arrays.  We want to treat
% them as *categorical variables*, i.e. as codes for a small number of
% possibilities rather than as arbitrary pieces of text.
X.StimType   = categorical(X.StimType);
X.Field      = categorical(X.Field);
X.FaultBlock = categorical(X.FaultBlock);

% These are not *ordinal variables*, so the ordering of the categories only
% matters when we make plots.  By default the categories are in alphabetical
% order.  Reorder the categories so that the are in descending order by
% population count.
field_names  = categories(X.Field);
field_counts = countcats(X.Field);
[~,idx] = sort(field_counts, 'descend');
X.Field = reordercats(X.Field, field_names(idx));
clear field_names field_counts idx; % those are the old orders

stim_type_names  = categories(X.StimType);
stim_type_counts = countcats(X.StimType);
[~,idx] = sort(stim_type_counts, 'descend');
X.StimType = reordercats(X.StimType, stim_type_names(idx));
clear stim_type_names stim_type_counts idx; % those are the old orders

fault_block_names  = categories(X.FaultBlock);
fault_block_counts = countcats(X.FaultBlock);
[~,idx] = sort(fault_block_counts, 'descend');
X.FaultBlock = reordercats(X.FaultBlock, fault_block_names(idx));
clear fault_block_names fault_block_counts idx; % those are the old orders

%%
% Define _Success_ as any positive uplift in 90-day liquid production.
X.Success = X.next90day_average_liquid > X.past90day_average_liquid;

%%
% Print a textual overview of the data table.
summary(X);



%% Logistic Regression - building the model
% We have seen before that there are statistically significant trends in the
% stimulation data.  However, since the variables in X are highly overlapping,
% it would be difficult to tell which variables are truly important by looking
% at only one at a time.  We will now put all of these variables into a single
% statistical model to estimate the probability of stim job "success".
% We start with the most standard, classical statistical method for
% classification: *logistic regression*.
%
% For background on logistic regression, see the textbooks we've been
% referencing. In summary, logistic regression is a *generalized linear model*
% of the form
%
% $P(Y_i | \vec{X_i}) = \frac{1}{1+\exp(-\vec{X_i}\cdot\vec{\beta})}$
%
% $Odds(Y_i | \vec{X_i}) = \exp(\vec{X_i}\cdot\vec{\beta})$
%
% $\vec{X_i}\cdot\vec{\beta} = \beta_0 + \beta_1x_{i,1} + \cdots + \beta_px_{i,p}$
%
% where $Y_i$ is the random variable equal to $1$ if the $i^{\rm th}$ stim job
% is a "success" and is $0$ otherwise; $\vec{X_i}=(x_{i,1},\ldots,x_{i,p})$ is
% the set of features describing the $i^{\rm th}$ stim job that we hope to use
% to predict success; $P(Y_i | \vec{X_i})$ is the probability of success for
% a stim job described by $\vec{X_i}$;
% $Odds(Y_i | \vec{X_i}) = P(Y_i | \vec{X_i}) / [1-P(Y_i | \vec{X_i})]$ are the
% odds of success; and $\vec{\beta} = (\beta_0, \beta_1, \ldots, \beta_p)$
% is the set of coefficients that must be estimated by fitting the logistic
% model to the historical data. Note in particular that the estimated odds of
% success are multiplied by $\exp(\beta_j)$ for a unit increase in $x_{i,j}$.
%
% Logistic regression is not the most powerful classifier.  However, it is more
% statistically rigorous and more easily interpretable than most machine
% learning algorithms.

% Build the set of predictor variable names.  Exclude the variables that
% include future information.  Also exclude FaultBlock for now since there are
% some minor problems with it that we would need to fix first.
predictor_variables = setdiff(X.Properties.VariableNames, ...
                              {'FaultBlock', 'next90day_average_liquid', 'Success'});

% Logistic regression is just one example of *generalized linear regression*,
% all of which may be used via Matlab's |fitglm| function.
mdl = fitglm(X, 'Distribution','binomial', ...
             'ResponseVar','Success', 'PredictorVars',predictor_variables);

% Note that, just as with linear regression, we get p-values for our
% coefficients which tell us how statistically significantly non-zero our
% estimates are.
disp(mdl);



%% Logistic Regression - interpreting results

%%
% Plot the coefficients and their 95% confidence intervals.
% We use three bar charts because the coefficients are on different scales.
% For numerical variables like liquid rate, the coefficient is in units of
% log-odds per unit increase in the quantity, e.g. per 1 barrel increase in
% liquid rate.

% Identify the categorical variables (which are all either 0 or 1 in the model).
tf_zero_one = cellfun(@(c)~isempty(c), ...
                      regexp(mdl.CoefficientNames, '^StimType|Field|Zones'));
variable_importance(mdl.Coefficients.Estimate(tf_zero_one),                ...
                    mdl.CoefficientNames(tf_zero_one),                     ...
                    tinv(0.025, mdl.DFE)*mdl.Coefficients.SE(tf_zero_one), ...
                    true);
title('Coefficients - 0-1 variables');
%set(gca, 'TickLabelInterpreter','none'); % fix the underscore printing issue

% Identify the year/count variables
tf_years    =   ~tf_zero_one             ...
              & cellfun(@(c)~isempty(c), ...
                      regexp(mdl.CoefficientNames, 'Year|Date|Count'));
variable_importance(mdl.Coefficients.Estimate(tf_years),                ...
                    mdl.CoefficientNames(tf_years),                     ...
                    tinv(0.025, mdl.DFE)*mdl.Coefficients.SE(tf_years), ...
                    true);
title('Coefficients - date variables');
%set(gca, 'TickLabelInterpreter','none'); % fix the underscore printing issue

% The remaining variables are liquid rates or liquid decline rates
tf_liquid   = ~tf_zero_one & ~tf_years;
tf_liquid(1) = false; % ignore the constant/offset
variable_importance(mdl.Coefficients.Estimate(tf_liquid),                ...
                    mdl.CoefficientNames(tf_liquid),                     ...
                    tinv(0.025, mdl.DFE)*mdl.Coefficients.SE(tf_liquid), ...
                    true);
title('Coefficients - liquid production variables');
%set(gca, 'TickLabelInterpreter','none'); % fix the underscore printing issue


%%
% We've discussed the statistical significance of predictors and how to
% interpret the individual coefficients, but we haven't discussed the model as
% a whole. A logistic regression model doesn't predict a quantitative variable,
% but rather a probability of occurrence for the target variable. In our case,
% it computes an estimated probability of "success" for any combination of
% predictors. We can see that our model gives us a spread of probabilities,
% roughly centered around the true probability of "success", and that our
% estimated probabilities are indeed higher for historical stim jobs that were
% "successes":
figure();
histogram(mdl.Fitted.Probability);
xlim([0,1]);
xlabel('Estimated probabilities of "success"')
ylabel('number of stim jobs');
hold on;
plot(mean(X.Success)+[0,0], ylim(), '--k');
legend({'estimates', 'true success rate'}, 'Location','NorthWest');

figure();
[~,idx] = sort(mdl.Fitted.Probability);
plot(mdl.Fitted.Probability(idx), 'x');
p = mean(X.Success);
% spread in points chosen for the two classes to be proportional to the class probabilities
jitter = 0.05*((2*p-1)*X.Success(idx) + (1-p)) .* randn(size(X.Success));
hold on;
plot(X.Success(idx) + jitter, '.'); % add "jitter" so points don't overlap
legend({'Estimate', 'Actual'}, 'Location','East');
xlim([0,size(X,1)+1]);
ylim([-0.1,+1.1]);
set(gca, 'XTickLabel',{});
xlabel('Historical records [ordered by estimated probability of "success"]');
ylabel('Probability of "success"');


%%
% I suspect that actual success or failure of a stim job is fairly stochastic,
% i.e. that there is always some non-zero chance of either failure or success.
% In this case, the probabilities of failure may be used to optimally balance
% risk and reward when designing the stimulation program for the production
% unit.  That said, it is most common in classification problems to actually
% classify points, i.e. to predict either success or failure.  This is done by
% choosing a threshold and predicting "success" if and only if the estimated
% probability exceeds this threshold.  The threshold may be chosen to balance
% the risk of false positives against the risk of false negatives.  This
% trade-off is typically captured in an *ROC curve*
% (ROC = Receiver Operating Characteristic), which can also be used to give
% a metric for the quality of the classification
% (AUC = Area Under the Curve).
[fpr,tpr,thresholds,AUC,opt_roc_pt] = perfcurve(X.Success, mdl.Fitted.Probability, true);
figure();
scatter(fpr, tpr, 10, thresholds, 'filled');
h = colorbar();
set(gca, 'CLim',[0,1]);
ylabel(h, 'threshold');
hold on;
plot([0,1], [0,1], ':r');
plot([0,0,1], [0,1,1], '--g');
xlabel('False positive rate')
ylabel('True positive rate')
title('ROC for Classification by Logistic Regression')
legend({sprintf('logistic regression    (AUC = %.2f)', AUC), ...
                'no discrimination      (AUC = 0.50)',       ...
                'perfect classification (AUC = 1.00)'},      ...
       'Location','SouthEast');
xlim([-0.01,+1.01]);
ylim(xlim());
box on;


%%
% We can choose the best risk-reward profile along the ROC curve above and use
% the threshold indicated by the color of that point.  The typical default
% threshold is 0.5.  The threshold should be driven by the needs of the
% business problem.  The relative costs of false negatives and false positives
% may be sent to |perfcurve|, which will then find the optimal threshold to
% balance the trade-offs.  In this case, we use the defaults for |perfcurve|,
% which assumes that false positives and false negatives are equally costly.
% We can then look at how the final classification (logistic regression model
% plus probability threshold) performs using a *confusion matrix*.
threshold_optimal = thresholds((fpr == opt_roc_pt(1)) & (tpr == opt_roc_pt(2)));
Ca = confusionmat(X.Success, mdl.Fitted.Probability >= threshold_optimal);
Ct = table(Ca(:,1), Ca(:,2),                                           ...
           'VariableNames',{'Predicted_failure', 'Predicted_success'}, ...
           'RowNames',{'Actual_failure', 'Actual_success'});
fprintf('Confusion matrix for threshold probability of success = %.2f:\n', ...
        threshold_optimal);
disp(Ct);
