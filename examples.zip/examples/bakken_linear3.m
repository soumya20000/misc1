%% Regression Diagnostics, Model Selection, and LASSO
% Build a "good" model for Y.oil as a function of the columns of X.
%
% This is the best modeling strategy:
%
% # Perform ordinary least squares linear regression using all of the variables that you think might be relevant.
% # Use regression diagnostics to identify limitations of your data set or of the resulting model.  You can use the p-values to help understand the data, but you should report confidence intervals computed using the bootstrap.
% # Refine your model based on business needs.  If you are trying to understand the data, use backwards stepwise refinement to eliminate the few unimportant variables.  If there are many variables, use LASSO instead.  If you just need to be able to make good predictions, then ideas from machine learning will be important.



%% Build the extended data set
% Load the original data
load('bakken.matlab', '-mat');

%%
% Add _proppant concentration_ and _oil saturation_ to the set of $X$ variables.
X = [X, table(X.proppant ./ X.frac_fluid / 42, ...
              X.oil_in_place / (5280^2/640) ./ X.thickness ./ (X.porosity/100) * (42*231/12^3) * 100, ...
              'VariableNames',{'proppant_concentration', 'oil_saturation'})];
X.Properties.VariableUnits{end-1} = 'lbs/gal';
X.Properties.VariableUnits{end} = '%';

%%
% Filter out the extreme and missing data.  Normally we would keep these rows
% and filter only as needed.  However, we will be comparing different models,
% and to do so the models all must be built on the exact same set of rows.
% We therefore throw out _all_ rows that _might_ not get used by one of our
% models.
tf_notmissing = (Y.oil > 0) & all(isfinite(table2array(X)),2);
tf_notextreme =   (X.proppant < 6e6)     ...
                & (X.frac_fluid < 1.5e5) ...
                & (X.proppant_concentration < 5);
X = X(tf_notmissing & tf_notextreme,:);
Y = Y(tf_notmissing & tf_notextreme,:);



%% Regression Diagnostics
% It is _not_ an assumption for ordinary least squares linear regression that
% the predictor variables be uncorrelated.  However, if some of the variables
% are highly correlated (or highly anti-correlated), then the coefficients may
% be difficult to interpret.  It is therefore always a good idea to understand
% the correlations before performing a regression analysis.
%
% *MATLAB NOTE*:  The |table| structure in Matlab is relatively new.  It stores
% each column separately, so that the columns may have different data types.
% In fact, the columns do not even need to be numeric, which is a nice feature.
% However, it means that older Matlab functions that work on arrays and
% matrices may not accept |table| inputs even if all of the columns of our
% |table| _are_ numeric.  For such functions, we must convert our table to an
% old-style matrix using the |table2array| function.
%
% *MATLAB NOTE*:  Matlab allows you to include LaTeX markup in the annotations
% for a figure.  This is usually very nice, but has the drawback that
% underscores aren't printed, but instead change the following character to
% a subscript.  This usually isn't what we want, so we can set the
% |'TickLabelInterpret'| to |'none'| rather than |'latex'| to prevent this
% behavior.  Alternatively, you can keep the LaTeX interpreter on, but replace
% all of your underscores with '\_'.
figure();
imagesc(corr(table2array(X)));
colorbar();
set(gca, 'CLim',[-1,+1],                                               ...
         'XTick',1:size(X,2), 'XTickLabel',X.Properties.VariableNames, ...
         'XTickLabelRotation',60,                                      ...
         'YTick',1:size(X,2), 'YTickLabel',X.Properties.VariableNames, ...
         'TickLabelInterpreter','none');
title('variable correlation coefficients');

%%
% While it is _not_ an assumption of ordinary least squares linear regression
% that the predictor variables be uncorrelated, it _is_ the case that high
% correlations reduce the accuracy of the coefficient estimates and that _very_
% high correlations can cause the model to overfit or even cause the regression
% algorithm to become numerically unstable.  This can be especially hard to
% diagnose if there are nearly linear relationships among more than two of the
% predictor variables.  This class of problems is known as *multicollinearity*.
% A good diagnostic for multicollinearity is the
% *Variance Inflation Factor (VIF)*.  For each predictor variable,
% $VIF_i = (1 - R^2_i)^{-1}$, where $R^2_i$ is the $R^2$ of a linear model predicting $X_i$ as a function of the other $X$-variables.  So, if a predictor variable has a high VIF, this indicates that it is easy to predict that variable as a function of the other predictors.
vifs = rd_vif(table2array(X));
vif_results = table(vifs', 1-1./vifs',              ...
                    'VariableNames',{'VIF','R2_i'}, ...
                    'RowNames',X.Properties.VariableNames);
disp(vif_results);

%%
% A common rule of thumb is that $X$-variables with VIFs higher than 10 should
% be removed from the model.  In this case, |oil_saturation| has the highest
% VIF, and once we eliminate it the remaining VIFs are all below 10.
X.oil_saturation = []; % delete this column from the table
vifs = rd_vif(table2array(X));
vif_results = table(vifs', 1-1./vifs',              ...
                    'VariableNames',{'VIF','R2_i'}, ...
                    'RowNames',X.Properties.VariableNames);
disp(vif_results);

%%
% Once we've eliminated the major problems with the variables, it's best to
% start with linear regression on all remaining variables.  At the very least,
% the p-values on the full model can tell you which variables are relevant for
% predicting $y$.
%
% *MATLAB NOTE*:  The |plotEffects| function allows us to quickly visualize the
% coefficients and their confidence intervals.  In order to put them on the
% same scale, the function multiplies each coefficient by the range of values
% for that variable seen in the data set.  In other words, what is plotted is
% how much $y$ would change if that predictor were changed from its minimum to
% its maximum value, keeping all other predictors constant.
mdl = fitlm(horzcat(X, Y));
disp(mdl);
figure();
mdl.plotEffects();
set(gca, 'TickLabelInterpreter','none'); % fix the underscore printing issue

%%
% The p-values and the confidence intervals around the coefficient estimates
% are calculated under certain statistical assumptions.  The first assumption
% is that $y$ is approximately linear, and that the *errors* (i.e. the
% departures from linearity) are random with Gaussian distribution.  Once the
% model is fit, we can approximate the errors via the
% *residuals* $r_i = y_i - \hat{y}_i$.  
% The *(externally) studentized residuals* are normalized by an estimate of
% standard deviation; for technical reasons, these are the residuals you should
% study.  The p-values and the confidence intervals are not statistically valid
% unless the externally studentized residuals are approximately Gaussian with
% mean 0 and variance 1.  (More precisely, they should be t-distributed with
% N-p-1 degrees of freedom).
figure();
histogram(mdl.Residuals.Studentized);
xlabel('Studentized Residuals');
figure();
normplot(mdl.Residuals.Studentized);
xlabel('Studentized Residuals');

%%
% There are significant departures from normality here.  The really big outlier
% happens to be the biggest oil producer, which tells us that something is very
% different about this particular well that isn't captured by our model.
[~,ind_max_residual] = max(mdl.Residuals.Studentized);
[~,ind_max_y] = max(Y.oil);
disp(ind_max_residual == ind_max_y); % remember 1 means True

%%
% Another statistical assumption is that the errors must be uncorrelated with
% the predictor variables.  However, if we make a map of the studentized
% residuals, we can see that there are spatial patterns in the residuals, which
% invalidates this assumption.  It also suggests that we have not captured all
% of the geological variations in our model.
scatter(X.longitude, X.latitude, 10, mdl.Residuals.Studentized, 'filled');
xlabel('Longitude');
ylabel('Latitude');
title('Studentized Residuals');
colorbar();
set(gca, 'CLim',[-3,+3]);

%%
% A more common method for checking for this independence is by plotting the
% residuals against the $X$ variables individually.  Any patterns visible in
% these plots are suggestive of nonlinearities that should be included in the
% model.  For this data set, some pattern is evident with latitude and
% thickness, so these might be good variables for which to include squared
% terms.
for v=1:size(X,2)
    figure();
    plot(X{:,v}, mdl.Residuals.Studentized, '.');
    hold on;
    plot(xlim(), [0,0], ':k');
    xlabel(X.Properties.VariableNames{v}, 'Interpreter','none');
    ylabel('Studentized Residuals');
end

%%
% The above diagnostics show us that the standard assumptions for
% ordinary least squares linear regression do not really hold, so we probably
% need to improve the model and/or use the bootstrap to understand
% uncertainties rather than relying upon the results in |fitlm|.  There are
% other standard diagnostics that focus more on the individual observations
% than the overall model.  For example, are the $X$-values for an observation
% so extreme that they might have really high "leverage" on the model, is the
% $y$-value much farther away from the prediction than would be expected, or is
% an $(X,y)$ combination so unusual that it has a large "influence" on the
% estimated coefficients?
%
% *Fox's Influence Plot* is a way to simultaneously illustrate all three of the
% above.  Look at the |rd_influence_plot2.m| code to read more about these
% quantities.  Basically, anything above or below the red dashed lines is an
% outlier (the $y$-value is not close to our predictions), anything to the right
% of the second vertical line is a *leverage point* (the $X$-values are extreme
% relative to the rest of the data), and anything with a red circle is an
% *influential point* (it single-handedly changes the coefficient estimates by
% a large amount).  These should ordinarily be studied individually to
% decide if they should be kept in the training data set.
[tf_outlier,tf_leverage,tf_influential] = rd_influence_plot2(mdl);

%%
% The |mdl| object returned by |fitlm| offers many diagnostic utilities of its
% own.  Here's one example, which illustrates how much each coefficient would
% have changed had each row been removed.  This is related to Cook's distance
% plotted above; you definitely don't want your results to be too influenced by
% just one row.
figure();
mdl.plotDiagnostics('dfbetas');
xlim([0, mdl.NumObservations+1]);
h = legend('show', 'Location','EastOutside');
h.Interpreter = 'none'; % fix the underscore thing



%% Stepwise Refinement

%%
% Before experimenting with including or excluding variables, you must realize
% that adding a new variable, _even a completely random variable_, to
% a regression model will always increase the $R^2$.  For this reason, when
% comparing models with different combinations of variables, you should look at
% the *adjusted $R^2$*, which attempts to penalize the ordinary $R^2$ for
% adding variables that don't contribute significantly.
RandStream.getGlobalStream.reset(); % ensure that we get the same random column
                                    % every time we run this code
X_new = horzcat(X, table(randn(size(X,1),1), 'VariableNames',{'random'}));
mdl2 = fitlm(horzcat(X_new, Y));
disp(mdl2);
disp(mdl2.Rsquared);
disp('Original model without the random column:');
disp(mdl.Rsquared);


%%
% You should try to use problem-specific reasoning to decide if and how to
% reduce the set of predictor variables.  For example, use the correlation
% coefficients to eliminate highly correlated variables.  Only once the $X$
% variables are completely independent can the regression coefficients be
% easily interpreted.
%
% However, a commonly used automatic model selection strategy is
% *Backward Stepwise Refinement*:  eliminate the least important variable
% (the one with the highest p-value), and stop eliminating variables when the
% adjusted $R^2$ stops increasing.
X_bswr = X;
mdl_bswr = mdl;
while (size(X_bswr,2) > 0) % as long as we haven't eliminated all of the variables
    % Notice that the p-values will change as we remove variables, especially
    % among the highly correlated variables
    disp(mdl_bswr.Coefficients(:,{'Estimate','pValue'}));

    % Look for the biggest p-value among the variable coefficients
    % (never remove the constant, regardless of its p-value)
    [~,ind] = max(mdl_bswr.Coefficients.pValue(2:end));

    % Try removing this variable and see if we get a better Adjusted R^2
    X_tentative = X_bswr(:,[1:(ind-1) (ind+1):end]);
    mdl_tentative = fitlm(horzcat(X_tentative, Y));
    if (mdl_tentative.Rsquared.Adjusted < mdl_bswr.Rsquared.Adjusted)
        fprintf('Removing %s would decrease the Adjusted R-squared\n\n', ...
                X_bswr.Properties.VariableNames{ind});
        break;
    end

    % Remove the variable and keep refining the model
    fprintf('Removing %s, Delta Adjusted R-squared=%.7f\n\n', ...
            X_bswr.Properties.VariableNames{ind},             ...
            mdl_tentative.Rsquared.Adjusted - mdl_bswr.Rsquared.Adjusted);
    X_bswr = X_tentative;
    mdl_bswr = mdl_tentative;
end


%%
% Forward and backward refinement are common strategies, so Matlab has built-in
% code for performing these tasks.  This line of code does exactly the same
% thing as the hand-coded |while| loop above, and the resulting model would be
% my first "good" model as a solution to the homework problem:
mdl_bswr_automatic = stepwiselm(horzcat(X,Y), 'linear',               ...
                                'Lower','constant', 'Upper','linear', ...
                                'Criterion','adjrsquared',            ...
                                'PEnter',Inf, 'PRemove',0);
disp(mdl_bswr_automatic);


%%
% We can also use the |stepwiselm| function to add interaction and quadratic
% terms to our model.  In this case, the $R^2$ gets much higher, but we've
% added so many terms that I'm worried that we're overfitting our training
% data.  We need to use ideas from machine learning to decide whether or not
% this procedure was useful.
mdl_fswr = stepwiselm(horzcat(X,Y), 'linear',                  ...
                      'Lower','constant', 'Upper','quadratic', ...
                      'Criterion','adjrsquared',               ...
                      'PEnter',1e-3, 'PRemove',0);
disp(mdl_fswr);



%% LASSO (Least Absolute Shrinkage & Selection Operator)
% LASSO is a generalization of ordinary least squares linear regression that is
% particularly useful for eliminating unimportant variables.
RandStream.getGlobalStream.reset(); % ensure that we get the same results
                                    % every time we run this code
[B,FitInfo] = lasso(table2array(X), Y.oil, 'CV',10, ...
                    'PredictorNames',X.Properties.VariableNames);
lassoPlot(B, FitInfo, 'PlotType','CV');
coeff_lasso = table([FitInfo.Intercept(FitInfo.IndexMinMSE); ...
                     B(:,FitInfo.IndexMinMSE)],              ...
                    'VariableNames',{'Estimate'},            ...
                    'RowNames',mdl.Coefficients.Properties.RowNames);
disp(coeff_lasso);

%%
% LASSO as implemented by Matlab has one tunable parameter ("lambda").  The
% LASSO function chooses lambda using *cross-validation*, an important concept
% in machine learning.  The goal is to choose the parameter that yields the
% best fit on a blind test set, not the best fit on the training data.
y_hat = horzcat(ones(size(X,1),1), table2array(X)) * coeff_lasso.Estimate;
r2_train = 1 - mean((y_hat - Y.oil).^2) / var(Y.oil,1);
r2_generalization = 1 - FitInfo.MSE(FitInfo.IndexMinMSE) / var(Y.oil,1);
fprintf('Training R^2 from backward stepwise refinement = %.5f\n', mdl_bswr_automatic.Rsquared.Ordinary);
fprintf('Estimated predictive R^2 from BSWR             = ???????\n');
fprintf('Training R^2 from LASSO                        = %.5f\n', r2_train);
fprintf('Estimated predictive R^2 from LASSO            = %.5f\n', r2_generalization);
