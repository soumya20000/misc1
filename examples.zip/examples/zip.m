%% Handwriting Recognition - Digits from the zip code data set
% This is a famous data set that has been used for many different
% classification studies in the public literature.  The data set was put
% together by the United States Postal Service.  It was used to test algorithms
% to be used by their automatic handwriting recognition systems used to sort
% and route mail.  Note that the classification of an image as a handwritten
% "1" or "2" is the _last_ step of the business problem.  The hard work of
% making this a production system would have to include all of the following
% steps:
%
% # Find the zip code on the envelope.
% # Isolate the individual digits in the zip code.
% # Re-color the images so that they use a common scale for the pixel values.
% # Rescale the images so that they are the same size.
% # Rotate and center the images so that they are all facing the right way for the classifier (note that with deep learning, this might not be required).
%
% All of these steps have been performed for us so we can concentrate on the
% classification problem.  Remember, though, that for a real business problem,
% the "data analytics" is always just a small fraction of the work required.


%% Import the data
% This data set is already split into a training set and a test set.
% For any particular classification model, you should _only_ experiment with
% the training data.  In particular, you should use the training data to help
% decide on the features you want to include, the metric you want to use, the
% hyperparameters that seem to work best, etc.  Only at the end should you
% train the final algorithm on the complete training set and then test
% _exactly once_ against the test set.  In other words, the test set should
% _only_ be used to compare algorithms, not to fine-tune algorithms.
[X_train,Y_train,X_test,Y_test] = zip_import();


%% Plot examples of each digit
figure();
for d=0:9
    subplot(4, 3, d+1);
    ind = find(Y_train == d, 1, 'first');
    zip_plot(X_train(ind,:));
    title(num2str(Y_train(ind)));
end


%% Build Algorithm 1 on the training set
% Build a classifier.  Feel free to classify just a single digit, to try to
% differentiate between two different digits, or to classify all ten digits.


%% Build Algorithm 2 on the training set


%% Test Algorithm 1 and Algorithm 2 against the test set
