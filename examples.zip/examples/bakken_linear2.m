%% Unconventional Well Example
% The |bakken.matlab| file contains information about several thousand wells
% in the Bakken formation in North Dakota and Montana.


%% Data Import
% Import the same data from |bakken_linear.m| and perform the same filtering.
%#ok<*NOPTS>
%#ok<*NASGU>
load('bakken.matlab', '-mat');
format short; % only print a few significant digits
proppant_concentration = X.proppant ./ X.frac_fluid / 42;
tf_Y_valid = Y.oil > 0;
tf_X_reject = false(numel(X.proppant), 1);
tf_X_reject(X.proppant == max(X.proppant)) = true;
tf_X_reject(proppant_concentration > 5) = true;
tf_X_reject(X.frac_fluid > 3e5) = true;


%% 2(f) Interpreting coefficients
% Why is the coefficient for porosity negative in the multivariate linear
% regression model? Does that make physical sense?
% Hint: What happens if we remove oil_in_place as one of the X variables?

%%
% First, let's rebuild our model from 2(d):
%
% *MATLAB NOTE*:  It's best to make filters using |logical| arrays, i.e. arrays
% of |true| and |false|.  These are easy to work with and can be used for fast
% indexing into other arrays of the same size.  Then, to combine multiple
% filters, just use Matlab's |&| (_and_) operator.
tf2d =   tf_Y_valid            & ~tf_X_reject                                  ...
       & isfinite(X.length)    & isfinite(X.frac_fluid) & isfinite(X.proppant) ...
       & isfinite(X.thickness) & isfinite(X.porosity)   & isfinite(X.oil_in_place);
tbl2d = horzcat(X(tf2d, {'length', 'frac_fluid', 'proppant', 'thickness', ...
                         'porosity', 'oil_in_place'}),                    ...
                Y(tf2d, 'oil'));
mdl2d = fitlm(tbl2d)

%%
% Now let's follow the hint.
tbl = horzcat(X(tf2d, {'length', 'frac_fluid', 'proppant', 'thickness', ...
                       'porosity'}),                                    ...
              Y(tf2d, 'oil'));
mdl = fitlm(tbl)

%%
% Now porosity looks statistically significantly _positively_ associated with
% oil production, which is what we would expect.  Why was the coefficient
% _negative_ in the full model?  The problem is with the interpretation of the
% coefficient.  In a multivariate linear model, a coefficient gives you an
% estimate of how the y-value changes as a function of the single x-value of
% interest, _assuming all other x-values are held constant_.  It probably does
% not make physical sense that production would decrease as a function of
% porosity, but it might make sense that production would decrease as
% a function of porosity _for fixed oil_in_place and thickness_.  In fact, the
% oil_in_place is actually the product of porosity, thickness, and
% oil saturation (which isn't included in this data set).  So if porosity goes
% up while oil_in_place and thickness remain fixed, then the oil saturation
% must have gone down, which could plausibly reduce production.
%
% In general, the coefficients of a regression model can be tricky to interpret
% if the variables are not completely independent of one another.  One way to
% check for this is to look at the correlation coefficients.  Numbers close to
% +1 or -1 indicate high correlations.  Sure enough, porosity and oil_in_place
% are correlated; the correlation is high enough that thought is required to
% interpret the results, but not so high that it could cause problems for the
% regression model.
%
% *MATLAB NOTE*:  You usually want to add the option |'rows','pairwise'| when
% calling |corr|.  This will only throw out the % minimum number of missing
% data points needed to compute each element of the correlation matrix.  That
% probably sounds like an obvious thing to do, but the reason it is _not_ the
% default is because the returned matrix of correlation coefficients might not
% be positive definite, which is a requirement for some other statistical
% functions.
tbl2d.Properties.VariableNames(1:end-1) % exclude the y-variable
corr(table2array(tbl2d(:,1:end-1)), 'rows','pairwise')



%% 2(g) Latitude and Longitude as predictor variables
% In 2(d) we built a model with engineering and geological parameters. In 2(e)
% we built a model with just the engineering parameters. Now build a third
% model with the engineering parameters, latitude, and longitude (no geology).
% Compare the latitude/longitude model with the other two. Does it make sense?
% What does it mean to have a statistical model with latitude and longitude as
% predictors?
tbl = horzcat(X(tf2d, {'length', 'frac_fluid', 'proppant', ...
                       'latitude', 'longitude'}),          ...
              Y(tf2d, 'oil'));
mdl = fitlm(tbl)

%%
% In terms of $R^2$, this model is not as good as model 2(d) but is better than
% the engineering-only model in 2(e).  In this case, latitude and longitude are
% serving as (weak) proxies for all of the geology.  This is an example of
% a model that is more _predictive_ than _explanatory_.  In fact, we can go
% even further and include non-linear terms in latitude and longitude to
% account for the fact that geology doesn't vary in purely linear,
% north-to-south and east-to-west patterns.  The result is almost as predictive
% (in terms of $R^2$) as model 2(d).
tbl = horzcat(X(tf2d, {'length', 'frac_fluid', 'proppant',         ...
                       'latitude', 'longitude'}),                  ...
              table(X.latitude(tf2d).^2, X.longitude(tf2d).^2,     ...
                    X.latitude(tf2d) .* X.longitude(tf2d),         ...
                    'VariableNames',{'latitude_squared',           ...
                                     'longitude_squared',          ...
                                     'latitude_times_longitude'}), ...
              Y(tf2d, 'oil'));
mdl = fitlm(tbl)



%% 2(h) Effect of outliers
% Rebuild the model from 2(d) without first filtering out the enormous proppant
% outliers. How does leaving in the outlier affect the results?

%%
% Let's just remove the tf_X_valid term in the row mask and then build the
% model.  The resulting $R^2$ is much lower, and the coefficient for proppant is
% 200 times smaller, just because 2% of the rows with extreme outliers were
% left in.
tf =   tf_Y_valid                                                            ...
     & isfinite(X.length)    & isfinite(X.frac_fluid) & isfinite(X.proppant) ...
     & isfinite(X.thickness) & isfinite(X.porosity)   & isfinite(X.oil_in_place);
disp([sum(tf2d), sum(tf)])
mdl2d
tbl = horzcat(X(tf, {'length', 'frac_fluid', 'proppant', 'thickness', ...
                     'porosity', 'oil_in_place'}),                    ...
              Y(tf, 'oil'));
mdl = fitlm(tbl)



%% 3(a) Standard confidence intervals for linear regression
% Suppose we believe model 2(d). What is the estimate for the average increase
% in oil production per unit increase in proppant? What does classical
% statistical theory suggest is the range of values that are consistent with
% the data?

%%
% The |fitlm| function doesn't just compute a least squares solution.
% It performs all of the standard statistical analyses on the linear model.
% The classical assumptions (including that the true function is linear on
% these same variables, the error relative to the linear function is Gaussian,
% and these errors are independent and identically distributed across rows)
% allow us to build a Student t-distribution for each coefficient, and the
% confidence interval can be queried directly:
%
% *MATLAB NOTE*:  |coefCI| returns a matrix rather than a table.  That means
% the rows are not labeled like they are in |Coefficients|.  So, to make sure
% we get the right row of confidence intervals, we have to explicitly pass the
% row index corresponding to 'proppant'.  You could just remember which row is
% which and pass in the number 4, but it is safer to _compute_ the index using
% the name of the coefficient.  That way, if you change your code to add or
% reorder the variables, this will still work without having to change the
% number 4.  It's also much more robust to errors (is it really variable #4?).
disp('Point estimate:');
mdl2d.Coefficients{'proppant', 'Estimate'}
disp('95% confidence interval:');
ci_standard = mdl2d.coefCI();
ci_standard(strcmp('proppant', mdl2d.CoefficientNames),:)



%% 3(b) Bootstrapped confidence intervals for linear regression
% Use |bootci| to get the bootstrapped confidence intervals, and compare to the
% t-test confidence intervals from 3(a). Any thoughts?

%%
% We first need to build a function to pass to the bootstrap routines.  For any
% sample of the rows, this function should perform the linear regression and
% return the coefficients.
%
% *MATLAB NOTE*:  |fitlm| would be overkill because it does many other
% computations that would just be ignored here.  The most efficient function
% would just use Matlab's "backslash operator", but to make things a little
% more readable, I'll use the |regress| function, which returns the
% coefficients rather than an object that contains the coefficients.
%
% *STATISTICS / MATLAB NOTE*:  The |regress| function, unlike |fitlm|, does not
% automatically add an intercept term.  The standard linear equation
%
% $y = \beta_0 + \beta_1 x_1 + \cdots + \beta_p x_p$
%
% may be written
%
% $y = (1, x_1, \ldots, x_p) \cdot (\beta_0, \beta_1, \ldots, \beta_p)$.
%
% So the matrix "trick" used in statistics to add an intercept term but treat
% it just like any other term is to add a new variable to your set of
% independent variables (call it $x_0$) that is identically equal to 1.  So, in
% order to get |regress| to compute an intercept term, we need to add a column
% of ones to our |X| matrix.  You can do this with the |ones| function.
compute_coefficients = @(row_inds)                         ...
    regress(tbl2d.oil(row_inds),                           ...
            horzcat(ones(numel(row_inds),1),               ...
                    table2array(tbl2d(row_inds,1:end-1))));

%%
% We can test this function by comparing it to what |fitlm| already computed
% (let's use lots of significant digits just for this comparison to make sure
% that the results are _exactly_ the same):
format long;
horzcat(mdl2d.Coefficients.Estimate, compute_coefficients(1:size(tbl2d,1)))
format short;

%%
% It matches exactly.  Let's use |bootci| to simultaneously compute the
% confidence intervals for every one of our coefficients.
ci_bootstrap = bootci(1e4, {compute_coefficients, 1:size(tbl2d,1)})';

%%
% Note that, in this case, the classical Student-t confidence intervals and the
% non-parametric bootstrap confidence intervals are very similar.  This might
% be surprising given that we *know* that the assumptions made by |fitlm| are
% false.  This is evidence that the classical linear regression model is fairly
% robust to deviations from the assumptions.
for k=1:size(ci_standard,1)
    disp(mdl2d.CoefficientNames{k});
    disp(vertcat(ci_standard(k,:), ci_bootstrap(k,:)));
end



%% 3(c) Correlations among the coefficient estimates
% In 3(b), you looked at confidence intervals for each of the coefficients,
% which leaves the impression that the estimated coefficients are independent.
% Use |bootstat| to plot the two-dimensional probability distribution of
% estimates for the oil_in_place and porosity coefficients. Does the plot make
% sense physically?

%%
% Now we want to look at the full distribution of the coefficients rather than
% just the confidence intervals.  To get the distribution, we must use the
% |bootstrp| function, but we don't need quite as many samples.
bootsamp = bootstrp(1e3, compute_coefficients, 1:size(tbl2d,1));

%%
% This gives us a sample from the full, multivariate distribution of
% coefficient estimates.  Let's look at the two coefficients of interest.  Note
% that they are negatively correlated.  This makes sense because the two
% quantities are strongly _positively_ correlated.  So if our estimate for one
% of the coefficients goes up, our estimate for the other coefficient would
% have to go down to maintain the same balance from the two quantities.
ind_porosity     = find(strcmp('porosity',     mdl2d.CoefficientNames));
ind_oil_in_place = find(strcmp('oil_in_place', mdl2d.CoefficientNames));
figure();
plot(bootsamp(:,ind_porosity), bootsamp(:,ind_oil_in_place), '.');
hold on;
plot(mdl2d.Coefficients.Estimate(ind_porosity), ...
     mdl2d.Coefficients.Estimate(ind_oil_in_place), ...
     'ok', 'MarkerSize',12, 'MarkerFaceColor','k');
xlabel('porosity coefficient for model 2(d)');
ylabel('oil\_in\_place coefficient for model 2(d)');
legend({'estimate distribution', 'point estimate'});

%%
% Note that |fitlm| returns a full covariance matrix for the coefficient
% estimates (though we only used the confidence intervals for individual
% coefficients).  Now we see a little more difference between the classical
% distribution and the bootstrap distribution (the bootstrapped correlation coefficient between these two estimates is about -0.6, whereas the classical estimate is only about -0.5):
format long;
mdl2d.CoefficientCovariance([ind_porosity ind_oil_in_place], ...
                            [ind_porosity ind_oil_in_place])
cov(bootsamp(:,[ind_porosity ind_oil_in_place]))
