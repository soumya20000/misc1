%% Eigenfaces Demo
% This is a demonstration of the "eigenfaces" approach to facial recognition.
% While it sounds specific to faces, it is just using PCA analysis on the pixel
% data, which is a common technique for non-facial image recognition problems,
% as well.

%% Main function
function eigenfaces()
    dir_img = 'yalefaces'; % directory where the image files are stored
    width = 180; % cropped width of the images


    %% Standardize an image.
    % When dealing with images, it is usually important that they be
    % the same size, that the important part of the image be centered, and that
    % extraneous parts of the image be removed.  Image processing techniques
    % are required.  Here, I try something simple to center the faces.
    function img2 = center_and_crop(img)
        % In a grayscale image, 255=white and 0=black.  Let's compute the total
        % "darkness" of each column.
        column_darkness = sum(255 - img);

        % We don't really care about individual columns; we want to keep
        % exactly WIDTH consecutive columns.  So, let's compute the
        % total "darkness" of every set of WIDTH consecutive columns.
        % The |filter| command will do this for us.  For column numbers
        % c < WIDTH, it will only sum the column_darkness of the first
        % c columns.
        window_darkness = filter(ones(1,width), 1, column_darkness);

        % Now we want to keep the window of WIDTH consecutive columns that
        % contains the most total "darkness".
        [~,i] = max(window_darkness);

        % It seems to work a little bit better if we adjust the "optimal"
        % starting point found above by a few columns.
        i = i - 5;

        % Now crop the image to contain only the best window of WIDTH
        % consecutive columns.
        img2 = img(:, (i-width+1):i);
    end % center_and_crop()


    %% Read an image from disk and return its "pixel vector".
    % Ideally, we would have a small number of features that make sense for
    % a given problem.  When dealing with images, the most obvious set of
    % features is the colors (or in this case, the gray intensities) of each
    % pixel.  This is perfectly valid mathematically, but it results in a HUGE
    % number of features.  We'll start with all of the pixel intensities and
    % derive a smaller set of features from it later.
    function img_vector = get_image_pixel_vector(filename)
        % Read the image from disk; |imread| imports an image into a matrix
        img_full = imread(fullfile(dir_img, filename));

        % Center the image and zoom in on the face
        img_cropped = center_and_crop(img_full);

        % Convert the intensity scale from 0-255 to 0-1.  We could do what we
        % want on the original scale, but Matlab really prefers floating point
        % numbers to integers.
        img_01 = double(img_cropped) / 255;

        % Store all of this image's gray intensity data as a single row
        img_vector = reshape(img_01, 1, numel(img_01));
    end


    %% Compute eigenvalues of the set of "normal" faces
    listing = dir(fullfile(dir_img, 'subject*.normal.gif'));

    %%
    % Load one image just to get the resolution.
    img_typical = imread(fullfile(dir_img, listing(1).name));
    img_size_original = size(img_typical);
    img_size = [img_size_original(1) width];

    %%
    % Create a matrix where each row contains the "pixel vector" for a single
    % image.
    images = NaN(numel(listing), img_size(1) * img_size(2));
    for f=1:numel(listing)
        images(f,:) = get_image_pixel_vector(listing(f).name);
    end

    %%
    % We now have a all of our images loaded into a single matrix.  The matrix
    % is MUCH wider than it is tall.  Regardless of a matrix's shape, though,
    % we can always perform Principal Component Analysis.
    [coeff,score,~,~,explained,mu] = pca(images);


    %% Plot the PCA results

    %%
    % How many "eigenfaces" do we need to explain most of the variation?
    figure();
    pareto(explained);
    title('percentage of variation explained by first n eigenfaces');

    %%
    % What do the "eigenfaces" look like?
    h = figure();
    h.Position = [h.Position(1)/2 h.Position(2)-h.Position(4) h.Position(3)*2 h.Position(4)*2];
    subplot(5,3,1);
    imagesc(reshape(mu, img_size));
    title('mean face');
    for f=1:max(size(coeff,2), 5*3-1)
        subplot(5,3,f+1);
        imagesc(reshape(coeff(:,f), img_size));
        set(gca, 'XTickLabel',{}, 'YTickLabel',{});
        title(sprintf('eigenface #%u', f));
    end
    colormap gray;


    %% Eigenfaces as low-dimensional features for facial recognition
    % Plot the projections of the normal faces onto the first two eigenfaces
    figure();
    plot(score(:,1), score(:,2), '.', 'MarkerSize',14)
    for f=1:size(score,1)
        text(score(f,1)+0.01*diff(xlim()), score(f,2), num2str(f));
    end
    xlabel('eigenface #1 score');
    ylabel('eigenface #2 score');
    title('2-dimensional encoding of the faces');

    %%
    % Plot several variants of one subject's face to demonstrate that even in
    % low dimensions this person can be identified
    hold on;
    for variation={'happy', 'sad', 'surprised', 'wink'}
        filename = sprintf('subject01.%s.gif', variation{1});
        x = get_image_pixel_vector(filename);
        x_scores = (x - mu) * coeff;
        plot(x_scores(1), x_scores(2), 'x', 'MarkerSize',12)
        text(x_scores(1)+0.01*diff(xlim()), x_scores(2), variation{1});
    end

    %%
    % For the normal face and a few of the variants, show what the
    % low-dimensional face looks like as we add more eigenfaces
    n = 16;
    h = figure();
    h.Position = [h.Position(1)/2 h.Position(2)-h.Position(4) h.Position(3)*2 h.Position(4)*2];
    function display_scored_image(filename, img_title, row)
        % Get the pixel vector for this image
        x = get_image_pixel_vector(filename);

        % Get the scores for this image in each of the eigendirections
        x_scores = (x - mu) * coeff;

        % Plot the original image
        subplot(3, n, n*row + 1);
        imagesc(reshape(x, img_size));
        set(gca, 'XTickLabel',{}, 'YTickLabel',{});
        title(img_title);

        % Plot the mean value of all of the "normal" faces
        subplot(3, n, n*row + 2);
        imagesc(reshape(mu, img_size));
        set(gca, 'XTickLabel',{}, 'YTickLabel',{});
        title('mean');

        for ff=1:(n-2)
            % Plot the mean plus the first ff eigenfaces
            subplot(3, n, n*row + 2+ff);
            imagesc(reshape(mu + x_scores(1:ff) * coeff(:,1:ff)', img_size));
            set(gca, 'XTickLabel',{}, 'YTickLabel',{});
            title(sprintf('1-%u', ff));
        end

        colormap gray;
    end % display_scored_image()

    display_scored_image('subject01.normal.gif', 'normal', 0);
    display_scored_image('subject01.sad.gif', 'sad', 1);
    display_scored_image('subject01.wink.gif', 'wink', 2);

end % eigenfaces()
