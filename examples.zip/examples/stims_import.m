%% Well Stimulation Example
% The STIMS.XLSX spreadsheet contains information about most of the
% *well stimulations* that have been performed at a particular
% producing unit (PU).  The PU has wells spread across 6 different *fields*,
% which are several kilometers apart so may be geologically different.  As
% production starts to decline, the wells are stimulated by pumping fluid down
% the tubing and into the reservoir rock, hopefully removing any sand that
% might be blocking the flowpath of hydrocarbons into the wellbore.  There are
% three basic kinds of fluids or *stim types* used: a low salinity brine,
% a high salinity brine, and an enhanced fluid which is diesel-based rather
% than water-based.  The *uplift* is the average production rate (in bbls/day)
% after the stimulation minus the average production rate before the
% stimulation.  Yes, some of the wells have negative uplifts, which means that
% the stimulation did more harm than good.
%
% The business wants to know if they should use more enhanced stimulations in
% the future.  What would you tell them if this were the only data you had?


%% Get the raw data from the Excel file

%%
% It often only takes one line of code to import a table from Excel into Matlab.
% Use either XLSREAD to get an *array* or READTABLE to get a *table*.
X = readtable('stims.xlsx');

%%
% Columns containing strings are imported as cell arrays.  We want to treat
% them as *categorical variables*, i.e. as codes for a small number of
% possibilities rather than as arbitrary pieces of text.
X.StimType = categorical(X.StimType);
X.Field    = categorical(X.Field);

%%
% These are not *ordinal variables*, so the ordering of the categories only
% matters when we make plots.  By default the categories are in alphabetical
% order.  Reorder the categories so that the are in descending order by
% population count.
field_names  = categories(X.Field);
field_counts = countcats(X.Field);
[~,idx] = sort(field_counts, 'descend');
X.Field = reordercats(X.Field, field_names(idx));
clear field_names field_counts idx; % those are the old orders

stim_type_names  = categories(X.StimType);
stim_type_counts = countcats(X.StimType);
[~,idx] = sort(stim_type_counts, 'descend');
X.StimType = reordercats(X.StimType, stim_type_names(idx));
clear stim_type_names stim_type_counts idx; % those are the old orders



%% Plot the data

%%
% Print a textual overview of the data table
summary(X);

%%
% Plot Uplift vs. StimType
figure();
histogram(X.StimType);
xlabel('StimType');
ylabel('number of stimulations');
figure();
boxplot(X.Uplift, X.StimType);
xlabel('StimType');
ylabel('Uplift');

%%
% Plot Uplift vs. Field
figure();
histogram(X.Field);
xlabel('Field');
ylabel('number of stimulations');
figure();
boxplot(X.Uplift, X.Field);
xlabel('Field');
ylabel('Uplift');

%%
% Try to plot everything all together
figure();
fields     = categories(X.Field);
stim_types = categories(X.StimType);
symbols = {'.', 'x', 'o'};
colors  = {'g', 'r', 'b'};
jitter = 0.05 * randn(size(X.Field));
for t=1:numel(stim_types)
    tf = (X.StimType == stim_types{t});
    plot(double(X.Field(tf)) + jitter(tf), X.Uplift(tf), symbols{t}, ...
         'MarkerSize',10, 'Color',colors{t});
    hold on;
end
legend(stim_types);
set(gca, 'XTick',1:numel(fields), 'XTickLabel',fields, 'XLim',[0.5,numel(fields)+0.5]);
xlabel('Field');
ylabel('Uplift');

