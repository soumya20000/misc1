function [tf_outlier,tf_leverage,tf_influential] = rd_influence_plot2(mdl)
%RD_INFLUENCE_PLOT2    Regression Diagnostic - Fox's Influence Plot
%    Given a MDL object as returned by the FITLM function, make
%    a scatter plot using common linear regression diagnostics for all of the
%    data used to fit the model:
%         discrepancy vs. leverage, area proportional to influence
%    Include common thresholds (vertical lines, horizontal lines, and red
%    highlighting on the points) to identify potentially problematic points.
%
%    Returns:
%    tf_outlier     - true if and only if a row is an extreme outlier under the
%                     OLS assumptions, i.e. the observed value of y is very
%                     unexpected given the observed values of X
%    tf_leverage    - true if and only if a row has high leverage, i.e. the
%                     observed values of X are very extreme relative to the
%                     rest of the training data
%    tf_influential - true if and only if a row has high influence under the
%                     OLS assumptions, i.e. if removing this row induces
%                     a large change in the coefficient estimates

    % Validate the inputs
    N     = mdl.NumObservations;
    p     = mdl.NumCoefficients;
    alpha = 0.05; % critical p-value for outlier threshold

    % Cook's distance for the ith point is, up to a scale factor, the distance
    % between the vector of fitted values with and without the ith point
    % included in the model.  It is therefore a measure of the influence that
    % the ith point has on the entire fit.
    % cd_huge - If D_i > cd_huge, then deleting point i would move the
    %           coefficients beyond their 50% confidence interval.  This is
    %           a common threshold for elimination of influential points.
    % cd_big  - In a perfectly balanced design, h_{ii}=p/N and D_i=r_i^2/(N-p),
    %           where r_i is the internally Studentized residual.  Since r_i is
    %           approximately Gaussian, then about 95% of the r_i should be
    %           between -2 and +2.  This is a common heuristic for flagging
    %           points for further study.
    cd_huge = finv(0.5, p, N-p);
    cd_big  = 4 / (N - p);
    tf_influential = mdl.Diagnostics.CooksDistance > cd_huge;

    % Build the basic plot
    figure();
    cd_range = prctile(mdl.Diagnostics.CooksDistance, [2.5 97.5]);
    size1 = 4;
    size2 = 100;
    sizes =   size1                              ...
            +   (size2 - size1) / diff(cd_range) ...
              * (min(cd_range(2),max(cd_range(1),mdl.Diagnostics.CooksDistance)) - cd_range(1));
    tf = mdl.Diagnostics.CooksDistance < cd_big;
    scatter(mdl.Diagnostics.Leverage(tf),  ...
            mdl.Residuals.Studentized(tf), ...
            sizes(tf), 'b', 'filled');
    xlabel({'\bf leverage',    '\rm(diagonals of hat matrix)'});
    ylabel({'\bf discrepancy', '\rm(externally Studentized residuals)'});
    title( {'\bf influence',   '\rm(area proportional to Cook''s D)'});

    % Highlight the points with high values of Cook's D
    hold on;
    tf =   (mdl.Diagnostics.CooksDistance >= cd_big) ...
         & (mdl.Diagnostics.CooksDistance < cd_huge);
    scatter(mdl.Diagnostics.Leverage(tf),  ...
            mdl.Residuals.Studentized(tf), ...
            sizes(tf), 'b', 'filled', 'MarkerEdgeColor','r');
    tf = mdl.Diagnostics.CooksDistance >= cd_huge;
    scatter(mdl.Diagnostics.Leverage(tf),  ...
            mdl.Residuals.Studentized(tf), ...
            1.5*size2, 'r', 'filled');

    % The externally Studentized residuals are t_{N-p-1}-distributed under the
    % null hypothesis that there is no additive bias in the measurements.  We
    % use this to compute the threshold beyond which about 5% of the points
    % should lie.  We also use this, along with a Bonferroni correction, to
    % identify the threshold beyond which points are unlikely (at the 5% level)
    % to be found in a set of this size.
    t_critical = abs(tinv(alpha/2, N-p-1));
    hh(1) = plot(xlim(), -t_critical + [0,0], ':r', 'LineWidth',1);
    hh(2) = plot(xlim(), +t_critical + [0,0], ':r', 'LineWidth',1);
    t_critical = abs(tinv(alpha/2/N, N-p-1));
    hh(3) = plot(xlim(), -t_critical + [0,0], '--r', 'LineWidth',2);
    hh(4) = plot(xlim(), +t_critical + [0,0], '--r', 'LineWidth',2);
    tf_outlier = abs(mdl.Residuals.Studentized) > t_critical;

    % A "leverage point" is often defined as a point with leverage more than
    % twice the average, i.e. with leverage > 2p/N (because the sum of the
    % leverages is always exactly equal to p).  For small samples, this can
    % result in too many leverage points, so 3p/N may be used instead.
    hv(1) = plot(min(2*p/N,1)+[0,0], ylim(), ':k');
    hv(2) = plot(min(3*p/N,1)+[0,0], ylim(), ':k');
    tf_leverage = mdl.Diagnostics.Leverage > 3*p/N;

    % Make sure that the leverage axis extends all the way to 0 and doesn't
    % extend past 1 (all leverages are between 0 and 1, so it shouldn't), and
    % that the residual axis is symmetric about 0.
    xlim([0, min(1,max(abs(xlim())))]);
    ylim([-1,+1] * max(abs(ylim())));
    set(hh, 'XData',xlim());
    set(hv, 'YData',ylim());
end % rd_influence_plot2()
