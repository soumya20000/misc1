function [y_hat,y_hat_sigma] = tb_parametric(tb, column_index, column_values)
%TB_PARAMETRIC    Perform a parametric study using a TreeBagger
%    Given a TreeBagger TB already built by the user, compute out-of-bag
%    predictions for each of the training samples at each of a given set
%    COLUMN_VALUES of different values for predictor variable number
%    COLUMN_INDEX.  COLUMN_INDEX may be a vector, in which case each row in
%    COLUMN_VALUES is a single set of predictor variable values to be evaluated.

    % Validate the inputs
    assert(nargin==3, 'TB_PARAMETRIC requires exactly 3 input parameters');
    assert(isscalar(tb) && strcmp(class(tb),'TreeBagger'), ...
           'TB_PARAMETRIC requires a TreeBagger object as its first argument');
    assert(tb.ComputeOOBPrediction, ...
           'TB_PARAMETRIC requires the random forest to have been constructed with the OOBPRED option set to ON');
    assert(   isnumeric(column_index)                                 ...
           && all(column_index>0) && all(column_index<=size(tb.X,2)), ...
           'TB_PARAMETRIC requires a column index as its second parameter');
    if (numel(column_index) ~= size(column_values,2))
        column_values = column_values';
    end
    assert(numel(column_index) == size(column_values,2), ...
           'COLUMN_VALUES must have one column for every COLUMN_INDEX');
    num_iterations = size(column_values, 1);
    num_samples    = size(tb.X,1);
    num_trees      = tb.NTrees;

    % Make a new sample set consisting of stacked duplicates of the training
    % set, but sequentially replace the column of interest by the values of
    % interest.
    X = repmat(tb.X, num_iterations, 1); % stacked duplicates
    for k=1:num_iterations
        X(((k-1)*num_samples+1):(k*num_samples), column_index) ...
            = repmat(column_values(k,:), num_samples, 1);
    end

    % For each tree in the forest, compute estimates for the out-of-bag samples.
    % Iterating over the trees rather than over the samples seems to speed
    % things up by a few orders of magnitude.
    predictions = NaN(num_samples, num_iterations, num_trees);
    for t=1:num_trees
        oob_indices = tb.OOBIndices(:,t);
        if (any(oob_indices))
            tmp = tb.predict(X(repmat(oob_indices,num_iterations,1),:), ...
                             'trees',t);
            predictions(oob_indices,:,t) ...
                = reshape(tmp, sum(oob_indices), num_iterations);
        end
    end

    % For each sample, compute the mean and variance of the out-of-bag
    % predictions
    y_hat       = nanmean(predictions, 3);
    y_hat_sigma = nanstd(predictions, 0, 3);
end % tb_parametric()
