%% DEMO - Cross-plots are not sufficient to find important predictors.
% The first thing we usually do on any data analytics project is plot all of
% the data.  For example, the Matlab functions |plotmatrix|
% <https://www.mathworks.com/help/matlab/ref/plotmatrix.html>
% or |gplotmatrix|
% <https://www.mathworks.com/help/stats/gplotmatrix.html>
% may be used to plot all of the variables against each other.  This is
% important to understand the data and to identify possible relationships.
% However, we often make the mistake of concluding that there isn't an
% important relationship between two variables if the relationship isn't
% visibly obvious in the cross-plot of those two variables.  Most real
% relationships are multivariate.  When looking at individual cross-plots, you
% can only hope to see a univariate part of the multivariate relationship.
% When the true relationship is high-dimensional, individual cross-plots will
% have almost no visible relationship.  This is true even for the simplest
% relationships (linear functions) and the simplest data (noise-free), as we
% demonstrate here.

%% Build a high-dimensional data set.
% Note that Y is a noise-free, linear function of X.
% We're only using random numbers to generate X, not Y.
RandStream.getGlobalStream.reset(); % ensure that we get the same results
                                    % every time we run the code
coefficients = [1.1 ; 1.5 ; 2.8 ; -0.5 ; -1.6 ; 3.1];
X = randn(1e3, numel(coefficients)-1); % the first coefficient is the constant
Y = coefficients(1) + X*coefficients(2:end);

%% Build a linear model.
% Since the data is noise-free, the model is a perfect fit.
mdl = fitlm(X, Y)

%% Make cross-plots of Y vs. X_i.
% Despite the fact that the model is perfect, when we project it down into
% a 2-dimensional scatter plot, we might not see much of a pattern.
% A good way to understand this is through $R^2$:  each variable can only
% explain a fraction of the total variation in Y.
for k=1:size(X,2)
    figure();
    plot(X(:,k), Y, '.');
    xlabel(sprintf('X_%d', k));
    ylabel('Y');
    rho = corr(X(:,k), Y);
    title(sprintf('correlation = %.3f, R^2 = %.3f', rho, rho^2));
end
