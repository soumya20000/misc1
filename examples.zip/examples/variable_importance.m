function h = variable_importance(scores, names, errors, force_rg)
%    This is a small extension of the BARH function which plots the SCORES in
%    descending order from top to bottom and applies the associated NAMES to
%    the y-ticks.  If the scores all have the same sign, then the bars will all
%    be blue; otherwise, the negative SCORES will be red and the positive
%    SCORES will be green.

    % Validate the inputs
    assert((nargin >= 1) & (nargin <= 4), ...
           'VARIABLE_IMPORTANCE expects between 1 and 4 inputs');
    if (nargin < 2)
        names = {};
    else
        assert(iscell(names) & (numel(names) == numel(scores)), ...
               'VARIABLE_IMPORTANCE expects a cell array of names as its second argument');
    end
    if (nargin < 3)
        errors = [];
    else
        assert(isnumeric(errors) & (numel(errors) == numel(scores)), ...
               'VARIABLE_IMPORTANCE expects a numeric array of error bar half-widths as its third argument');
    end
    if (nargin < 4)
        force_rg = false;
    else
        assert(isscalar(force_rg) & islogical(force_rg), ...
               'VARIABLE_IMPORTANCE expects a logical scalar for its fourth argument');
    end


    % Make the bar plot
    [~,idx] = sort(scores, 'ascend');
    tf_neg = scores(idx) < 0;
    h = figure();
    if (~any(tf_neg) && ~force_rg)
        barh(1:numel(idx), scores(idx), 'b', 'EdgeColor','b');
    elseif (all(tf_neg) && ~force_rg)
        barh(1:numel(idx), scores(idx), 'b', 'EdgeColor','b');
    else
        barh(1:sum(tf_neg), scores(idx(tf_neg)), 'r', 'EdgeColor','r');
        hold on;
        plot([0,0], [0.25,sum(tf_neg)+0.5], '-r');
        barh(sum(tf_neg) + (1:sum(~tf_neg)), scores(idx(~tf_neg)), 'g', 'EdgeColor','g');
        plot([0,0], [numel(scores)+0.75,sum(tf_neg)+0.5], '-g');
    end


    % Add error bars (if requested)
    if isempty(errors)
        % When we created the bar chart above, we set the EdgeColor equal to
        % the FaceColor rather than leaving it as black.  This allows the bars
        % to look a little "fuzzier" than they would if they had sharp black
        % edges, which is a nice visual complement to the error bars.  If no
        % error bars are being plotted, go back to the default sharp edges.
        set(findobj(gca, 'Type','Bar'), 'EdgeColor','k');
    else
        hold on;
        for k=1:numel(scores)
            x1 = scores(idx(k)) - abs(errors(idx(k)));
            x2 = scores(idx(k)) + abs(errors(idx(k)));
            plot([x1,x2], [k,    k],     '-k');
            plot([x1,x1], [k-0.1,k+0.1], '-k');
            plot([x2,x2], [k-0.1,k+0.1], '-k');
        end
    end


    % Label the bars (if requested)
    ax = get(h, 'Children');
    set(ax, 'YTick',1:numel(scores));
    if ~isempty(names)
        set(ax, 'YTickLabel',regexprep(names(idx), '_', '\\_'));
    end
    ylim([0.25, numel(scores)+0.75]);


    % Clean up the axis limits
    xl = max(abs(scores));
    if ~isempty(errors)
        xl = max([xl, max(abs(scores+errors)), max(abs(scores-errors))]);
    end
    xl = xl * 1.05;
    if (~any(tf_neg) && ~force_rg)
        % Make the plot extend all the way to x=0 on the left
        xlim([0, xl]);
    elseif (all(tf_neg) && ~force_rg)
        % Make the plot extend all the way to x=0 on the right
        xlim([-xl, 0]);
    else
        % Make the plot symmetric about x=0
        xlim([-xl,+xl]);
    end

end % variable_importance()
