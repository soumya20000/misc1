function vifs = rd_vif(X)
%RD_VIF    Compute the Variance Inflation Factors for every column in X
    p = size(X,2);
    vifs = NaN(1, p);
    for k=1:p
        stats = regstats(X(:,k), X(:,[1:(k-1), (k+1):end]), ...
                         'linear', {'rsquare'});
        vifs(k) = 1 / (1 - stats.rsquare);
    end
end % rd_vif()
