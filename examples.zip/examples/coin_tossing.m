%% Coin Tossing Example
% Suppose you flip a coin over and over again.  At some point, you are sure to
% get the same result on consecutive flips.  In fact, if you flip the coin long
% enough, you are sure to get a "run" of consecutive heads or consecutive tails
% of any length.  This example uses Monte Carlo simulation to study the longest
% "run" one might see in a fixed number of coin tosses.

%% Main function
% *MATLAB NOTE*:  We wrap our entire example in a function because:
%
% # We would like the user to be able to easily change the parameters
% # We need to define another function inside, and in Matlab functions can only
% be defined inside of other functions.
function coin_tossing(num_tosses, num_simulations)


    %% Helper function
    % Our Monte Carlo simulation will flip the coin, and this function will
    % find the longest run of consecutive heads or tails in the flips.
    %
    % *MATLAB NOTE*:  Loops are slow.  This function could be "vectorized" to
    % be more efficient.  For example,
    %
    %   max_run = max( diff( [0, find(diff(tosses)), numel(tosses)] ) );
    %
    % would be more efficient but also more inscrutable.  Such tricks are
    % often necessary in Matlab, but clarity should be prioritized above speed.
    function max_run = longest_run(tosses)
        % Count each "run" of heads and tails from the simulated sequence of
        % coin tosses.
        runs = [1];
        for k=2:numel(tosses)
            if (tosses(k) == tosses(k-1))
                runs(end) = runs(end) + 1;
            else
                runs(end+1) = 1;
            end
        end

        % Return only the length of the longest run.
        max_run = max(runs);
    end



    %% Set-up
    % Set defaults for any parameters not specified by the user and
    % pre-allocate the array of results.

    %%
    % *MATLAB NOTE*:  Use NARGIN to tell whether or not the user passed in the
    % parameters.  If not, set them to defaults.
    if (nargin < 1)
        num_tosses = 100;
    end
    if (nargin < 2)
        num_simulations = 1000;
    end

    %%
    % *MATLAB NOTE*:  In Matlab (like all programming languages),
    % pre-allocation of memory is much more efficient than resizing the array
    % every iteration through a loop.  You should almost always use NAN rather
    % than ZEROS or ONES because that makes it much easier to tell whether or
    % not you've forgotten to fill in the entire array.
    sim_long = NaN(num_simulations, 1);



    %% Monte Carlo simulation
    % Execute the Monte Carlo simulation one trial at a time.
    %
    % *DATA ANALYTICS QUESTION*:  How many Monte Carlo simulations should we
    % use?
    %
    % *MATLAB NOTE*:  RAND is a built-in pseudo-random number generator whose
    % results are uniformly distributed in the interval (0,1).  By rounding, we
    % get something that is 0 half the time and 1 half the time.
    %
    % *MATLAB NOTE*:  The Matlab function RANDOM generates pseudo-random
    % numbers for any standard probability distribution.  That might make this
    % code more clear than the rounding trick used here:
    %
    %    pd = makedist('Binomial', 'N',1, 'p',0.5);
    %    tosses = random(pd, 1, num_tosses);
    %
    % *MATLAB NOTE*:  Sometimes we can use vectorization tricks to execute all
    % simulations with one command.  For example,
    %
    %    tosses = round( rand(num_simulations, num_tosses) );
    %
    % would toss all of our coins at the same time.
    %
    % *DATA ANALYTICS NOTE*:  In statistical jargon, a set of NUM_TOSSES
    % coin flips is a single *sample* for this analysis.  The longest run of
    % heads or tails in a single sample is the *statistic* we have chosen to
    % study.
    for s=1:num_simulations
        % Simulate tossing a coin NUM_TOSSES times.
        tosses = round( rand(1,num_tosses) );

        % Find the longest run in the sample.
        sim_long(s) = longest_run(tosses);
    end



    %% Results
    % Plot the data as a histogram.
    %
    % *MATLAB NOTE*:  Matlab's HISTOGRAM function does a good job of
    % automatically choosing a good number of bins (there are even
    % "theoretically optimal" bin counts!).  Here I'm just telling it
    % explicitly that I want one bin per integer, which is appropriate for this
    % particular data set.
    figure();
    histogram(sim_long, 'BinMethod','integers');

    % Make sure to extend the x-axis all the way to 0 to avoid one of the
    % famous methods to "lie with statistics".
    xlim([0,max(xlim())]);

    % Plot the mean value
    hold on;
    mean_value = mean(sim_long);
    plot(mean_value + [0,0], ylim(), '--k');

    % Plot the 95% prediction interval
    prediction_interval = prctile(sim_long, [2.5 97.5]);
    plot(prediction_interval(1) + [0,0], ylim(), ':k');
    plot(prediction_interval(2) + [0,0], ylim(), ':k');

    % Fully annotate the plot if you're going to show it to anyone.
    %
    % *MATLAB NOTE*:  Use a cell array to make multiline titles.
    xlabel('longest "run" of heads or tails');
    ylabel('Monte Carlo simulation count');
    title( {'What is the longest run of heads or tails'; ...
            sprintf('in %d tosses of a fair coin?', num_tosses)} );
    legend( {'Monte Carlo results';                         ...
             sprintf('mean (%.1f)', mean_value);            ...
             '95% prediction interval';                     ...
             sprintf('(%.1f,%.1f)', prediction_interval(1), ...
                                    prediction_interval(2))} );



    %% Discussion
    % This simple example illustrates many of the most important concepts in
    % statistics:
    %
    % * A *sample* is a single piece of data available to you.  The goal of
    % statistics is to try to understand something about a *population* when you
    % can only look at a few samples.  A sample is often just one number,
    % but in this case the population we are interested in is the set of
    % sequences of NUM_TOSSES coin flips, so a single sample has NUM_TOSSES
    % heads and tails.
    %
    % * The *sample size* is the total number of samples you collect.  In this
    % case, it is NUM_SIMULATIONS.  A big part of the statistical design of
    % experiments is quantifying the tradeoffs between sample size and the
    % chance of a successful experiment.  This should always be tied to
    % what you are trying to learn.
    %
    % * A *statistic* is just a number (or set of numbers) that you compute as
    % a function of your sample.  Classical statistical theorems usually apply
    % to statistics like the mean value of a sample.  However, YOU must
    % choose the statistic that you want to study based on what YOU think will
    % give you the best evidence for YOUR problem.  In this case, our statistic
    % is the longest run of heads or tails in the sample, which is much more
    % complicated than just the mean or median, but still a perfectly valid
    % statistic.  The reason we chose it is because there is anecdotal evidence
    % that this is a good discriminator of human-generated vs. coin-generated
    % sequences of heads and tails, whereas other statistics (e.g. the fraction
    % of heads) are not as useful for THIS particular problem.
    %
    % * A *confidence interval* is the range of values of some population-level
    % quantity that still seem like reasonable estimates given what you have
    % learned from the samples.  This typically shrinks as your sample size
    % increases.  For instance, we could draw a very tight confidence interval
    % around the mean value of the longest run since we have so many samples.
    %
    % * A *prediction interval* is like a confidence interval for a prediction
    % of some quantity on a new sample.  Prediction intervals will get narrower
    % as the confidence intervals around population parameters get narrower,
    % i.e. we can be more confident about future predictions as we learn more
    % about the system that is generating our samples.  However, prediction
    % intervals will never shrink to 0 because there will always be noise in
    % the system.  In this case, our prediction interval is quite wide even
    % though we know the mean very precisely because what we're trying to
    % predict (the longest run in a future sample of NUM_TOSSES coin flips) is
    % so variable.
    %
    % * A *p-value* is a measure of evidence for some hypothesis.  Let's not
    % confuse things by trying to define it precisely and just say how it would
    % be used.  If we get a new sample from someone and the longest run is
    % outside of our 95% prediction interval, then it is so extreme (small or
    % large) that it would seem inconsistent with our hypothesis that it was
    % generated by a perfectly random coin.  We would therefore "reject" this
    % hypothesis with p<0.05.  Similarly, if the new run were outside of our
    % 99% prediction interval, we would "reject" with p<0.01.

end
