%% Introduction to Gaussian Processes
% This notebook provides a simple introduction to Gaussian Processes.
% For (much) more detail, see the book
% "Gaussian Processes for Machine Learning" by Rasmussen and Williams
% <http://www.gaussianprocess.org/gpml/ [website]>



%% From Random Numbers to Random Curves

%%
% Make sure we get the same results every time we run this script.
RandStream.getGlobalStream.reset();

%%
% Matlab includes many (pseudo-)random number generators.  We ordinarily
% use the |randn| function to generate Gaussian random numbers.  The |mvnrnd|
% function generalizes |randn|, allowing us to generate multivariate Gaussian
% random vectors with arbitrary covariance matrices.  Obviously a scalar is
% just a 1-vector, so we can also use |mvnrnd| to generate independent Gaussian
% random numbers.
mean_vector_1       = 0;
covariance_matrix_1 = 1;
random_sample_1     = mvnrnd(mean_vector_1, covariance_matrix_1, 1e3);
figure();
histogram(random_sample_1);
title(sprintf('Sample of %u random numbers', size(random_sample_1,1)));

%%
% Now we demonstrate how to generate _pairs_ of Gaussian random numbers.  The
% |mvnrnd| function allows us to enter a full covariance matrix for the
% multivariate Gaussian.  We will use a relatively high correlation coefficient
% of 0.8, so every pair we generate will tend to be close together.
%
% Notice that the scatter plot is skewed due to the high correlation
% coefficient.  The points are closer to a 45 degree line than to a random disk
% of points that we would expect had the correlation coefficient been 0.
% However, you should also note that, even though the pairs of points were
% drawn simultaneously, the *marginal distributions* of the individual
% components look like typical bell curves.  This is a nice property of
% multivariate Gaussian distributions:  their marginal distributions are also
% Gaussian.
mean_vector_2       = [0 0];
covariance_matrix_2 = [1.0 0.8 ; ...
                       0.8 1.0];
random_sample_2     = mvnrnd(mean_vector_2, covariance_matrix_2, 1e3);
figure();
scatterhist(random_sample_2(:,1), random_sample_2(:,2));
title(sprintf('Sample of %u pairs of random, correlated numbers', ...
              size(random_sample_2,1)));

%%
% We usually plot pairs of numbers using a scatter plot, as we did above.
% However, we can also use line plots.  Here the first element of each random
% pair is plotted at $x=0$, and the second element of each random pair is
% plotted at $x=1$.
n = 10;
figure();
plot(repmat([0;1], 1, n), random_sample_2(1:n,:)', '.-', 'MarkerSize',12);
xlim([-0.1, +1.1]);
title(sprintf('Sample of %u pairs of random, correlated numbers', n));

%%
% Similarly, instead of plotting random triples as 3-dimensional scatter plots,
% we can plot them as line plots connecting $x=0$, $x=1$, and $x=2$.
% This technique becomes extremely helpful as we run out of plottable
% dimensions very quickly.
mean_vector_3       = [0 0 0];
covariance_matrix_3 = [1.0   0.8 0.8^4 ; ...
                       0.8   1.0 0.8   ; ...
                       0.8^4 0.8 1.0]  ;
random_sample_3     = mvnrnd(mean_vector_3, covariance_matrix_3, n);
figure();
plot(repmat([0;1;2], 1, n), random_sample_3', '.-', 'MarkerSize',12);
xlim([-0.1, +2.1]);
title(sprintf('Sample of %u triples of random, correlated numbers', n));

mean_vector_4       = [0 0 0 0];
covariance_matrix_4 = [1.0   0.8   0.8^4 0.8^9 ; ...
                       0.8   1.0   0.8   0.8^4 ; ...
                       0.8^4 0.8   1.0   0.8   ; ...
                       0.8^9 0.8^4 0.8   1.0  ];
random_sample_4     = mvnrnd(mean_vector_4, covariance_matrix_4, n);
figure();
plot(repmat([0;1;2;3], 1, n), random_sample_4', '.-', 'MarkerSize',12);
xlim([-0.1, +3.1]);
title(sprintf('Sample of %u quadruples of random, correlated numbers', n));

xs_101                = 0:100;
mean_vector_101       = zeros(1, numel(xs_101));
covariance_matrix_101 = 0.8 .^ (bsxfun(@minus, xs_101, xs_101').^2);
random_sample_101     = mvnrnd(mean_vector_101, covariance_matrix_101, n);
figure();
plot(repmat(xs_101', 1, n), random_sample_101', '.-', 'MarkerSize',12);
xlim([xs_101(1)-0.1, xs_101(end)+0.1]);
title(sprintf('Sample of %u %u-tuples of random, correlated numbers', ...
              n, numel(xs_101)));

%%
% There is no particular reason to have chosen $x=0, 1, \ldots, d-1$ to plot
% our $d$-dimensional data.  We could just as easily have chosen to pack the
% points more tightly along the x-axis.  Once we start doing that, it is
% natural (for mathematicians, at least) to imagine having a Gaussian random
% variable associated with _every_ value of $x$, and allowing for arbitrary
% covariance structures among subsets of these random variables.
% Such an infinite collection of Gaussian random variables is called a
% *Gaussian Process*.



%% The Kernel Function
% We defined a Gaussian Process above, but we didn't specify the covariance
% structure among these infinitely many Gaussian random variables.  In
% principle, the choice of covariance structure is up to you, and may be
% arbitrarily complex.  Typically, however, we use Gaussian Processes with
% a covariance between random variables that is just a function of the
% $x$-coordinates to which the random variables are associated.  This is called
% a *kernel function*.

%%
% The simplest kernel function is a constant.  This is equivalent to all of the
% random variables being independent, regardless of how close together they are
% on the $x$-axis:
%
% $k(x, x') = \delta_{x x'}$.
%
% Such a Gaussian Process is called *white noise*.  Note that a sample from
% such a Gaussian Process does not look like a curve at all.
kernel_whitenoise = @(x1, x2)double(bsxfun(@eq, x1(:), x2(:)'));
xs                = 0:0.1:100;
mean_vector       = zeros(1, numel(xs));
covariance_matrix = kernel_whitenoise(xs, xs);
fprintf('      ');
for j=1:5
    fprintf('\tx''=%.1f        ', xs(j));
end
fprintf('\n');
for i=1:5
    fprintf('x=%.1f', xs(i));
    for j=1:5
        fprintf('\tk(x,x'')=%.4f', covariance_matrix(i,j));
    end
    fprintf('\n');
end
random_sample     = mvnrnd(mean_vector, covariance_matrix, n);
figure();
plot(repmat(xs', 1, n), random_sample', '-');
xlim([xs(1)-0.1, xs(end)+0.1]);
title(sprintf('%u samples of the white noise GP (%u points each)', ...
              n, numel(xs)));

%%
% Perhaps the most common kernel function used for Gaussian Processes is
% the *squared exponential kernel*.  It specifies that the covariance between
% the random variable at $x$ and the random variable at $x'$ is equal to:
%
% $k(x, x';\lambda) = \exp\left[ -|x - x'|^2 / (2\lambda^2) \right]$
%
% where $\lambda$ is the *length scale*.  Note that samples from such Gaussian
% processes look like very smooth curves.  This is intuitive since, when $x$
% and $x'$ are close together, the correlation coefficient between the
% associated random variables is close to 1, so the values at $x$ and $x'$ will
% tend to be close together.
kernel_sqexp      = @(x1, x2, lambda)exp(-bsxfun(@minus, x1(:), x2(:)').^2 / (2*lambda^2));
length_scale      = 5;
xs                = 0:0.1:100;
mean_vector       = zeros(1, numel(xs));
covariance_matrix = kernel_sqexp(xs, xs, length_scale);
fprintf('      ');
for j=1:5
    fprintf('\tx''=%.1f        ', xs(j));
end
fprintf('\n');
for i=1:5
    fprintf('x=%.1f', xs(i));
    for j=1:5
        fprintf('\tk(x,x'')=%.4f', covariance_matrix(i,j));
    end
    fprintf('\n');
end
random_sample     = mvnrnd(mean_vector, covariance_matrix, n);
figure();
plot(repmat(xs', 1, n), random_sample', '-');
xlim([xs(1)-0.1, xs(end)+0.1]);
title(sprintf('%u samples of the squared-exponential-kernel (\\lambda=%.1f) GPs (%u points each)', ...
              n, length_scale, numel(xs)));

%%
% Notice that the curves tend to vary over distances in $x$ of about 5,
% which happened to be the length scale we chose.  To see that this is
% a general property of squared exponential kernels, let's draw samples of
% a Gaussian Process with a different length scale.
length_scale      = 20;
mean_vector       = zeros(1, numel(xs));
covariance_matrix = kernel_sqexp(xs, xs, length_scale);
fprintf('      ');
for j=1:5
    fprintf('\tx''=%.1f        ', xs(j));
end
fprintf('\n');
for i=1:5
    fprintf('x=%.1f', xs(i));
    for j=1:5
        fprintf('\tk(x,x'')=%.4f', covariance_matrix(i,j));
    end
    fprintf('\n');
end
random_sample     = mvnrnd(mean_vector, covariance_matrix, n);
figure();
plot(repmat(xs', 1, n), random_sample', '-');
xlim([xs(1)-0.1, xs(end)+0.1]);
title(sprintf('%u samples of the squared-exponential-kernel (\\lambda=%.1f) GPs (%u points each)', ...
              n, length_scale, numel(xs)));

%%
% Other kernels may be used to get behavior in between smooth curves
% and white noise.  For example, the *exponential kernel* is of the form
%
% $k(x, x';\lambda) = \exp\left[ -|x - x'| / \lambda \right]$
%
% where $\lambda$ is the *length scale*.  Samples from such Gaussian Processes
% are still continuous, but are no longer differentiable (in a generalized
% sense that we won't make precise here).
kernel_exponential = @(x1, x2, lambda)exp(-abs(bsxfun(@minus, x1(:), x2(:)')) / lambda);
length_scale      = 20;
xs                = 0:0.1:100;
mean_vector       = zeros(1, numel(xs));
covariance_matrix = kernel_exponential(xs, xs, length_scale);
fprintf('      ');
for j=1:5
    fprintf('\tx''=%.1f        ', xs(j));
end
fprintf('\n');
for i=1:5
    fprintf('x=%.1f', xs(i));
    for j=1:5
        fprintf('\tk(x,x'')=%.4f', covariance_matrix(i,j));
    end
    fprintf('\n');
end
random_sample     = mvnrnd(mean_vector, covariance_matrix, n);
figure();
plot(repmat(xs', 1, n), random_sample', '-');
xlim([xs(1)-0.1, xs(end)+0.1]);
title(sprintf('%u samples of the exponential-kernel (\\lambda=%.1f) GP (%u points each)', ...
              n, length_scale, numel(xs)));



%% Conditioning on Observed Data
% You may wonder if Gaussian Processes are good for anything other than
% generating random curves.  The true strength of Gaussian Processes is that
% they can be conditioned on observed data.  Imagine that we want to model some
% curve as a Gaussian Process, but we _know_ some of the values.  For example,
% suppose we fix our kernel, but we want our curves to go through the point
% $(x,y) = (30, 1)$.  We can generate a large number of samples from our
% Gaussian Process and just keep those that go near this known point.
length_scale = 10;
kernel       = @(x1, x2)kernel_sqexp(x1, x2, length_scale);
xs                = 0:0.1:100;
mean_vector       = zeros(1, numel(xs));
covariance_matrix = kernel(xs, xs);
random_sample     = mvnrnd(mean_vector, covariance_matrix, 1e4);
observations      = [30, 1];
[~,obs_ind] = min(abs(xs - observations(1,1)));
idx_near_observations = find(  abs(random_sample(:,obs_ind) - observations(1,2))...
                             < 0.01); % 0.01 is an arbitrary tolerance
idx_near_observations = idx_near_observations(1:min(n,numel(idx_near_observations)));
figure();
plot(observations(:,1)', observations(:,2)', '.k', 'MarkerSize',40);
hold on;
plot(repmat(xs', 1, numel(idx_near_observations)), ...
     random_sample(idx_near_observations,:)',      ...
     '-');
xlim([xs(1)-0.1, xs(end)+0.1]);
title(sprintf('%u samples nearly matching observed data', ...
              numel(idx_near_observations)));

%%
% Now suppose we have two observations.  We can look for random samples that
% happen to be close to both of them.
observations = vertcat(observations, [70 -1]);
[~,obs_ind1] = min(abs(xs - observations(1,1)));
[~,obs_ind2] = min(abs(xs - observations(2,1)));
idx_near_observations = find(  (  abs(  random_sample(:,obs_ind1) ...
                                      - observations(1,2))        ...
                                < 0.1)                            ...
                             & (  abs(  random_sample(:,obs_ind2) ...
                                      - observations(2,2))        ...
                                < 0.1) ); % 0.1 is an arbitrary tolerance
idx_near_observations = idx_near_observations(1:min(n,numel(idx_near_observations)));
figure();
plot(observations(:,1)', observations(:,2)', '.k', 'MarkerSize',40);
hold on;
plot(repmat(xs', 1, numel(idx_near_observations)), ...
     random_sample(idx_near_observations,:)',      ...
     '-');
xlim([xs(1)-0.1, xs(end)+0.1]);
title(sprintf('%u samples nearly matching observed data', ...
              numel(idx_near_observations)));

%%
% This procedure does not scale well.  First, we have chosen a small but
% non-zero tolerance because the probability that a curve will _exactly_ match
% some observation is 0.  Second, the more observations we have, the lower the
% probability will be that any sample will come close to _all_ of the
% observations.  We are therefore in the awkward position of requiring an
% infinite number of sample curves in order to randomly find a few that happen
% to match our observations.  Fortunately there are exact formulae that can be
% used to update the mean and covariance matrices given observed data.  The
% details of the formulae are not important, but the fact that they exist and
% are easy to implement is quite valuable.
posterior_mean       =   kernel(xs, observations(:,1))                   ...
                       * (  kernel(observations(:,1), observations(:,1)) ...
                          \ observations(:,2));
posterior_covariance =   kernel(xs, xs)                                    ...
                       -   kernel(xs, observations(:,1))                   ...
                         * (  kernel(observations(:,1), observations(:,1)) ...
                            \ kernel(observations(:,1), xs));
posterior_sample     = mvnrnd(posterior_mean, posterior_covariance, n);
figure();
plot(observations(:,1)', observations(:,2)', '.k', 'MarkerSize',40);
hold on;
plot(repmat(xs', 1, n), posterior_sample', '-');
xlim([xs(1)-0.1, xs(end)+0.1]);
title(sprintf('%u samples exactly matching observed data', n));



%% Statistics
% Now that we can directly sample from the Gaussian Process conditioned on
% our observed data, we can compute various statistics for this new class of
% curves.  For instance, we can compute the mean value of the curves at every
% $x$ just by drawing a large number of samples and averaging them.  Similarly,
% we can compute 95% confidence intervals at every $x$ just by looking at the
% pointwise percentiles over all of our samples.
posterior_sample = mvnrnd(posterior_mean, posterior_covariance, 1e4);
figure();
f_mean  = mean(posterior_sample);
f_upper = prctile(posterior_sample, 97.5);
f_lower = prctile(posterior_sample,  2.5);
h1 = patch([xs xs(end:-1:1)],          ...
          [f_upper f_lower(end:-1:1)], ...
          [0.9 0.9 0.9], 'LineStyle','none');
hold on;
h2 = plot(xs, f_mean, '-b', 'LineWidth',2);
h3 = plot(observations(:,1)', observations(:,2)', '.k', 'MarkerSize',40);
h4 = plot(repmat(xs', 1, n), posterior_sample(1:n,:)', '-r');
legend([h3 h2 h1 h4(1)], {'observed values', 'approximate mean', 'approximate 95% confidence interval', 'sample curves'});
xlabel('x');
ylabel('function values');
title('Gaussian Process conditioned to observations');

%%
% We don't actually need to draw samples to estimate the means or the 95%
% confidence intervals.  The formulae above gave us the _exact_ means and
% covariances for the Gaussian Process conditioned on the observations.
figure();
f_upper = posterior_mean + 1.96*sqrt(diag(posterior_covariance));
f_lower = posterior_mean - 1.96*sqrt(diag(posterior_covariance));
h1 = patch([xs xs(end:-1:1)], ...
          [f_upper' f_lower(end:-1:1)'],   ...
          [0.9 0.9 0.9], 'LineStyle','none');
hold on;
h2 = plot(xs, posterior_mean, '-b', 'LineWidth',2);
h3 = plot(observations(:,1)', observations(:,2)', '.k', 'MarkerSize',40);
h4 = plot(repmat(xs', 1, n), posterior_sample(1:n,:)', '-r');
legend([h3 h2 h1 h4(1)], {'observed values', 'mean', '95% confidence interval', 'sample curves'});
xlabel('x');
ylabel('function values');
title('Gaussian Process conditioned to observations');

%%
% So now we can forget about sampling the curves altogether.  Let's demonstrate
% this by adding another observation.
observations = vertcat(observations, [50 -1.5]);
posterior_mean       =   kernel(xs, observations(:,1))                   ...
                       * (  kernel(observations(:,1), observations(:,1)) ...
                          \ observations(:,2));
posterior_covariance =   kernel(xs, xs)                                    ...
                       -   kernel(xs, observations(:,1))                   ...
                         * (  kernel(observations(:,1), observations(:,1)) ...
                            \ kernel(observations(:,1), xs));
figure();
f_upper = posterior_mean + 1.96*sqrt(diag(posterior_covariance));
f_lower = posterior_mean - 1.96*sqrt(diag(posterior_covariance));
h1 = patch([xs xs(end:-1:1)], ...
          [f_upper' f_lower(end:-1:1)'],   ...
          [0.9 0.9 0.9], 'LineStyle','none');
hold on;
h2 = plot(xs, posterior_mean, '-b', 'LineWidth',2);
h3 = plot(observations(:,1)', observations(:,2)', '.k', 'MarkerSize',40);
legend([h3 h2 h1], {'observed values', 'mean', '95% confidence interval'});
xlabel('x');
ylabel('function values');
title('Gaussian Process conditioned to observations');



%% Model Fitting
% In fact, we don't even have to cut and paste the formulae above.  Matlab has
% built-in routines for fitting Gaussian Processes to data.  When we assume
% that the mean is _known_ to be 0, this Gaussian Process is equivalent to
% *simple kriging*.
mdl = fitrgp(observations(:,1), observations(:,2), ...
             'BasisFunction','none',               ... % mean 0
             'KernelParameters',[length_scale 1],  ...
             'FitMethod','none',                   ... % fix kernel parameters
             'Sigma',1e-3);                            % noise-free observations
[posterior_mean,~,posterior_confidence_interval] = mdl.predict(xs');
figure();
h1 = patch([xs xs(end:-1:1)], ...
          [posterior_confidence_interval(:,2)' posterior_confidence_interval(end:-1:1,1)'],   ...
          [0.9 0.9 0.9], 'LineStyle','none');
hold on;
h2 = plot(xs, posterior_mean, '-b', 'LineWidth',2);
h3 = plot(observations(:,1)', observations(:,2)', '.k', 'MarkerSize',40);
legend([h3 h2 h1], {'observed values', 'mean', '95% confidence interval'});
xlabel('x');
ylabel('function values');
title('Gaussian Process conditioned to observations');

%%
% For our running example, we chose to fix the kernel parameters - the length
% scale and the variance of individual points.  Matlab can _fit_ these
% parameters to our data.
mdl = fitrgp(observations(:,1), observations(:,2), ...
             'BasisFunction','none',               ... % mean 0
             'Sigma',1e-3);                            % noise-free observations
[posterior_mean,~,posterior_confidence_interval] = mdl.predict(xs');
figure();
h1 = patch([xs xs(end:-1:1)], ...
          [posterior_confidence_interval(:,2)' posterior_confidence_interval(end:-1:1,1)'],   ...
          [0.9 0.9 0.9], 'LineStyle','none');
hold on;
h2 = plot(xs, posterior_mean, '-b', 'LineWidth',2);
h3 = plot(observations(:,1)', observations(:,2)', '.k', 'MarkerSize',40);
legend([h3 h2 h1], {'observed values', 'mean', '95% confidence interval'});
xlabel('x');
ylabel('function values');
title(sprintf('GP, length scale=%.1f, signal standard deviation=%.1f', ...
              mdl.KernelInformation.KernelParameters(1),               ...
              mdl.KernelInformation.KernelParameters(2)));

%%
% So far we have been assuming that the prior mean is exactly 0.  This is
% fairly common, and it causes the GP to move back towards 0 away from
% observations.  We might assume instead that the Gaussian Process has some
% underlying mean that might _not_ be 0, but we would like to estimate it along
% with the simple GP deviations away from that mean.  Such a Gaussian Process
% is equivalent to *ordinary kriging*.
mdl = fitrgp(observations(:,1), observations(:,2), ...
             'BasisFunction','constant',           ... % fit a nonzero mean
             'Sigma',1e-3);                            % noise-free observations
[posterior_mean,~,posterior_confidence_interval] = mdl.predict(xs');
figure();
h1 = patch([xs xs(end:-1:1)], ...
          [posterior_confidence_interval(:,2)' posterior_confidence_interval(end:-1:1,1)'],   ...
          [0.9 0.9 0.9], 'LineStyle','none');
hold on;
h2 = plot(xs, posterior_mean, '-b', 'LineWidth',2);
h3 = plot(observations(:,1)', observations(:,2)', '.k', 'MarkerSize',40);
h4 = plot(xs, mdl.Beta + 0*xs, '--r');
legend([h3 h4 h2 h1], {'observed values', sprintf('mean=%.1f', mdl.Beta), ...
                       'mean', '95% confidence interval'});
xlabel('x');
ylabel('function values');
title(sprintf('GP, length scale=%.1f, signal standard deviation=%.1f', ...
              mdl.KernelInformation.KernelParameters(1),               ...
              mdl.KernelInformation.KernelParameters(2)));

%%
% Gaussian Processes are even more flexible.  We might assume that instead of
% a constant mean, the simple Gaussian Process represents deviations from
% a linear trend, and we would like to fit the trend line and the GP
% simultaneously.  Such a Gaussian Process is equivalent to *universal kriging*.
mdl = fitrgp(observations(:,1), observations(:,2), ...
             'BasisFunction','linear',             ... % fit a linear trend
             'Sigma',1e-3);                            % noise-free observations
[posterior_mean,~,posterior_confidence_interval] = mdl.predict(xs');
figure();
h1 = patch([xs xs(end:-1:1)], ...
          [posterior_confidence_interval(:,2)' posterior_confidence_interval(end:-1:1,1)'],   ...
          [0.9 0.9 0.9], 'LineStyle','none');
hold on;
h2 = plot(xs, posterior_mean, '-b', 'LineWidth',2);
h3 = plot(observations(:,1)', observations(:,2)', '.k', 'MarkerSize',40);
h4 = plot(xs, mdl.Beta(1) + mdl.Beta(2)*xs, '--r');
legend([h3 h4 h2 h1], {'observed values',                   ...
                       sprintf('linear trend (%.1f+%.2fx)', ...
                               mdl.Beta(1), mdl.Beta(2)),   ...
                       'mean', '95% confidence interval'});
xlabel('x');
ylabel('function values');
title(sprintf('GP, length scale=%.1f, signal standard deviation=%.1f', ...
              mdl.KernelInformation.KernelParameters(1),               ...
              mdl.KernelInformation.KernelParameters(2)));
