%% Supervised Learning
% Build a "better" model for Y.oil as a function of the columns of X.



%% Build the extended data set
% Load the original data.
load('bakken.matlab', '-mat');

%%
% Add _proppant concentration_ and _oil saturation_ to the set of $X$ variables.
X = [X, table(X.proppant ./ X.frac_fluid / 42, ...
              X.oil_in_place / (5280^2/640) ./ X.thickness ./ (X.porosity/100) * (42*231/12^3) * 100, ...
              'VariableNames',{'proppant_concentration', 'oil_saturation'})];
X.Properties.VariableUnits{end-1} = 'lbs/gal';
X.Properties.VariableUnits{end} = '%';

%%
% Filter out the extreme and missing data.  Normally we would keep these rows
% and filter only as needed.  However, we will be comparing different models,
% and to do so the models all must be built on the exact same set of rows.
% We therefore throw out _all_ rows that _might_ not get used by one of our
% models.
tf_notmissing = (Y.oil > 0) & all(isfinite(table2array(X)),2);
tf_notextreme =   (X.proppant < 6e6)     ...
                & (X.frac_fluid < 1.5e5) ...
                & (X.proppant_concentration < 5);
X = X(tf_notmissing & tf_notextreme,:);
Y = Y(tf_notmissing & tf_notextreme,:);
clear tf_notmissing tf_notextreme;



%% Training data vs. test data
% We want to compare the predictive accuracy of different methods.
% In order to do this, we _must_ split the data into two sets, one on which to
% build the model (the *training* set) and one on which to evaluate its ability
% to make blind predictions (the *test* set).  The test data should be hidden
% until the very end.  There are many ways that information from the test set
% could sneak into your training and model building, so be careful.
%
% *DATA ANALYTICS NOTE*:  The test data should be chosen at random in order to
% avoid bias (just as you would use randomization in design of experiments).
% However, you _must_ make sure that your random split between training and
% test data is perfectly repeatable.  You don't want to do some exploratory
% work on a training set, then re-run your code and do more exploratory work on
% a different split of the data.  In that case, much of your new "test" data
% would have been part of your original "training" data.  In other words, you
% would have peeked at your test data.
RandStream.getGlobalStream.reset(); % ensure that we choose the same test set
                                    % every time we run the code
cvp_holdout = cvpartition(size(X,1), 'HoldOut',0.25); % 25% of data in test set
X_train = X(cvp_holdout.training, :);
Y_train = Y(cvp_holdout.training, :);
X_test = X(cvp_holdout.test, :);
Y_test = Y(cvp_holdout.test, :);
clear X Y cvp_holdout; % don't "peak" at the test data in Y



%% Model comparison
% Let's train a few models using default parameters.
%
% *MATLAB NOTE*:  Newer versions of Matlab encourage you to use the
% |fitensemble| function to build random forests.  I still use the old
% |TreeBagger| code because I have so many helper functions I've written over
% the years to work with |TreeBagger| objects.
mdl_def_linear = fitlm(horzcat(X_train, Y_train));
mdl_def_cart   = fitrtree(X_train, Y_train, ...
                          'Prune','off', 'Surrogate','off');
mdl_def_forest = TreeBagger(200, table2array(X_train), Y_train.oil, ...
                            'Method','regression', 'MinLeafSize',1);
num_models = 3;

%%
% To compare the models, we need to make predictions on the _test_ set.  We
% will make predictions on the test and training set here just to illustrate
% how different the results tend to be.
ax = NaN(1, 2*num_models);
for m=1:num_models
    switch m
        case 1
            mdl = mdl_def_linear;
            name = 'linear regression';
        case 2
            mdl = mdl_def_cart;
            name = 'CART (a.k.a. regression tree)';
        case 3
            mdl = mdl_def_forest;
            name = 'random forest';
    end

    h = figure();
    pos = h.Position;
    h.Position = [pos(1) pos(2) 2*pos(3) pos(4)];

    Y_hat_train = mdl.predict(table2array(X_train));
    R2_train = 1 - mean((Y_hat_train-Y_train.oil).^2) / var(Y_train.oil,1);
    ax(2*m-1) = subplot(1,2,1);
    plot(Y_hat_train, Y_train.oil, '.');
    xlabel('predicted oil production [bbls]');
    ylabel('actual oil production [bbls]');
    title(sprintf('training R^2 = %.3f', R2_train));

    Y_hat_test  = mdl.predict(table2array(X_test));
    R2_test = 1 - mean((Y_hat_test-Y_test.oil).^2) / var(Y_test.oil,1);
    ax(2*m) = subplot(1,2,2);
    plot(Y_hat_test, Y_test.oil, '.');
    xlabel('predicted oil production [bbls]');
    ylabel('actual oil production [bbls]');
    title(sprintf('test R^2 = %.3f', R2_test));

    suptitle(name);
end

% Make the axis limits uniform across all plots
limits = [+Inf, -Inf];
for h=ax
    limits(1) = min(horzcat(limits(1), xlim(h), ylim(h)));
    limits(2) = max(horzcat(limits(2), xlim(h), ylim(h)));
end
for h=ax
    xlim(h, limits);
    ylim(h, limits);
    hold(h, 'on');
    plot(h, limits, limits, '--');
end
drawnow();



%% Model optimization
% We used the default parameters for all of the models fit above.  Many
% supervised learning algorithms have tuning parameters that may be adjusted to
% improve performance.  However, we _must not_ tune the parameters against the
% test set.  The test set is only there for the final evaluation of the model,
% so the tuning parameters must be finalized before we even look at the test
% data.  We sometimes have enough data that we can hold out another data set
% (called the *validation* set) just for tuning the parameters.  However, we
% usually want to preserve as much training data as possible.  Can we tune the
% parameters using just the training data?
%
% Yes, but if we do so naively, then we will overfit the training data and our
% generalization performance will suffer.  The most common procedure to safely
% tune models on training data is called *cross-validation*.  This splits the
% training data into a mini-training set and a mini-test set, builds the model
% for every value of the tuning parameter on the mini-training set, evaluates
% those models on the mini-test set, and then repeats the process for different
% splits.  Most often, we use *k-fold cross-validation* (usually $k=10$):
% We first split the training data into $k$ subsets.  For each one, we combine
% the other $k-1$ subsets into a single mini-training set, train the model, and
% test against the last subset.  This gives us a test prediction for every
% training element for every value of our tuning parameter.
%
% Note that some of the model fitting functions will automatically use
% cross-validation (or other procedures) to optimize the tuning parameters.
% We will do it "manually" here just to illustrate the procedure.
%
% *DATA ANALYTICS NOTE*:  For cross-validation, we generally don't care about
% repeatability of the partitioning like we did with the split between training
% and test set.  However, it remains extremely important that you not "peek" at
% the test partition while building a model on the corresponding training
% partition.
cvk = cvpartition(size(X_train,1), 'KFold',10); % 10 folds

%%
% There are no parameters to optimize for ordinary linear regression.  However,
% if we were doing something a little more complicated like stepwise
% refinement, then parameter optimization might be important.  In that case,
% the parameters would be the thresholds controlling when to add or remove
% variables from the model.
mdl_opt_linear = fitlm(horzcat(X_train, Y_train));

%%
% For a single regression tree, the main choice is how "deep" to allow the tree
% to grow.  This is controlled by two related parameters to the |fitrtree|
% function which determine the smallest parent node that may be split into two
% children and the smallest child node allowed to remain in the tree without
% being merged with its sibling.
params = 1:5:(size(X_train,1)/8); % somewhat arbitrary set of parameters to try
param_sse = NaN(size(params));
for p=1:numel(params)
    Y_hat_train = NaN(numel(Y_train.oil), 1);
    for k=1:cvk.NumTestSets
        mdl_k = fitrtree(X_train(cvk.training(k),:),       ...
                         Y_train(cvk.training(k),:),       ...
                         'Prune','off', 'Surrogate','off', ...
                         'MinLeafSize',params(p), 'MinParentSize',2*params(p));
        Y_hat_train(cvk.test(k)) = mdl_k.predict(X_train(cvk.test(k),:));
    end
    param_sse(p) = sum((Y_train.oil - Y_hat_train).^2);
end
[~,param_opt_ind] = min(param_sse);
mdl_opt_cart = fitrtree(X_train, Y_train,                    ...
                        'Prune','off', 'Surrogate','off',    ...
                        'MinLeafSize',params(param_opt_ind), ...
                        'MinParentSize',2*params(param_opt_ind));
name_opt_cart = sprintf('CART (optimized MinLeafSize=%u)', params(param_opt_ind));

%%
% With a random forest, the main parameters are the number of predictor
% variables to sample at each node.  There are other parameters, but for
% example |MinLeafSize| should probably always be set to 1, and |NumTrees| can
% be made arbitrarily high without overfitting.
params = 1:size(X_train,2); % only possible values of |NumPredictorsToSample|
param_sse = NaN(size(params));
for p=1:numel(params)
    Y_hat_train = NaN(numel(Y_train.oil), 1);
    for k=1:cvk.NumTestSets
        mdl_k = TreeBagger(200, table2array(X_train(cvk.training(k),:)), ...
                           Y_train.oil(cvk.training(k)),                 ...
                           'Method','regression', 'MinLeafSize',1,       ...
                           'NumPredictorsToSample',params(p));
        Y_hat_train(cvk.test(k)) = mdl_k.predict(table2array(X_train(cvk.test(k),:)));
    end
    param_sse(p) = sum((Y_train.oil - Y_hat_train).^2);
end
[~,param_opt_ind] = min(param_sse);
mdl_opt_forest = TreeBagger(200, table2array(X_train), Y_train.oil, ...
                            'Method','regression', 'MinLeafSize',1, ...
                            'NumPredictorsToSample',params(param_opt_ind));
name_opt_forest = sprintf('random forest (optimized NumPredictorsToSample=%u)', params(param_opt_ind));

%%
% To compare the models, we need to make predictions on the _test_ set.  We
% will make predictions on the test and training set here just to illustrate
% how different the results tend to be.
ax = NaN(1, 2*num_models);
for m=1:num_models
    switch m
        case 1
            mdl = mdl_opt_linear;
            name = 'linear regression';
        case 2
            mdl = mdl_opt_cart;
            name = name_opt_cart;
        case 3
            mdl = mdl_opt_forest;
            name = name_opt_forest;
    end

    h = figure();
    pos = h.Position;
    h.Position = [pos(1) pos(2) 2*pos(3) pos(4)];

    Y_hat_train = mdl.predict(table2array(X_train));
    R2_train = 1 - mean((Y_hat_train-Y_train.oil).^2) / var(Y_train.oil,1);
    ax(2*m-1) = subplot(1,2,1);
    plot(Y_hat_train, Y_train.oil, '.');
    xlabel('predicted oil production [bbls]');
    ylabel('actual oil production [bbls]');
    title(sprintf('training R^2 = %.3f', R2_train));

    Y_hat_test  = mdl.predict(table2array(X_test));
    R2_test = 1 - mean((Y_hat_test-Y_test.oil).^2) / var(Y_test.oil,1);
    ax(2*m) = subplot(1,2,2);
    plot(Y_hat_test, Y_test.oil, '.');
    xlabel('predicted oil production [bbls]');
    ylabel('actual oil production [bbls]');
    title(sprintf('test R^2 = %.3f', R2_test));

    suptitle(name);
end

% Make the axis limits uniform across all plots
limits = [+Inf, -Inf];
for h=ax
    limits(1) = min(horzcat(limits(1), xlim(h), ylim(h)));
    limits(2) = max(horzcat(limits(2), xlim(h), ylim(h)));
end
for h=ax
    xlim(h, limits);
    ylim(h, limits);
    hold(h, 'on');
    plot(h, limits, limits, '--');
end
drawnow();



%% Classification And Regression Trees (CART)
% Now that we've decided on optimal parameters, we can build and use our models
% on the full data set.  We'll first study CART, which is the standard
% algorithm for generating a single tree.
%
% 'Surrogate' - A _very_ nice feature of trees is that they can handle missing
% data.  When making predictions, an $X$ vector is "dropped" down a tree.  It
% usually ends up at a "leaf" node, and the prediction will be the average
% value of all of the training elements in that leaf.  However, if at any
% non-leaf node in the tree the prediction vector is missing the data used to
% make that split, then the algorithm obviously can't tell whether to keep
% dropping the element to the left child or the right child.  Consequently, it
% just returns the average of all of the training elements below the node where
% the $X$ vector got stuck.  This works great, but can be made to work even
% better.  If you use the parameter 'Surrogate','on', the tree will generate
% "surrogate" splits at each node.  Then, if an $X$ vector gets stuck at a node
% because it is missing data, there will be additional split criterion that may
% be used instead.
t = fitrtree(vertcat(X_train,X_test), vertcat(Y_train,Y_test), ...
             'Surrogate','on', 'MinLeafSize',11, 'MinParentSize',2*11);

%%
% As we saw above, a single tree is generally much less predictive than
% a random forest.  However, they are _very_ nice for interpretability.  We can
% view a graphical representation of the tree to study the rules generated by
% the CART algorithm.  This can provide insight into the data and the problem.
t.view('Mode','graph');

%%
% Individual trees are not very stable in the following sense:  small
% perturbations to the training data can lead to big changes in the structure
% of the tree.  Even just removing a data point or adding a little noise can
% have a big impact.  In this case the tree seems relatively stable, so I'll
% added a fairly significant amount of noise just to illustrate the point.
Y_base = vertcat(Y_train.oil, Y_test.oil);
Y_perturbed = Y_base + std(Y_base)*randn(size(Y_base));
t2 = fitrtree(vertcat(X_train,X_test), Y_perturbed, ...
              'Surrogate','on', 'MinLeafSize',11, 'MinParentSize',2*11);
t2.view('Mode','graph');



%% Random Forests
% Because the CART algorithm may generate very different trees for different
% inputs, we might get more stability by intentionally adjusting the inputs and
% generating lots of trees.  This is the basis for the random forest algorithm.
% In the language of machine learning, random forests can significantly reduce
% the variance from the CART algorithm while only adding a little bias,
% therefore improving the generalization error.  The price for this is that we
% now have many different trees, so we've lost the interpretability of CART.
rf = TreeBagger(200, table2array(vertcat(X_train,X_test)), ...
                table2array(vertcat(Y_train,Y_test)),      ...
                'Method','regression', 'MinLeafSize',1,    ...
                'NumPredictorsToSample',4,                 ...
                'OOBPrediction','on', 'OOBPredictorImportance','on');

%%
% The random forest algorithm uses the bootstrap to select a different set of
% training data on which to build each tree.  This has the very nice property
% that the training data _not_ used to build a given tree may be used as
% a blind test set for that particular tree.  These so-called "out of bag"
% predictions can be averaged over all trees to get an _unbiased_ estimate of
% the generalization performance of the tree.  We can also see how the
% performance improves as we add more trees.  Note that the number of trees
% is _not_ a parameter you should optimize with cross-validation; the bigger
% the better, but performance quickly plateaus and computational performance
% gradually decays.
oob_error = rf.oobError('Mode', 'cumulative');
R2 = 1 - oob_error(end) / var(vertcat(Y_train.oil,Y_test.oil), 1);
figure();
plot(oob_error);
xlabel('number of trees in forest');
ylabel('out-of-bag mean squared error');
title(sprintf('Estimated generalization R^2 = %.3f', R2));

%%
% Another _very_ useful trick with random forests is to estimate the importance
% of the variables.  This works by randomly permuting the values of one of the
% predictor variables, making predictions with the shuffled data, and tallying
% how much worse the predictions are than with the original unshuffled data.
% This gives a good idea of the _global_ importance of the variables, i.e.
% their importance over the entire multidimensional space of predictor
% variables.  Keep in mind, though, that this is just the importance of the
% variables to _this_ random forest for making _this_ particular prediction.
% It definitely shouldn't be confused with physical importance, though we often
% wish to equate the two.
var_imp = rf.OOBPermutedPredictorDeltaError;
[~,idx] = sort(var_imp, 'ascend');
figure();
barh(1:numel(idx), var_imp(idx));
set(gca, 'YTick',1:numel(idx), ...
         'YTickLabel',X_train.Properties.VariableNames(idx));
ylim([0.25, numel(idx)+0.75]);
xlabel('variable impact on mean squared error');
set(gca, 'TickLabelInterpreter','none');
title('Random Forest Variable Importance');

%%
% We can use the random forest to make predictions for how $Y$ would change as
% a function of $X$.  We often want to know how Y changes, _on average_, as
% a function of one of the $X$ variables.  But how do you make "on average"
% precise?  We probably want to know the expected value of the change in
% $Y$ averaged over all future wells.  We can approximate this by averaging
% over all past wells.  I have code to do this:
proppant_values = linspace(prctile(X_train.proppant,  5), ...
                           prctile(X_train.proppant, 95), ...
                           10);
proppant_ind = find(strcmp('proppant', X_train.Properties.VariableNames));
y_hat = tb_parametric(rf, proppant_ind, proppant_values);
figure();
errorbar(proppant_values, mean(y_hat), 1.96*std(y_hat)/sqrt(size(y_hat,1)))
xlabel('proppant [lbs]');
ylabel('average predicted oil production [bbls]');

%%
% The above is called a "partial dependency plot".  I have another set of code
% that creates a matrix of all 1st- and 2nd-order partial dependencies.
%
% Warning - this takes a while to run.
tb_pdplot(rf, X_train.Properties.VariableNames, 'pure_interactions',true);
for ax=findobj(gcf, 'Type','Axes')'
    set(get(ax, 'xlabel'), 'Interpreter','none');
    set(get(ax, 'ylabel'), 'Interpreter','none');
end
