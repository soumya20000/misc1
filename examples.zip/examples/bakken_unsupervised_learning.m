%% Unsupervised Learning
% Regression and classification are *supervised learning* problems - given
% _labeled_ training data (X,Y), we would like to learn how to predict Y
% from X.  *Unsupervised learning* is the much more general class of problems
% of learning about _unlabeled_ data X.  This is very unconstrained.  We will
% only discuss two kinds of unsupervised learning problems - *clustering* and
% *dimensionality reduction*.



%% Build the extended data set
% Load the original data
load('bakken.matlab', '-mat');

%%
% Add _proppant concentration_ to the set of X variables.
X = [X, table(X.proppant ./ X.frac_fluid / 42, ...
              'VariableNames',{'proppant_concentration'})];
X.Properties.VariableUnits{end} = 'lbs/gal';

%%
% Remove the extreme and missing X-data.  We would ordinarily not throw any
% data out until we absolutely had to.  However, the algorithms discussed here
% are not robust to outliers or missing data, so we will throw out the "bad"
% data at the beginning for purposes of this demonstration.
tf_notmissing = all(isfinite(table2array(X)),2);
tf_notextreme =   (X.proppant < 6e6)     ...
                & (X.frac_fluid < 1.5e5) ...
                & (X.proppant_concentration < 5);
X = X(tf_notmissing & tf_notextreme,:);
clear tf_notmissing tf_notextreme;

%%
% Make sure we get the same results every time we run this code.
RandStream.getGlobalStream.reset();

%%
% Let's focus on the engineering parameters.
X_length_related = X(:,{'length','frac_fluid','proppant'});



%% Clustering
% In the context of supervised learning, classification refers to the problem
% of predicting an unknown label for new X data.  Such algorithms are trained
% on pre-labeled data (X,Y).  However, what if we do not have _any_ labels Y?
% Is it possible to automatically generate a discrete set of labels just given
% X?  This is known as *clustering*, and is probably the most common
% unsupervised learning problem.  It can also be posed as a rigorous
% statistical problem, though we won't pursue that line of reasoning here.
%
% The most widely used algorithm for clustering is called *k-means*.  Given
% a pre-determined number of clusters $k$, k-means groups the X data into
% $k$ clusters such that each point is closer to the mean value of its cluster
% than it is to the mean value of any other cluster.
%
% Note that the k-means algorithm is randomized.  It is not guaranteed to
% return the optimal solution, nor even to return the same solution each time
% it is run.  However, the Matlab implementation is fairly consistent from run
% to run.
%
% You have to pre-specify the number of clusters.  Let's visualize the results
% on the length-related data for various values of $k$.
for k=2:5
    [cluster_index, cluster_mean] = kmeans(X_length_related{:,:}, k);
    figure();
    for c=1:k
        % Plot each cluster in a different color
        h = plot3(X_length_related{cluster_index==c,1}, ...
                  X_length_related{cluster_index==c,2}, ...
                  X_length_related{cluster_index==c,3}, ...
                  '.');
        hold on;
        plot3(cluster_mean(c,1), cluster_mean(c,2), cluster_mean(c,3), ...
              'd', 'MarkerSize',12, 'MarkerFaceColor',h.Color, 'MarkerEdgeColor','k');
    end
    xlabel(X_length_related.Properties.VariableNames{1}, 'Interpreter','none');
    ylabel(X_length_related.Properties.VariableNames{2}, 'Interpreter','none');
    zlabel(X_length_related.Properties.VariableNames{3}, 'Interpreter','none');
    title(sprintf('k-means, k=%u', k));
    box on;
    grid on;
end

%%
% From the plots above, it does not appear that the k-means algorithm is
% finding the "natural" clusters in the data.  It seems instead to be focused
% almost entirely on the amount of proppant.  The problem is that the |kmeans|
% function uses Euclidean distances by default, and since the proppant values
% are much bigger than the frac fluid or length values, they dominate the
% distances.  We usually need to rescale the data so that the parameters have
% similar impacts on the Euclidean distances.  We can do this with the |zscore|
% function, which normalizes each column by subtracting the mean and dividing
% by the standard deviation.  (More generally, it is up to us to define the
% notion of _distance_ used for clustering.)
for k=2:5
    cluster_index = kmeans(zscore(X_length_related{:,:}), k);
    figure();
    for c=1:k
        % Plot each cluster in a different color.
        % Note that this time I'm computing the cluster means "by hand" rather
        % than using the means returned by the |kmeans| function.  The reason
        % is that I had re-scaled the data that I passed to |kmeans|, so it
        % would have returned rescaled cluster means.  What I want to plot,
        % though, are the cluster means in the original units.
        h = plot3(X_length_related{cluster_index==c,1}, ...
                  X_length_related{cluster_index==c,2}, ...
                  X_length_related{cluster_index==c,3}, ...
                  '.');
        hold on;
        plot3(nanmean(X_length_related{cluster_index==c,1}), ...
              nanmean(X_length_related{cluster_index==c,2}), ...
              nanmean(X_length_related{cluster_index==c,3}), ...
              'd', 'MarkerSize',12, 'MarkerFaceColor',h.Color, 'MarkerEdgeColor','k');
    end
    xlabel(X_length_related.Properties.VariableNames{1}, 'Interpreter','none');
    ylabel(X_length_related.Properties.VariableNames{2}, 'Interpreter','none');
    zlabel(X_length_related.Properties.VariableNames{3}, 'Interpreter','none');
    title(sprintf('k-means on normalized data, k=%u', k));
    box on;
    grid on;
end

%%
% These results are better, but it still looks like it is missing the most
% natural clustering, especially at $k=2$.  *Gaussian Mixture Models* are more
% sophisticated than the k-means algorithm:  they fit independent, multivariate
% Gaussian distributions for each cluster.  In this case, the results seem more
% intuitively correct.
for k=2:5
    mdl = fitgmdist(X_length_related{:,:}, k);
    cluster_index = mdl.cluster(X_length_related{:,:});
    figure();
    for c=1:k
        h = plot3(X_length_related{cluster_index==c,1}, ...
                  X_length_related{cluster_index==c,2}, ...
                  X_length_related{cluster_index==c,3}, ...
                  '.');
        hold on;
        plot3(nanmean(X_length_related{cluster_index==c,1}), ...
              nanmean(X_length_related{cluster_index==c,2}), ...
              nanmean(X_length_related{cluster_index==c,3}), ...
              'd', 'MarkerSize',12, 'MarkerFaceColor',h.Color, 'MarkerEdgeColor','k');
    end
    xlabel(X_length_related.Properties.VariableNames{1}, 'Interpreter','none');
    ylabel(X_length_related.Properties.VariableNames{2}, 'Interpreter','none');
    zlabel(X_length_related.Properties.VariableNames{3}, 'Interpreter','none');
    title(sprintf('Gaussian Mixture Model, k=%u', k));
    box on;
    grid on;
end

%%
% It is natural to ask how many clusters there "should" be.  There are a number
% of different ways to quantify how "good" a clustering is, and for any such
% quantification you can choose the value of $k$ that gives the best score.
% Matlab's |evalclusters| function will do this for you automatically.
% However, in practice the standard clustering metrics won't match your needs,
% so you shouldn't blindly trust |evalclusters| to optimize $k$.



%% Dimensionality Reduction - Principal Component Analysis (PCA)
% Let's focus just on the cluster of "long" wells.
k = 3;
mdl = fitgmdist(X_length_related{:,:}, k);
cluster_index = mdl.cluster(X_length_related{:,:});
[~,c] = max(mdl.mu(:,strcmp('length',X_length_related.Properties.VariableNames)));
fprintf('Cluster %u has the "long" wells\n', c);

%%
% The amount of proppant used in a well is generally chosen as a function of
% the well length, and the amount of frac fluid use in a well must be chosen as
% a function of the proppant amount.  These three variables are therefore
% highly correlated in the data set.
figure();
plot3(X_length_related{cluster_index==c,1}, ...
      X_length_related{cluster_index==c,2}, ...
      X_length_related{cluster_index==c,3}, '.');
xlabel(X_length_related.Properties.VariableNames{1}, 'Interpreter','none');
ylabel(X_length_related.Properties.VariableNames{2}, 'Interpreter','none');
zlabel(X_length_related.Properties.VariableNames{3}, 'Interpreter','none');
title(sprintf('Cluster %u', c));
box on;
grid on;

correlations = corr(X_length_related{cluster_index==c,:});
correlations = array2table(correlations, ...
                           'VariableNames',X_length_related.Properties.VariableNames, ...
                           'RowNames',X_length_related.Properties.VariableNames);
fprintf('Linear correlations for cluster %u:\n', c);
disp(correlations);

%%
% A natural question to ask is, how much _independent_ information is contained
% in these correlated variables?  If the frac fluid volume and proppant amount
% were always chosen as the _same_ function of completion length, then the
% completion length alone would effectively contain all of the information
% about these three quantities.  *Principal Component Analysis* looks for the
% linear combinations of the variables that contain the most information in the
% sense of explaining the most variation in the raw data.  Matlab has
% a built-in PCA function:
[coeff,score,latent,tsquared,explained,mu] = pca(X_length_related{cluster_index==c,:}, ...
                                                 'VariableWeights','variance');

%%
% The Principal Components are returned ordered by the fraction of the
% variation from the original data explained by them.  This is often visualized
% with a so-called *scree plot*.
figure();
pareto(explained);
xlabel('Principal Component');
ylabel('variance explained [%]');
title(sprintf('scree plot for cluster %u', c));

%%
% Note that no information has been lost.  This is purely a linear
% transformation.  The original data can be exactly recovered (up to
% numerical errors) from the PCA output.  In particular, |mu| contains the mean
% value of the original data, |coeff| contains the principal component
% coefficients in the original basis, and |score| contains the coefficients of
% the original data in the principal component basis.
tmp = bsxfun(@plus, mu, score * coeff');
relative_error = tmp ./ X_length_related{cluster_index==c,:} - 1;
disp( max(abs(relative_error(:))) );

%%
% The "Principal Components" are just linear combinations of the original
% variables.
for p=1:size(coeff,2)
    fprintf('Principal Component %u: ', p);
    for v=1:size(coeff,1)
        if (v > 1)
            fprintf(' + ');
        end
        fprintf('%8.1f*%s', ...
                coeff(v,p), X_length_related.Properties.VariableNames{v});
    end
    fprintf('\n');
end

%%
% This becomes a little more intuitive once we visualize the results.
for p=1:size(coeff,2)
    figure();
    scatter3(X_length_related{cluster_index==c,1}, X_length_related{cluster_index==c,2}, ...
             X_length_related{cluster_index==c,3}, 10, score(:,p), 'filled');
    xlabel(X_length_related.Properties.VariableNames{1}, 'Interpreter','none');
    ylabel(X_length_related.Properties.VariableNames{2}, 'Interpreter','none');
    zlabel(X_length_related.Properties.VariableNames{3}, 'Interpreter','none');
    box on;
    colorbar();
    title(sprintf('Principal Component %u', p));
end

%%
% PCA is commonly used to help understand high-dimensional data.  When there
% are only three components, we can do this visually.  So, just to illustrate
% the point, let's add a fourth variable - the stage count.  A stage count of
% less than 10 for these new, long wells is probably a data problem, so we'll
% throw those rows out.  What we see is:
%
% # 57% of the variation in the data is just related to proportional scaling of length, proppant, fluid, and stages
% # 22% of the variation in the data is related to using more proppant, fluid, and stages per foot of well length
% # 13% of the variation in the data is related to using more proppant and fluid per frac stage
% #  8% of the variation in the data is related to varying the proportion of proppant to frac fluid
tf = (cluster_index == c) & (X.frac_stages >= 10);
X_length_related2 = X(tf, {'length','frac_fluid','proppant','frac_stages'});
[coeff,score,latent,tsquared,explained,mu] = pca(X_length_related2{:,:}, ...
                                                 'VariableWeights','variance');
figure();
pareto(explained);
xlabel('Principal Component');
ylabel('variance explained [%]');
title(sprintf('scree plot for cluster %u', c));
for p=1:size(coeff,2)
    fprintf('Principal Component %u: ', p);
    for v=1:size(coeff,1)
        if (v > 1)
            fprintf(' + ');
        end
        fprintf('%8.1f*%s', ...
                coeff(v,p), X_length_related2.Properties.VariableNames{v});
    end
    fprintf('\n');
end

%%
% The other common use for PCA is to reduce the number of variables to be
% included in a classification or regression model.  This is more useful when
% the original data is higher dimensional than the data sets we've been using.
