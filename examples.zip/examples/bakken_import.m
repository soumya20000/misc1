%% Unconventional Well Example
% The BAKKEN.MAT file contains information about several thousand wells
% in the Bakken formation in North Dakota and Montana.
% It contains the following *geographic* information:
%
% # X.latitude
% # X.longitude
%
% It contains the following *engineering* information:
%
% # X.length - total completed length of the horizontal well in contact with
%              the reservoir
% # X.frac_fluid - total number of barrels of fluid pumped into the well during
%                  hydraulic fracturing
% # X.proppant - total weight of sand pumped into the well during
%                hydraulic fracturing
% # X.frac_stages - number of operational stages used to hydraulically fracture
%                   the complete lateral length of the well
% 
% It contains the following *geological* information:
%
% # X.thickness - the gross reservoir thickness near the well
% # X.porosity - the average reservoir porosity near the well
% # X.oil_in_place - the resource density, a.k.a. Original Oil In Place (OOIP)
%
% Finally, it contains the following *production* information:
%
% # Y.oil - the total volume of oil produced from the well over its
%           first 365 days of production

%% Import Data
% *MATLAB/SHAREPOINT NOTE*:  Normally you would save data from your Matlab
% workspace into a file with a '.mat' extension.  However, SharePoint won't let
% me save a '.mat' file to my MySite.  To get around this, I renamed the file
% with a '.matlab' extension, which fools SharePoint but unfortunately also
% fools Matlab.  To get around THAT, I had to include the '-mat' parameter to
% Matlab's *|load|* function.
load('bakken.matlab', '-mat');
summary(X)
summary(Y)



%% Plot the data

%%
% Plot the engineering data
h = figure();
h.Position = [h.Position(1)-h.Position(3), ...
              h.Position(2)-h.Position(4), ...
              2*h.Position(3),             ...
              2*h.Position(4)]; % make the figure bigger
gplotmatrix([X.length, X.frac_fluid, X.proppant, X.frac_stages], ...
            [], [], '', '.', [], 'off', 'hist',                  ...
            {'length','frac\_fluid','proppant','frac\_stages'})

%%
% Plot the geological data
figure();
scatter(X.longitude, X.latitude, 10, X.thickness, 'filled');
xlabel('longitude [deg]');
ylabel('latitude [deg]');
title('gross reservoir thickness [ft]');
colorbar();

figure();
scatter(X.longitude, X.latitude, 10, X.porosity, 'filled');
xlabel('longitude [deg]');
ylabel('latitude [deg]');
title('reservoir porosity [%]');
colorbar();

figure();
scatter(X.longitude, X.latitude, 10, X.oil_in_place, 'filled');
xlabel('longitude [deg]');
ylabel('latitude [deg]');
title('resource density (Original Oil In Place) [bbls/acre]');
colorbar();

%%
% Plot the production data
figure();
histogram(Y.oil);
xlabel('365-day oil production [bbls]');
